#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QtQml>

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);
  //  qmlRegisterSingletonType( QUrl("file:///absolute/path/Styling.qml"), "tutorial.style", 1, 0, "MyStyle" );
    qmlRegisterSingletonType(QUrl(QStringLiteral("qrc:/Styling.qml")), "tutorial.style", 1, 0, "MyStyle" );
 //   QUrl("file://Styling.qml")
    QQmlApplicationEngine engine;
    engine.load(QUrl(QStringLiteral("qrc:/main.qml")));

//    QObject *rootObject = engine.rootObjects().first();
//       QObject *qmlObject = rootObject->findChild<QObject*>("mainWindow");

//       // Step 2a: set or get the desired property value for the root object
//       rootObject->setProperty("visible", true);

//       // Step 2b: set or get the desired property value for any qml object
//       qmlObject->setProperty("visible", false);


    return app.exec();
}
