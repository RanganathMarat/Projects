#ifndef MODEL_H
#define MODEL_H

#endif // MODEL_H

#include <QAbstractListModel>
#include <QStringList>

//![0]
class ExecutionListItem:public QObject
{
    Q_OBJECT
Q_PROPERTY (QString name READ GetName WRITE SetName NOTIFY NameChangedEvent);
public:
     ExecutionListItem(){}
    ExecutionListItem(const QString &name, const QString &duration);
//![0]

    QString GetName() const;
    QString duration() const;

private:

    QString m_name;
    QString m_duration;
public slots:
    void SetName(QString arg)
    {
        if (m_name != arg) {
            m_name = arg;
            NameChangedEvent(arg);
        }
    }

signals:
    void NameChangedEvent(QString arg);

//![1]
};

class ExecutionList: public QAbstractListModel
{
    Q_OBJECT
public:
    enum ExecutionListRoles {
        NameRole = Qt::UserRole + 1,
        DurationRole
    };

    ExecutionList(QObject *parent = 0);
//![1]

    void addExecutionListItem( ExecutionListItem *executionListItem);

    int rowCount(const QModelIndex & parent = QModelIndex()) const;

    QVariant data(const QModelIndex & index, int role = Qt::DisplayRole) const;

    void AddItem ();

    void RemoveItem ();



public slots:
    void ButtonClicked();

protected:
    QHash<int, QByteArray> roleNames() const;
private:
    QList<ExecutionListItem*> m_executionListItems;
    int i;
};





