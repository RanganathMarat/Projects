#include "model.h"
#include "qdebug.h"

ExecutionListItem::ExecutionListItem(const QString &name, const QString &duration)
    : m_name(name), m_duration(duration)
{
}

QString ExecutionListItem::GetName() const
{
    return m_name;
}

QString ExecutionListItem::duration() const
{
    return m_duration;
}

ExecutionList::ExecutionList(QObject *parent)
   : QAbstractListModel(parent)
{
    i = 0;
}

void ExecutionList::addExecutionListItem( ExecutionListItem *executionListItem)
{
    beginInsertRows(QModelIndex(), rowCount(), rowCount());
    m_executionListItems << executionListItem;
   endInsertRows();
}

int ExecutionList::rowCount(const QModelIndex & parent) const {
    Q_UNUSED(parent);
    return m_executionListItems.count();
}

QVariant ExecutionList::data(const QModelIndex & index, int role) const {
     qDebug()<<"Retrive executionListItem111";
    if (index.row() < 0 || index.row() >= m_executionListItems.count())
        return QVariant();

    const ExecutionListItem *executionListItem = m_executionListItems[index.row()];
    if (role == NameRole)
    {
        qDebug()<<"Retrive ECList Model";
        return executionListItem->GetName();
    }
    else if (role == DurationRole)
    {
         qDebug()<<"Retrive ECList duration";
        return executionListItem->duration();
    }
    qDebug()<<"Retrive executionListItem";
    return executionListItem;
//   return NULL;
}

void ExecutionList::AddItem(){

   ExecutionListItem *executionListItem = new ExecutionListItem("Protocol_Temp", "03:00");
  // QModelIndex index = m_executionListItems.index(0,0);
   beginInsertRows(QModelIndex(), 1,1);
   //m_executionListItems.prepend(executionListItem);
   m_executionListItems.insert(1,executionListItem);
  endInsertRows();
   // this->addExecutionListItem(new ExecutionListItem("Protocol_Temp", "03:00"));
}

void ExecutionList::ButtonClicked(){
    AddItem();
}

//![0]
QHash<int, QByteArray> ExecutionList::roleNames() const {
    QHash<int, QByteArray> roles;
    roles[NameRole] = "name";
    roles[DurationRole] = "duration";
    return roles;
}
//![0]


