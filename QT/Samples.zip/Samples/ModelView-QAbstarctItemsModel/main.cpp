#include "model.h"
#include <QApplication>
#include <QQmlApplicationEngine>
#include <qqmlcontext.h>
#include <QElapsedTimer>
#include <QMessageBox>
#include <QtQml>
int main(int argc, char *argv[])
{
    qmlRegisterType<ExecutionListItem>("DTOLibrary", 1,0, "ExecutionListItem");

    QApplication app(argc, argv);
    QElapsedTimer myTimer;
     myTimer.start();


   ExecutionList executionList;
/*    executionList.addExecutionListItem(ExecutionListItem("Survey", "03:00"));
    executionList.addExecutionListItem(ExecutionListItem("ffe", "04:00"));
    executionList.addExecutionListItem(ExecutionListItem("b1_ffe", "05:00"));
    executionList.addExecutionListItem(ExecutionListItem("b1_ffe", "05:00"));
    executionList.addExecutionListItem(ExecutionListItem("b1_ffe", "05:00"));*/
     //QString::number(myTimer.elapsed())+ " ms";
    QQmlApplicationEngine engine;
    engine.load(QUrl(QStringLiteral("qrc:/main.qml")));



    ExecutionListItem *ecItem;


    for (int i  = 0; i < 100; i++)
    {
        ecItem= new ExecutionListItem("Survey " +  QString::number(i), "03:00");
        executionList.addExecutionListItem(ecItem);
    }

    QQmlContext *ctxt = engine.rootContext();
    ctxt->setContextProperty("_myModel",&executionList);

     QMessageBox::information(NULL, "Application Control creation time", QString::number(myTimer.elapsed())+ " ms");



    return app.exec();

}
