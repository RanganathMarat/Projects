#ifndef ExamcardDTO_HEADER
#define ExamcardDTO_HEADER

#include <qobject.h>
#include <QQmlListProperty>

#include "dtobase.h"
#include "scansetdto.h"
#include "executionstepdto.h"

class ExamcardDTO : public DTOBase
{
    Q_OBJECT

private:
    QString _name = "Brain";
    Q_PROPERTY (QString name READ GetName WRITE SetName NOTIFY NameChangedEvent);

public:
    ExamcardDTO::ExamcardDTO()
    {

    }

    virtual ~ExamcardDTO()
    { }

    QString GetName() const
    {
        return _name;
    }


public slots:
    void SetName(QString arg)
    {
        if (_name != arg) {
            _name = arg;
            NameChangedEvent(arg);
        }
    }

signals:
    void NameChangedEvent(QString arg);
};

#endif
