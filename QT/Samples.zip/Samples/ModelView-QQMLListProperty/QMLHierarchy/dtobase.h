#ifndef DTOBase_HEADER
#define DTOBase_HEADER

#include <qobject.h>
#include <QQmlListProperty>
#include "observablecollection.h"

class DTOBase : public QObject
{
    Q_OBJECT

private:
    ObservableCollection *_childElements;
    Q_PROPERTY (ObservableCollection* childElements READ childElements NOTIFY DTOChanged);

public:
    DTOBase::DTOBase()
    {
        _childElements = new ObservableCollection();


    }
    virtual ~DTOBase()
    {
        _childElements->clearAll();
    }

    ObservableCollection* childElements()
    {

        return _childElements;
    }

public slots:

signals:
    void DTOChanged();

};

#endif
