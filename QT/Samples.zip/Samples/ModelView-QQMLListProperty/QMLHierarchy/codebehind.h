#ifndef CodeBehind_HEADER
#define CodeBehind_HEADER

#include <qobject.h>
#include <QQmlListProperty>
#include "examcarddto.h"
#include "qmessagebox.h"
#include "QElapsedTimer"


class CodeBehind : public QObject
{
    Q_OBJECT

private:
    ExamcardDTO* _examcardDTO;
    Q_PROPERTY (ExamcardDTO* examcard READ GetExamcard NOTIFY examcardChanged);

public:
    CodeBehind::CodeBehind()
    {
        _examcardDTO = new ExamcardDTO();

        ScanSetDTO *ss = new ScanSetDTO();
        ExecutionStepDTO *es = new ExecutionStepDTO();

        ss->SetName("[ss]Survey");
        es->SetName("Survey");
        ss->childElements()->add(es);
        _examcardDTO->childElements()->add(ss);

        ss = new ScanSetDTO();
        es = new ExecutionStepDTO();
        ss->SetName("[ss]Scan1");
        es->SetName("Scan1");
        ss->childElements()->add(es);
        es = new ExecutionStepDTO();
        es->SetName("Scan2");
        ss->childElements()->add(es);
        _examcardDTO->childElements()->add(ss);



    }

    virtual ~CodeBehind()
    { }

    ExamcardDTO* GetExamcard() const
    {
        return _examcardDTO;
    }

    Q_INVOKABLE void PerformanceCommand()
    {
          ExamcardDTO *_temp = new ExamcardDTO();
        _temp->SetName("SmartBrain");
        //_temp->childElements()->clearAll();

        ScanSetDTO *ss;
        ExecutionStepDTO *es;

         QElapsedTimer myTimer;
             myTimer.start();



        for(int i = 0 ; i< 100; i++)
        {
            ss = new ScanSetDTO();


            es = new ExecutionStepDTO();
            ss->SetName("[ss]");
            es->SetName("Scan" +  QString::number(i+1));
            ss->childElements()->add(es);
       _temp->childElements()->add(ss);
        }
       _examcardDTO=_temp;
         this->examcardChanged();
          QMessageBox::information(NULL, "Application Control creation time", QString::number(myTimer.elapsed())+ " ms");
    }

    Q_INVOKABLE void ChangeNameCommand()
    {
      //  ((ExecutionStepDTO*)((ScanSetDTO*)_examcardDTO->childElements()->itemAt(0))->childElements()->itemAt(0))->SetName("ChangedName");
//        ExecutionStepDTO *es = new ExecutionStepDTO();

//        es->SetName("temp");
//      ((ScanSetDTO*)(_examcardDTO->childElements()->itemAt(0)))->childElements()->add(es);

        ScanSetDTO *ss;
        ExecutionStepDTO *es;
        ss = new ScanSetDTO();
        es = new ExecutionStepDTO();
        ss->SetName("[ss]");
        es->SetName("Temp");
        ss->childElements()->add(es);
        _examcardDTO->childElements()->add(ss);

    }

    Q_INVOKABLE void ChangeCommand()
    {
        if(_examcardDTO->GetName()!="SmartBrain")
        {
            _examcardDTO->SetName("SmartBrain");
            _examcardDTO->childElements()->clearAll();

            ScanSetDTO *ss = new ScanSetDTO();
            ExecutionStepDTO *es = new ExecutionStepDTO();
            ss->SetName("[ss]");
            es->SetName("SmartSurvey");
            ss->childElements()->add(es);
            _examcardDTO->childElements()->add(ss);
            ss = new ScanSetDTO();
            es = new ExecutionStepDTO();
            ss->SetName("[ss]");
            es->SetName("SmartScan1");
            ss->childElements()->add(es);
            es = new ExecutionStepDTO();
            es->SetName("SmartScan2");
            ss->childElements()->add(es);
            _examcardDTO->childElements()->add(ss);
            ss = new ScanSetDTO();
            es = new ExecutionStepDTO();
            ss->SetName("[ss]");
            es->SetName("Scan3");
            ss->childElements()->add(es);
            _examcardDTO->childElements()->add(ss);

        }
        else
        {
            _examcardDTO->SetName("Brain");
            _examcardDTO->childElements()->clearAll();

            ScanSetDTO *ss = new ScanSetDTO();
            ExecutionStepDTO *es = new ExecutionStepDTO();
            ss->SetName("[ss]");
            es->SetName("Survey");
            ss->childElements()->add(es);
            _examcardDTO->childElements()->add(ss);
            ss = new ScanSetDTO();
            es = new ExecutionStepDTO();
            ss->SetName("[ss]");
            es->SetName("Scan1");
            ss->childElements()->add(es);
            es = new ExecutionStepDTO();
            es->SetName("Scan2");
            ss->childElements()->add(es);
            _examcardDTO->childElements()->add(ss);
        }
    }

public slots:


signals:
void examcardChanged();
};

#endif
