#include <QApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QtQml>
#include "codebehind.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    qmlRegisterType<DTOBase>("DTOLibrary", 1,0, "DTOBase");
    qmlRegisterType<ExecutionStepDTO>("DTOLibrary", 1,0, "ExecutionStepDTO");
    qmlRegisterType<ScanSetDTO>("DTOLibrary", 1,0, "ScanSetDTO");
    qmlRegisterType<ExamcardDTO>("DTOLibrary", 1,0, "ExamcardDTO");
    qmlRegisterType<ObservableCollection>("DTOLibrary", 1,0, "ObservableCollection");

    QQmlApplicationEngine engine;
    engine.load(QUrl(QStringLiteral("qrc:/main.qml")));

    CodeBehind * cb = new CodeBehind();
    engine.rootContext()->setContextProperty("mainmodel",cb);

    return app.exec();
}
