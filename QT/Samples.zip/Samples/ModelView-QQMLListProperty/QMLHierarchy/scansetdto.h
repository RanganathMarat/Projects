#ifndef ScanSetDTO_HEADER
#define ScanSetDTO_HEADER

#include <qobject.h>
#include <QQmlListProperty>
#include "dtobase.h"

class ScanSetDTO : public DTOBase
{
    Q_OBJECT

private:
    QString _name = "EStep";
    Q_PROPERTY (QString name READ GetName WRITE SetName NOTIFY NameChangedEvent);

public:
    ScanSetDTO::ScanSetDTO()
    {
    }

    virtual ~ScanSetDTO()
    { }

    QString GetName() const
    {
        return _name;
    }


public slots:
    void SetName(QString arg)
    {
        if (_name != arg) {
            _name = arg;
            NameChangedEvent(arg);
        }
    }

signals:
    void NameChangedEvent(QString arg);
};
#endif
