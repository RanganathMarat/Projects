#ifndef ObservableCollection_HEADER
#define ObservableCollection_HEADER

#include <qobject.h>
#include <QQmlListProperty>
#include <QDebug>

class ObservableCollection : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QQmlListProperty<QObject> list READ list NOTIFY listChanged)
    Q_CLASSINFO("DefaultProperty", "list")
private:
    QList<QObject*> _list;

public:
    ObservableCollection::ObservableCollection()
    {
    }
    virtual ~ObservableCollection()
    { }
    // meant for use by QQmlListProperty Only
    static void ObservableCollection::append(QQmlListProperty<QObject> *property, QObject* value) {
        ObservableCollection *collection = qobject_cast<ObservableCollection *>(property->object);
        if (collection) {
            collection->_list.append(value);
            collection->listChanged();
        }
    }
    // meant for use by QQmlListProperty Only
    static void ObservableCollection::clear(QQmlListProperty<QObject> *property) {
        ObservableCollection *collection = qobject_cast<ObservableCollection *>(property->object);
        if (collection) {
            collection->_list.clear();
            collection->listChanged();
        }
    }
    // meant for use by QQmlListProperty Only
    static int ObservableCollection::size(QQmlListProperty<QObject> *property) {
        ObservableCollection *collection = qobject_cast<ObservableCollection *>(property->object);
        int size;
        if (collection) {
            size = collection->_list.count();
        }
        return size;
    }
    // meant for use by QQmlListProperty Only
    static QObject* ObservableCollection::at(QQmlListProperty<QObject> *property, int index) {
        ObservableCollection *collection = qobject_cast<ObservableCollection *>(property->object);
        QObject* obj;
        if (collection) {
            obj = collection->_list.at(index);
        }
        return obj;
    }

    QQmlListProperty<QObject> list()
    {
        return QQmlListProperty<QObject>(this,&_list, &append, &size, &at, &clear);
    }

public slots:
    // public add method
    void add(QObject* value)
    {
        _list.append(value);
       this->listChanged();
        qDebug()<<"ListChanged on Add";
      // QDebug()<<"ListChanged on Add";
    }
    // public remove method
    bool remove(QObject* value)
    {
        bool success = _list.removeOne(value);
        this->listChanged();
         qDebug()<<"ListChanged on Remove";
        return success;
    }
    // public clear method
    void clearAll()
    {
        _list.clear();
        this->listChanged();
         qDebug()<<"ListChanged on Clear";
    }
    // public at method
    QObject* itemAt(int index)
    {
        QObject* obj = _list.at(index);
        return obj;
    }

signals:
    void listChanged();

};



#endif
