/****************************************************************************
** Meta object code from reading C++ file 'observablecollection.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.4.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../observablecollection.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'observablecollection.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.4.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_ObservableCollection_t {
    QByteArrayData data[12];
    char stringdata[120];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_ObservableCollection_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_ObservableCollection_t qt_meta_stringdata_ObservableCollection = {
    {
QT_MOC_LITERAL(0, 0, 20), // "ObservableCollection"
QT_MOC_LITERAL(1, 21, 15), // "DefaultProperty"
QT_MOC_LITERAL(2, 37, 4), // "list"
QT_MOC_LITERAL(3, 42, 11), // "listChanged"
QT_MOC_LITERAL(4, 54, 0), // ""
QT_MOC_LITERAL(5, 55, 3), // "add"
QT_MOC_LITERAL(6, 59, 5), // "value"
QT_MOC_LITERAL(7, 65, 6), // "remove"
QT_MOC_LITERAL(8, 72, 8), // "clearAll"
QT_MOC_LITERAL(9, 81, 6), // "itemAt"
QT_MOC_LITERAL(10, 88, 5), // "index"
QT_MOC_LITERAL(11, 94, 25) // "QQmlListProperty<QObject>"

    },
    "ObservableCollection\0DefaultProperty\0"
    "list\0listChanged\0\0add\0value\0remove\0"
    "clearAll\0itemAt\0index\0QQmlListProperty<QObject>"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ObservableCollection[] = {

 // content:
       7,       // revision
       0,       // classname
       1,   14, // classinfo
       5,   16, // methods
       1,   52, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // classinfo: key, value
       1,    2,

 // signals: name, argc, parameters, tag, flags
       3,    0,   41,    4, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       5,    1,   42,    4, 0x0a /* Public */,
       7,    1,   45,    4, 0x0a /* Public */,
       8,    0,   48,    4, 0x0a /* Public */,
       9,    1,   49,    4, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::QObjectStar,    6,
    QMetaType::Bool, QMetaType::QObjectStar,    6,
    QMetaType::Void,
    QMetaType::QObjectStar, QMetaType::Int,   10,

 // properties: name, type, flags
       2, 0x80000000 | 11, 0x00495009,

 // properties: notify_signal_id
       0,

       0        // eod
};

void ObservableCollection::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        ObservableCollection *_t = static_cast<ObservableCollection *>(_o);
        switch (_id) {
        case 0: _t->listChanged(); break;
        case 1: _t->add((*reinterpret_cast< QObject*(*)>(_a[1]))); break;
        case 2: { bool _r = _t->remove((*reinterpret_cast< QObject*(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 3: _t->clearAll(); break;
        case 4: { QObject* _r = _t->itemAt((*reinterpret_cast< int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QObject**>(_a[0]) = _r; }  break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (ObservableCollection::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ObservableCollection::listChanged)) {
                *result = 0;
            }
        }
    }
}

const QMetaObject ObservableCollection::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_ObservableCollection.data,
      qt_meta_data_ObservableCollection,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *ObservableCollection::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ObservableCollection::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_ObservableCollection.stringdata))
        return static_cast<void*>(const_cast< ObservableCollection*>(this));
    return QObject::qt_metacast(_clname);
}

int ObservableCollection::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 5)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 5;
    }
#ifndef QT_NO_PROPERTIES
      else if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QQmlListProperty<QObject>*>(_v) = list(); break;
        default: break;
        }
        _id -= 1;
    } else if (_c == QMetaObject::WriteProperty) {
        _id -= 1;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 1;
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        if (_id < 1)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 1;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void ObservableCollection::listChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, Q_NULLPTR);
}
QT_END_MOC_NAMESPACE
