#include "examcardmodelitem.h"


ExamcardModelItem::ExamcardModelItem(const QString &name, const QString &duration)
    : exam_name(name), exam_duration(duration)
{
}

QString ExamcardModelItem::examCardName() const
{
    return exam_name;
}

QString ExamcardModelItem::examDuration() const
{
    return exam_duration;
}
ExamcardModelItem::~ExamcardModelItem()
{

}


ExamCardModel::ExamCardModel(QObject *parent)
    : QAbstractItemModel(parent)
{
    i = 0;
}

void ExamCardModel::addExamCard(const ExamCardModelItem &ExamCardModelItem)
{
    beginInsertRows(QModelIndex(), rowCount(), rowCount());
    examCards << ExamCardModelItem;
    endInsertRows();
}
int ExamCardModel::columnCount(const QModelIndex &parent) const
{
    Q_UNUSED(parent);
    return examCards.count();
}
int ExamCardModel::rowCount(const QModelIndex & parent) const {
    Q_UNUSED(parent);
    return examCards.count();
}
int ExamCardModel::index(int row, int column, const QModelIndex &parent) const
{
    if (row < rowCount(parent) && column < columnCount(parent))
            return createIndex(row, column, examCards.at(row));
     return QModelIndex();
}

QVariant ExamCardModel::data(const QModelIndex & index, int role) const
{
    if (index.row() < 0 || index.row() >= examCards.count())
        return QVariant();

    const ExamCardModelItem &ExamCardModelItem = examCards[index.row()];
    if (role == NameRole)
        return ExamCardModelItem.name();
    else if (role == DurationRole)
        return ExamCardModelItem.duration();
    return QVariant();
}

void ExamCardModel::AddItem(){
    i++;
    this->examCards(ExamCardModelItem("Exam ", "03:00"));
}

void ExamCardModel::ButtonClicked(){
    AddItem();
}

//![0]
QHash<int, QByteArray> ExamCardModel::roleNames() const {
    QHash<int, QByteArray> roles;
    roles[NameRole] = "name";
    roles[DurationRole] = "duration";
    return roles;
}
