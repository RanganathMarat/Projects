#ifndef MODEL_H
#define MODEL_H

#endif // MODEL_H

#include <QAbstractItemModel>
#include <QAbstractListModel>
#include <QStringList>

//![0]
class ExecutionListItem
{
public:
    ExecutionListItem(const QString &name, const QString &duration);
//![0]

    QString name() const;
    QString duration() const;

private:
    QString m_name;
    QString m_duration;
//![1]
};

class ExecutionList: public QAbstractItemModel
{
    Q_OBJECT
public:
    enum ExecutionListRoles {
        NameRole = Qt::UserRole + 1,
        DurationRole
    };

    ExecutionList(QObject *parent = 0);
//![1]

    void addExecutionListItem(const ExecutionListItem &executionListItem);
    QModelIndex index(int row, int column, const QModelIndex &parent) const;

    int rowCount(const QModelIndex & parent = QModelIndex()) const;
    int columnCount(const QModelIndex &parent) const;
    QModelIndex parent(const QModelIndex &child) const = 0;
    QVariant data(const QModelIndex & index, int role = Qt::DisplayRole) const;

    void AddItem ();

    void RemoveItem ();



public slots:
    void ButtonClicked();

protected:
    QHash<int, QByteArray> roleNames() const;
private:
    QList<ExecutionListItem> m_executionListItems;
    int i;
};





