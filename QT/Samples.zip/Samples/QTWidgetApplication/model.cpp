#include "model.h"

ExecutionListItem::ExecutionListItem(const QString &name, const QString &duration)
    : m_name(name), m_duration(duration)
{
}

QString ExecutionListItem::name() const
{
    return m_name;
}

QString ExecutionListItem::duration() const
{
    return m_duration;
}

ExecutionList::ExecutionList(QObject *parent)
   : QAbstractItemModel(parent)
{
    i = 0;
}

void ExecutionList::addExecutionListItem(const ExecutionListItem &executionListItem)
{
    beginInsertRows(QModelIndex(), rowCount(), rowCount());
    m_executionListItems << executionListItem;
    endInsertRows();
}

int ExecutionList::index(int row, int column, const QModelIndex &parent) const
{
    if (row < rowCount(parent) && column < columnCount(parent))
            return createIndex(row, column, examCards.at(row));
     return QModelIndex();
}

int ExecutionList::rowCount(const QModelIndex & parent) const {
    Q_UNUSED(parent);
    return m_executionListItems.count();
}

int ExecutionList::columnCount(const QModelIndex &parent) const
{
    Q_UNUSED(parent);
    return m_executionListItems.count();
}

QModelIndex ExecutionList::parent(const QModelIndex &child) const
{
      Q_UNUSED(child);
   return  QModelIndex();
 }


QVariant ExecutionList::data(const QModelIndex & index, int role) const {
    if (index.row() < 0 || index.row() >= m_executionListItems.count())
        return QVariant();

    const ExecutionListItem &executionListItem = m_executionListItems[index.row()];
    if (role == NameRole)
        return executionListItem.name();
    else if (role == DurationRole)
        return executionListItem.duration();
    return QVariant();
//   return NULL;
}

void ExecutionList::AddItem(){
  //  i++;
  //  this->addExecutionListItem(ExecutionListItem("Protocol_"+  QString::number (i), "03:00"));
}

void ExecutionList::ButtonClicked(){
    AddItem();
}

//![0]
QHash<int, QByteArray> ExecutionList::roleNames() const {
    QHash<int, QByteArray> roles;
    roles[NameRole] = "name";
    roles[DurationRole] = "duration";
    return roles;
}
//![0]


