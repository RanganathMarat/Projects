#include "form.h"
#include "ui_form.h"

Form::Form(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Form)
{
    ui->setupUi(this);
    this->setMaximumHeight(60);
    this->setMaximumWidth(180);
}
void Form::SetInteractor(int iterator)
{
    //QString s = QString::number(iterator);
    ui->scanNr->setText( "1, " + QString::number(iterator));

    //ui->scanNr->setTextFormat(Qt::QString::number("1," + iterator));
}
Form::~Form()
{
    delete ui;
}
