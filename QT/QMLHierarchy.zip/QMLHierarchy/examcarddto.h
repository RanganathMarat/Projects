#ifndef ExamcardDTO_HEADER
#define ExamcardDTO_HEADER

#include <qobject.h>
#include <QQmlListProperty>
#include <QJsonObject>
#include<QJsonArray>
#include<QJsonDocument>

#include "dtobase.h"
#include "scansetdto.h"
#include "executionsequencedto.h"
#include "examcardpropertydto.h"

class ExamCardDTO : public ElementBase
{
    Q_OBJECT
private:    

    ExamCardPropertyDTO* _examCardProperty;
    Q_PROPERTY (ExamCardPropertyDTO* ExamCardProperty READ ExamCardProperty WRITE SetExamCardProperty NOTIFY ExamCardPropertyChanged);

    QString _name;
    Q_PROPERTY (QString Name READ Name WRITE SetName NOTIFY NameChanged);

    QString _examCardDescription;
    Q_PROPERTY (QString ExamCardDescription READ ExamCardDescription WRITE SetExamCardDescription NOTIFY ExamCardDescriptionChanged);

public:
    ExamCardDTO::ExamCardDTO()
    { }
    virtual ~ExamCardDTO()
    { }

    ExamCardPropertyDTO* ExamCardProperty()
    {
        return _examCardProperty;
    }

    QString Name()
    {
        return _name;
    }

    QString ExamCardDescription()
    {
        return _examCardDescription;
    }

    void ExamCardDTO::Deserialize(const QJsonObject &json)
    {
        SetName(json["Name"].toString());

        SetExamCardDescription(json["ExamCardDescription"].toString());

        //Deserialze ExamCardPropertyDTO
        ExamCardPropertyDTO *ep = new ExamCardPropertyDTO();
        ep->Deserialize(json["ExamCardProperty"].toObject());
        SetExamCardProperty(ep);

        //Deserialze Child Nodes
        QJsonArray childArray = json["ChildElements"].toArray();        
        for (int childIndex = 0; childIndex < childArray.size(); ++childIndex)
        {
            QJsonObject scansetObject = childArray[childIndex].toObject();
            ScanSetDTO *scanSet = new ScanSetDTO();
                scanSet->Deserialize(scansetObject);
                this->ChildElements()->append(scanSet);
        }
    }

public slots:

    void SetExamCardProperty(ExamCardPropertyDTO* arg)
    {
        _examCardProperty = arg;
        this->ExamCardPropertyChanged(arg);
    }

    void SetName(QString arg)
    {
        if(_name != arg) {
            _name = arg;
            this->NameChanged(arg);
        }
    }

    void SetExamCardDescription(QString arg)
    {
        if(_examCardDescription != arg) {
            _examCardDescription = arg;
            this->ExamCardDescriptionChanged(arg);
        }
    }

signals:

    void ExamCardPropertyChanged(ExamCardPropertyDTO* arg);

    void NameChanged(QString arg);

    void ExamCardDescriptionChanged(QString arg);

};

#endif
