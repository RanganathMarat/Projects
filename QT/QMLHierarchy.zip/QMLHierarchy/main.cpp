#include <QApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QtQml>
#include<qjsondocument.h>
#include <QJsonObject>

#include "codebehind.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    qRegisterMetaType<QString*>("QString*");
    qmlRegisterType<ElementBase>("DTOLibrary", 1,0, "DTOBase");
    qmlRegisterType<CellInfoDTO>("DTOLibrary", 1,0, "CellInfoDTO");
    qmlRegisterType<ExecutionSequenceDTO>("DTOLibrary", 1,0, "ExecutionSequenceDTO");
    qmlRegisterType<ScanSetDTO>("DTOLibrary", 1,0, "ScanSetDTO");
    qmlRegisterType<ExamCardDTO>("DTOLibrary", 1,0, "ExamCardDTO");
    qmlRegisterType<ExamCardPropertyDTO>("DTOLibrary", 1,0, "ExamCardPropertyDTO");
    qmlRegisterType<ObservableCollection>("DTOLibrary", 1,0, "ObservableCollection");

    QQmlApplicationEngine engine;

    engine.load(QUrl(QStringLiteral("qrc:/main.qml")));

    CodeBehind * cb = new CodeBehind();
    engine.rootContext()->setContextProperty("mainmodel",cb);

    return app.exec();
}
