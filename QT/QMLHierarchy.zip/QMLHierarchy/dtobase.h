#ifndef DTOBase_HEADER
#define DTOBase_HEADER

#include <qobject.h>
#include <QQmlListProperty>
#include "observablecollection.h"

class DTOBase : public QObject
{
    Q_OBJECT
private:

public:
    DTOBase::DTOBase()
    {

    }
    virtual ~DTOBase()
    {

    }

    virtual void Deserialize(const QJsonObject &json)
    {
    }


public slots:

signals:

};

class ElementBase : public DTOBase
{
    Q_OBJECT
private:
    ObservableCollection *_childElements;
    Q_PROPERTY (ObservableCollection* ChildElements READ ChildElements NOTIFY ChildElementsChanged);

public:
    ElementBase::ElementBase()
    {
        _childElements = new ObservableCollection(this);
    }
    virtual ~ElementBase()
    {
        _childElements->clear();
    }

    ObservableCollection* ChildElements()
    {
        return _childElements;
    }

public slots:

signals:
    void ChildElementsChanged(ObservableCollection* arg);
};

//workaround to "Enum class"
class Core : public QObject
{
    Q_OBJECT
    Q_ENUMS(EditFields)
    Q_ENUMS(SmartPlanType)
private:

public:
    Core::Core()
    {
    }
    virtual ~Core()
    {
    }

    enum EditFields
    {
        None = 0,
        Settings = 1,
        Name = 2,
        GeometryName = 3,
        GeoLink = 4,
        Laterality = 5,
    };
    enum SmartPlanType
    {
        AWPLAN_SMARTPLAN_TYPE_MIN = -1,
        AWPLAN_SMARTPLAN_TYPE_NONE = 0,
        AWPLAN_SMARTPLAN_TYPE_BRAIN = 1,
        AWPLAN_SMARTPLAN_TYPE_KNEE = 2,
        AWPLAN_SMARTPLAN_TYPE_BOTH_KNEES = 3,
        AWPLAN_SMARTPLAN_TYPE_C_SPINE = 4,
        AWPLAN_SMARTPLAN_TYPE_T_SPINE = 5,
        AWPLAN_SMARTPLAN_TYPE_L_SPINE = 6,
        AWPLAN_SMARTPLAN_TYPE_TOTAL_SPINE = 7,
        AWPLAN_SMARTPLAN_TYPE_SHOULDER = 8,
        AWPLAN_SMARTPLAN_TYPE_ANKLE = 9,
        AWPLAN_SMARTPLAN_TYPE_BOTH_ANKLES = 10,
        AWPLAN_SMARTPLAN_TYPE_WRIST = 11,
        AWPLAN_SMARTPLAN_TYPE_BREASTS = 12,
        AWPLAN_SMARTPLAN_TYPE_BRAIN_ANGIO = 13,
        AWPLAN_SMARTPLAN_TYPE_CARDIAC_GLOBAL = 14,
        AWPLAN_SMARTPLAN_TYPE_CARDIAC_LOCAL = 15,
        AWPLAN_SMARTPLAN_TYPE_HIP = 16,
        AWPLAN_SMARTPLAN_TYPE_BOTH_HIPS = 17,
        AWPLAN_SMARTPLAN_TYPE_ABDOMEN = 18,
        AWPLAN_SMARTPLAN_TYPE_PELVIS = 19,
        AWPLAN_SMARTPLAN_TYPE_RESEARCH = 20,
        AWPLAN_SMARTPLAN_TYPE_MAX = 21,
    };

public slots:

signals:

};


#endif
