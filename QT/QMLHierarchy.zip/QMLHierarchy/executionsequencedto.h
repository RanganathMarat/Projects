#ifndef ExecutionSequenceDTO_HEADER
#define ExecutionSequenceDTO_HEADER

#include <qobject.h>
#include <QQmlListProperty>
#include <QJsonObject>
#include<QJsonArray>

#include "dtobase.h"
#include "cellinfodto.h"
#include "geometrydto.h"


class ExecutionSequenceDTO : public ElementBase
{
    Q_OBJECT
private:

    bool _contrast;
    Q_PROPERTY (bool Contrast READ Contrast WRITE SetContrast NOTIFY ContrastChanged);

//    CipDTO* _contrastInjectionProtocol;
//    Q_PROPERTY (CipDTO* ContrastInjectionProtocol READ ContrastInjectionProtocol WRITE SetContrastInjectionProtocol NOTIFY ContrastInjectionProtocolChanged);

    bool _contrastInjectionEnabled;
    Q_PROPERTY (bool ContrastInjectionEnabled READ ContrastInjectionEnabled WRITE SetContrastInjectionEnabled NOTIFY ContrastInjectionEnabledChanged);

    CellInfoDTO* _currentSetting;
    Q_PROPERTY (CellInfoDTO* CurrentSetting READ CurrentSetting WRITE SetCurrentSetting NOTIFY CurrentSettingChanged);

    bool _manualStart;
    Q_PROPERTY (bool ManualStart READ ManualStart WRITE SetManualStart NOTIFY ManualStartChanged);

    bool _isFirst;
    Q_PROPERTY (bool IsFirst READ IsFirst WRITE SetIsFirst NOTIFY IsFirstChanged);

    bool _breathHold;
    Q_PROPERTY (bool BreathHold READ BreathHold WRITE SetBreathHold NOTIFY BreathHoldChanged);

    CellInfoDTO* _scanDelayMode;
    Q_PROPERTY (CellInfoDTO* ScanDelayMode READ ScanDelayMode WRITE SetScanDelayMode NOTIFY ScanDelayModeChanged);

    CellInfoDTO* _scanDelay;
    Q_PROPERTY (CellInfoDTO* ScanDelay READ ScanDelay WRITE SetScanDelay NOTIFY ScanDelayChanged);

    CellInfoDTO* _numberOfDynamics;
    Q_PROPERTY (CellInfoDTO* NumberOfDynamics READ NumberOfDynamics WRITE SetNumberOfDynamics NOTIFY NumberOfDynamicsChanged);

    double _stepDuration;
    Q_PROPERTY (double StepDuration READ StepDuration WRITE SetStepDuration NOTIFY StepDurationChanged);

    int _primaryProgress;
    Q_PROPERTY (int PrimaryProgress READ PrimaryProgress WRITE SetPrimaryProgress NOTIFY PrimaryProgressChanged);

    int _secondaryProgress;
    Q_PROPERTY (int SecondaryProgress READ SecondaryProgress WRITE SetSecondaryProgress NOTIFY SecondaryProgressChanged);

    CellInfoDTO* _tableWillMove;
    Q_PROPERTY (CellInfoDTO* TableWillMove READ TableWillMove WRITE SetTableWillMove NOTIFY TableWillMoveChanged);

    bool _readOnly;
    Q_PROPERTY (bool ReadOnly READ ReadOnly WRITE SetReadOnly NOTIFY ReadOnlyChanged);

    CellInfoDTO* _name;
    Q_PROPERTY (CellInfoDTO* Name READ Name WRITE SetName NOTIFY NameChanged);

    QString _smartGeoType;
    Q_PROPERTY (QString SmartGeoType READ SmartGeoType WRITE SetSmartGeoType NOTIFY SmartGeoTypeChanged);

    QString _smartScoutType;
    Q_PROPERTY (QString SmartScoutType READ SmartScoutType WRITE SetSmartScoutType NOTIFY SmartScoutTypeChanged);

    CellInfoDTO* _geometryId;
    Q_PROPERTY (CellInfoDTO* GeometryId READ GeometryId WRITE SetGeometryId NOTIFY GeometryIdChanged);

    bool _reuseStackSizes;
    Q_PROPERTY (bool ReuseStackSizes READ ReuseStackSizes WRITE SetReuseStackSizes NOTIFY ReuseStackSizesChanged);

//    TransferPropertyDTO* _transferProperty;
//    Q_PROPERTY (TransferPropertyDTO* TransferProperty READ TransferProperty WRITE SetTransferProperty NOTIFY TransferPropertyChanged);

    CellInfoDTO* _geoLinkId;
    Q_PROPERTY (CellInfoDTO* GeoLinkId READ GeoLinkId WRITE SetGeoLinkId NOTIFY GeoLinkIdChanged);

    bool _isPreScan;
    Q_PROPERTY (bool IsPreScan READ IsPreScan WRITE SetIsPreScan NOTIFY IsPreScanChanged);

    CellInfoDTO* _currentState;
    Q_PROPERTY (CellInfoDTO* CurrentState READ CurrentState WRITE SetCurrentState NOTIFY CurrentStateChanged);

    QString _scanNumber;
    Q_PROPERTY (QString ScanNumber READ ScanNumber WRITE SetScanNumber NOTIFY ScanNumberChanged);

    QString _anatomy;
    Q_PROPERTY (QString Anatomy READ Anatomy WRITE SetAnatomy NOTIFY AnatomyChanged);

    QString _anatomicalRegion;
    Q_PROPERTY (QString AnatomicalRegion READ AnatomicalRegion WRITE SetAnatomicalRegion NOTIFY AnatomicalRegionChanged);

    double _attainedSED;
    Q_PROPERTY (double AttainedSED READ AttainedSED WRITE SetAttainedSED NOTIFY AttainedSEDChanged);

    double _predictedSED;
    Q_PROPERTY (double PredictedSED READ PredictedSED WRITE SetPredictedSED NOTIFY PredictedSEDChanged);

    CellInfoDTO* _laterality;
    Q_PROPERTY (CellInfoDTO* Laterality READ Laterality WRITE SetLaterality NOTIFY LateralityChanged);

    bool _highSarPnsLevel;
    Q_PROPERTY (bool HighSarPnsLevel READ HighSarPnsLevel WRITE SetHighSarPnsLevel NOTIFY HighSarPnsLevelChanged);

    ObservableCollection* _settingsList;
    Q_PROPERTY (ObservableCollection* SettingsList READ SettingsList WRITE SetSettingsList NOTIFY SettingsListChanged);

    bool _inputModeEnabled;
    Q_PROPERTY (bool InputModeEnabled READ InputModeEnabled WRITE SetInputModeEnabled NOTIFY InputModeEnabledChanged);

    bool _inputModeSelected;
    Q_PROPERTY (bool InputModeSelected READ InputModeSelected WRITE SetInputModeSelected NOTIFY InputModeSelectedChanged);

    bool _inputModeVisible;
    Q_PROPERTY (bool InputModeVisible READ InputModeVisible WRITE SetInputModeVisible NOTIFY InputModeVisibleChanged);

    bool _showExtendedParameter;
    Q_PROPERTY (bool ShowExtendedParameter READ ShowExtendedParameter WRITE SetShowExtendedParameter NOTIFY ShowExtendedParameterChanged);

    Core::EditFields _currentEditField;
    Q_PROPERTY (Core::EditFields CurrentEditField READ CurrentEditField WRITE SetCurrentEditField NOTIFY CurrentEditFieldChanged);

    bool _isPlannedScan;
    Q_PROPERTY (bool IsPlannedScan READ IsPlannedScan WRITE SetIsPlannedScan NOTIFY IsPlannedScanChanged);

    bool _isInEditMode;
    Q_PROPERTY (bool IsInEditMode READ IsInEditMode WRITE SetIsInEditMode NOTIFY IsInEditModeChanged);

public:
    ExecutionSequenceDTO::ExecutionSequenceDTO()
    { }
    virtual ~ExecutionSequenceDTO()
    { }

    bool Contrast()
    {
        return _contrast;
    }

//    CipDTO* ContrastInjectionProtocol()
//    {
//        return _contrastInjectionProtocol;
//    }

    bool ContrastInjectionEnabled()
    {
        return _contrastInjectionEnabled;
    }

    CellInfoDTO* CurrentSetting()
    {
        return _currentSetting;
    }

    bool ManualStart()
    {
        return _manualStart;
    }

    bool IsFirst()
    {
        return _isFirst;
    }

    bool BreathHold()
    {
        return _breathHold;
    }

    CellInfoDTO* ScanDelayMode()
    {
        return _scanDelayMode;
    }

    CellInfoDTO* ScanDelay()
    {
        return _scanDelay;
    }

    CellInfoDTO* NumberOfDynamics()
    {
        return _numberOfDynamics;
    }

    double StepDuration()
    {
        return _stepDuration;
    }

    int PrimaryProgress()
    {
        return _primaryProgress;
    }

    int SecondaryProgress()
    {
        return _secondaryProgress;
    }

    CellInfoDTO* TableWillMove()
    {
        return _tableWillMove;
    }

    bool ReadOnly()
    {
        return _readOnly;
    }

    CellInfoDTO* Name()
    {
        return _name;
    }

    QString SmartGeoType()
    {
        return _smartGeoType;
    }

    QString SmartScoutType()
    {
        return _smartScoutType;
    }

    CellInfoDTO* GeometryId()
    {
        return _geometryId;
    }

    bool ReuseStackSizes()
    {
        return _reuseStackSizes;
    }

//    TransferPropertyDTO* TransferProperty()
//    {
//        return _transferProperty;
//    }

    CellInfoDTO* GeoLinkId()
    {
        return _geoLinkId;
    }

    bool IsPreScan()
    {
        return _isPreScan;
    }

    CellInfoDTO* CurrentState()
    {
        return _currentState;
    }

    QString ScanNumber()
    {
        return _scanNumber;
    }

    QString Anatomy()
    {
        return _anatomy;
    }

    QString AnatomicalRegion()
    {
        return _anatomicalRegion;
    }

    double AttainedSED()
    {
        return _attainedSED;
    }

    double PredictedSED()
    {
        return _predictedSED;
    }

    CellInfoDTO* Laterality()
    {
        return _laterality;
    }

    bool HighSarPnsLevel()
    {
        return _highSarPnsLevel;
    }

    ObservableCollection* SettingsList()
    {
        return _settingsList;
    }

    bool InputModeEnabled()
    {
        return _inputModeEnabled;
    }

    bool InputModeSelected()
    {
        return _inputModeSelected;
    }

    bool InputModeVisible()
    {
        return _inputModeVisible;
    }

    bool ShowExtendedParameter()
    {
        return _showExtendedParameter;
    }

    Core::EditFields CurrentEditField()
    {
        return _currentEditField;
    }

    bool IsPlannedScan()
    {
        return _isPlannedScan;
    }

    bool IsInEditMode()
    {
        return _isInEditMode;
    }

public slots:

    void SetContrast(bool arg)
    {
        if(_contrast != arg) {
            _contrast = arg;
            this->ContrastChanged(arg);
        }
    }

//    void SetContrastInjectionProtocol(CipDTO* arg)
//    {
//        if(_contrastInjectionProtocol != arg) {
//            _contrastInjectionProtocol = arg;
//            this->ContrastInjectionProtocolChanged(arg);
//        }
//    }

    void SetContrastInjectionEnabled(bool arg)
    {
        if(_contrastInjectionEnabled != arg) {
            _contrastInjectionEnabled = arg;
            this->ContrastInjectionEnabledChanged(arg);
        }
    }

    void SetCurrentSetting(CellInfoDTO* arg)
    {
        if(_currentSetting != arg) {
            _currentSetting = arg;
            this->CurrentSettingChanged(arg);
        }
    }

    void SetManualStart(bool arg)
    {
        if(_manualStart != arg) {
            _manualStart = arg;
            this->ManualStartChanged(arg);
        }
    }

    void SetIsFirst(bool arg)
    {
        if(_isFirst != arg) {
            _isFirst = arg;
            this->IsFirstChanged(arg);
        }
    }

    void SetBreathHold(bool arg)
    {
        if(_breathHold != arg) {
            _breathHold = arg;
            this->BreathHoldChanged(arg);
        }
    }

    void SetScanDelayMode(CellInfoDTO* arg)
    {
        if(_scanDelayMode != arg) {
            _scanDelayMode = arg;
            this->ScanDelayModeChanged(arg);
        }
    }

    void SetScanDelay(CellInfoDTO* arg)
    {
        if(_scanDelay != arg) {
            _scanDelay = arg;
            this->ScanDelayChanged(arg);
        }
    }

    void SetNumberOfDynamics(CellInfoDTO* arg)
    {
        if(_numberOfDynamics != arg) {
            _numberOfDynamics = arg;
            this->NumberOfDynamicsChanged(arg);
        }
    }

    void SetStepDuration(double arg)
    {
        if(_stepDuration != arg) {
            _stepDuration = arg;
            this->StepDurationChanged(arg);
        }
    }

    void SetPrimaryProgress(int arg)
    {
        if(_primaryProgress != arg) {
            _primaryProgress = arg;
            this->PrimaryProgressChanged(arg);
        }
    }

    void SetSecondaryProgress(int arg)
    {
        if(_secondaryProgress != arg) {
            _secondaryProgress = arg;
            this->SecondaryProgressChanged(arg);
        }
    }

    void SetTableWillMove(CellInfoDTO* arg)
    {
        if(_tableWillMove != arg) {
            _tableWillMove = arg;
            this->TableWillMoveChanged(arg);
        }
    }

    void SetReadOnly(bool arg)
    {
        if(_readOnly != arg) {
            _readOnly = arg;
            this->ReadOnlyChanged(arg);
        }
    }

    void SetName(CellInfoDTO* arg)
    {
        if(_name != arg) {
            _name = arg;
            this->NameChanged(arg);
        }
    }

    void SetSmartGeoType(QString arg)
    {
        if(_smartGeoType != arg) {
            _smartGeoType = arg;
            this->SmartGeoTypeChanged(arg);
        }
    }

    void SetSmartScoutType(QString arg)
    {
        if(_smartScoutType != arg) {
            _smartScoutType = arg;
            this->SmartScoutTypeChanged(arg);
        }
    }

    void SetGeometryId(CellInfoDTO* arg)
    {
        if(_geometryId != arg) {
            _geometryId = arg;
            this->GeometryIdChanged(arg);
        }
    }

    void SetReuseStackSizes(bool arg)
    {
        if(_reuseStackSizes != arg) {
            _reuseStackSizes = arg;
            this->ReuseStackSizesChanged(arg);
        }
    }

//    void SetTransferProperty(TransferPropertyDTO* arg)
//    {
//        if(_transferProperty != arg) {
//            _transferProperty = arg;
//            this->TransferPropertyChanged(arg);
//        }
//    }

    void SetGeoLinkId(CellInfoDTO* arg)
    {
        if(_geoLinkId != arg) {
            _geoLinkId = arg;
            this->GeoLinkIdChanged(arg);
        }
    }

    void SetIsPreScan(bool arg)
    {
        if(_isPreScan != arg) {
            _isPreScan = arg;
            this->IsPreScanChanged(arg);
        }
    }

    void SetCurrentState(CellInfoDTO* arg)
    {
        if(_currentState != arg) {
            _currentState = arg;
            this->CurrentStateChanged(arg);
        }
    }

    void SetScanNumber(QString arg)
    {
        if(_scanNumber != arg) {
            _scanNumber = arg;
            this->ScanNumberChanged(arg);
        }
    }

    void SetAnatomy(QString arg)
    {
        if(_anatomy != arg) {
            _anatomy = arg;
            this->AnatomyChanged(arg);
        }
    }

    void SetAnatomicalRegion(QString arg)
    {
        if(_anatomicalRegion != arg) {
            _anatomicalRegion = arg;
            this->AnatomicalRegionChanged(arg);
        }
    }

    void SetAttainedSED(double arg)
    {
        if(_attainedSED != arg) {
            _attainedSED = arg;
            this->AttainedSEDChanged(arg);
        }
    }

    void SetPredictedSED(double arg)
    {
        if(_predictedSED != arg) {
            _predictedSED = arg;
            this->PredictedSEDChanged(arg);
        }
    }

    void SetLaterality(CellInfoDTO* arg)
    {
        if(_laterality != arg) {
            _laterality = arg;
            this->LateralityChanged(arg);
        }
    }

    void SetHighSarPnsLevel(bool arg)
    {
        if(_highSarPnsLevel != arg) {
            _highSarPnsLevel = arg;
            this->HighSarPnsLevelChanged(arg);
        }
    }

    void SetSettingsList(ObservableCollection* arg)
    {
        if(_settingsList != arg) {
            _settingsList = arg;
            this->SettingsListChanged(arg);
        }
    }

    void SetInputModeEnabled(bool arg)
    {
        if(_inputModeEnabled != arg) {
            _inputModeEnabled = arg;
            this->InputModeEnabledChanged(arg);
        }
    }

    void SetInputModeSelected(bool arg)
    {
        if(_inputModeSelected != arg) {
            _inputModeSelected = arg;
            this->InputModeSelectedChanged(arg);
        }
    }

    void SetInputModeVisible(bool arg)
    {
        if(_inputModeVisible != arg) {
            _inputModeVisible = arg;
            this->InputModeVisibleChanged(arg);
        }
    }

    void SetShowExtendedParameter(bool arg)
    {
        if(_showExtendedParameter != arg) {
            _showExtendedParameter = arg;
            this->ShowExtendedParameterChanged(arg);
        }
    }

    void SetCurrentEditField(Core::EditFields arg)
    {
        if(_currentEditField != arg) {
            _currentEditField = arg;
            this->CurrentEditFieldChanged(arg);
        }
    }

    void SetIsPlannedScan(bool arg)
    {
        if(_isPlannedScan != arg) {
            _isPlannedScan = arg;
            this->IsPlannedScanChanged(arg);
        }
    }

    void SetIsInEditMode(bool arg)
    {
        if(_isInEditMode != arg) {
            _isInEditMode = arg;
            this->IsInEditModeChanged(arg);
        }
    }

    void ExecutionSequenceDTO::Deserialize(const QJsonObject &json)
    {
        CellInfoDTO *cDTO = new CellInfoDTO();
        cDTO->Deserialize<QString>(json["Name"].toObject());
        SetName(cDTO);

        cDTO = new CellInfoDTO();
        cDTO->Deserialize<GeometryDTO>(json["GeometryId"].toObject());
        SetGeometryId(cDTO);

        cDTO = new CellInfoDTO();
        cDTO->Deserialize<QString>(json["GeoLinkId"].toObject());
        SetGeoLinkId(cDTO);

        SetScanNumber(json["ScanNumber"].toString());


        this->ChildElements()->clear();
        QJsonArray childArray = json["ChildElements"].toArray();
        for (int childIndex = 0; childIndex < childArray.size(); ++childIndex)
        {
            // Implement ProcessingSteps
        }
    }

signals:

    void ContrastChanged(bool arg);

//    void ContrastInjectionProtocolChanged(CipDTO* arg);

    void ContrastInjectionEnabledChanged(bool arg);

    void CurrentSettingChanged(CellInfoDTO* arg);

    void ManualStartChanged(bool arg);

    void IsFirstChanged(bool arg);

    void BreathHoldChanged(bool arg);

    void ScanDelayModeChanged(CellInfoDTO* arg);

    void ScanDelayChanged(CellInfoDTO* arg);

    void NumberOfDynamicsChanged(CellInfoDTO* arg);

    void StepDurationChanged(double arg);

    void PrimaryProgressChanged(int arg);

    void SecondaryProgressChanged(int arg);

    void TableWillMoveChanged(CellInfoDTO* arg);

    void ReadOnlyChanged(bool arg);

    void NameChanged(CellInfoDTO* arg);

    void SmartGeoTypeChanged(QString arg);

    void SmartScoutTypeChanged(QString arg);

    void GeometryIdChanged(CellInfoDTO* arg);

    void ReuseStackSizesChanged(bool arg);

//    void TransferPropertyChanged(TransferPropertyDTO* arg);

    void GeoLinkIdChanged(CellInfoDTO* arg);

    void IsPreScanChanged(bool arg);

    void CurrentStateChanged(CellInfoDTO* arg);

    void ScanNumberChanged(QString arg);

    void AnatomyChanged(QString arg);

    void AnatomicalRegionChanged(QString arg);

    void AttainedSEDChanged(double arg);

    void PredictedSEDChanged(double arg);

    void LateralityChanged(CellInfoDTO* arg);

    void HighSarPnsLevelChanged(bool arg);

    void SettingsListChanged(ObservableCollection* arg);

    void InputModeEnabledChanged(bool arg);

    void InputModeSelectedChanged(bool arg);

    void InputModeVisibleChanged(bool arg);

    void ShowExtendedParameterChanged(bool arg);

    void CurrentEditFieldChanged(Core::EditFields arg);

    void IsPlannedScanChanged(bool arg);

    void IsInEditModeChanged(bool arg);

};
#endif
