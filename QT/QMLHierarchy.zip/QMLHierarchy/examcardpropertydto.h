#ifndef ExamCardPropertyDTO_HEADER
#define ExamCardPropertyDTO_HEADER

#include <qobject.h>
#include <QQmlListProperty>
#include <QJsonObject>
#include<QJsonArray>
#include<qdebug.h>

#include "dtobase.h"
#include "geometrydto.h"

class ExamCardPropertyDTO : public DTOBase
{
    Q_OBJECT
private:
    ObservableCollection* _namedGeometries;
    Q_PROPERTY (ObservableCollection* NamedGeometries READ NamedGeometries WRITE SetNamedGeometries NOTIFY NamedGeometriesChanged);
public:
    ExamCardPropertyDTO::ExamCardPropertyDTO()
    {
        _namedGeometries = new ObservableCollection(this);
    }
    virtual ~ExamCardPropertyDTO()
    { }

    ObservableCollection* NamedGeometries()
    {
        //qDebug()<<"NamedGeometries : "<<_namedGeometries->count();
        return _namedGeometries;
    }

    void ExamCardPropertyDTO::Deserialize(const QJsonObject &json)
    {
        this->NamedGeometries()->clear();
        QJsonArray geoArray = json["NamedGeometries"].toArray();
        for (int childIndex = 0; childIndex < geoArray.size(); ++childIndex)
        {
            QJsonObject geoObj = geoArray[childIndex].toObject();
            GeometryDTO *geo = new GeometryDTO();
            geo->Deserialize(geoObj);
            this->NamedGeometries()->append((QObject*)geo);
        }
    }

public slots:

    void SetNamedGeometries(ObservableCollection* arg)
    {
        if(_namedGeometries != arg) {
            _namedGeometries = arg;
            this->NamedGeometriesChanged(arg);
        }
    }

signals:

    void NamedGeometriesChanged(ObservableCollection* arg);

};

#endif
