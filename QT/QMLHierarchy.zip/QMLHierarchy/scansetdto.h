#ifndef ScanSetDTO_HEADER
#define ScanSetDTO_HEADER

#include <qobject.h>
#include <QQmlListProperty>
#include <QJsonObject>
#include<QJsonArray>
#include<QJsonDocument>

#include "dtobase.h"
#include "executionsequencedto.h"

class ScanSetDTO : public ElementBase
{
    Q_OBJECT
private:

    QByteArray oldJson;
    bool _editMode;
    Q_PROPERTY (bool EditMode READ EditMode WRITE SetEditMode NOTIFY EditModeChanged);

public:
    ScanSetDTO::ScanSetDTO()
    { }
    virtual ~ScanSetDTO()
    { }

    bool EditMode()
    {
        return _editMode;
    }

    void ScanSetDTO::Deserialize(const QJsonObject &json)
    {

        SetEditMode(json["EditMode"].toBool());

        //Deserialze Child Nodes
        this->ChildElements()->clear();
        QJsonArray childArray = json["ChildElements"].toArray();
        for (int childIndex = 0; childIndex < childArray.size(); ++childIndex)
        {
            QJsonObject ecStepObject = childArray[childIndex].toObject();
            ExecutionSequenceDTO *ecStep = new ExecutionSequenceDTO();
            ecStep->Deserialize(ecStepObject);
            this->ChildElements()->append(ecStep);
        }
    }

public slots:

    void SetEditMode(bool arg)
    {
        if(_editMode != arg) {
            _editMode = arg;
            this->EditModeChanged(arg);
        }
    }

signals:

    void EditModeChanged(bool arg);

};
#endif
