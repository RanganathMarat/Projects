#ifndef CellInfoDTO_HEADER
#define CellInfoDTO_HEADER

#include <qobject.h>
#include <QQmlListProperty>
#include <QJsonObject>
#include<QJsonArray>
#include<qdebug.h>

#include "dtobase.h"

class CellInfoDTO : public DTOBase
{
    Q_OBJECT
private:

    QObject* _value;
    Q_PROPERTY (QObject* Value READ Value WRITE SetValue NOTIFY ValueChanged);

    QString _string;
    Q_PROPERTY (QString String READ String WRITE SetString NOTIFY StringChanged);

    bool _canChange;
    Q_PROPERTY (bool CanChange READ CanChange WRITE SetCanChange NOTIFY CanChangeChanged);

    QString _description;
    Q_PROPERTY (QString Description READ Description WRITE SetDescription NOTIFY DescriptionChanged);

public:
    CellInfoDTO::CellInfoDTO()
    { }
    CellInfoDTO::CellInfoDTO(QObject *obj)
    {
        SetValue(obj);
    }
    CellInfoDTO::CellInfoDTO(QString obj)
    {
        SetString(obj);
    }
    virtual ~CellInfoDTO()
    { }

    QString String()
    {
        return _string;
    }

    QObject* Value()
    {
        return _value;
    }

    bool CanChange()
    {
        return _canChange;
    }

    QString Description()
    {
        return _description;
    }

    template <typename T>
    void Deserialize(const QJsonObject &json)
    {
        if(json["Value"].isString())
        {
            //qDebug()<<json["Value"].toString();
            SetString(json["Value"].toString());
        }
        else if(json["Value"].isDouble())
        {
            //qDebug()<<json["Value"].toDouble();
            SetString(QString::number(json["Value"].toDouble()));
        }
        else if(json["Value"].isObject())
        {
            T* newObj = new T();
            ((DTOBase*)newObj)->Deserialize(json["Value"].toObject());
            SetValue((QObject*)newObj);
        }

        SetCanChange(json["CanChange"].toBool());

        SetDescription(json["Description"].toString());
    }

public slots:

    void SetString(QString arg)
    {
        if(_string != arg) {
            _string = arg;
            this->StringChanged(arg);
        }
    }

    void SetValue(QObject* arg)
    {
        if(_value != arg) {
            _value = arg;
            this->ValueChanged(arg);
        }
    }

    void SetCanChange(bool arg)
    {
        if(_canChange != arg) {
            _canChange = arg;
            this->CanChangeChanged(arg);
        }
    }

    void SetDescription(QString arg)
    {
        if(_description != arg) {
            _description = arg;
            this->DescriptionChanged(arg);
        }
    }

signals:

    void StringChanged(QString arg);

    void ValueChanged(QObject* arg);

    void CanChangeChanged(bool arg);

    void DescriptionChanged(QString arg);

};
#endif
