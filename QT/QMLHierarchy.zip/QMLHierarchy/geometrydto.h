#ifndef GeometryDTO_HEADER
#define GeometryDTO_HEADER

#include <qobject.h>
#include <QQmlListProperty>
#include <QJsonObject>
#include<QJsonArray>
#include<qdebug.h>

#include "dtobase.h"

class GeometryDTO : public DTOBase
{
    Q_OBJECT
private:

    QString _geometryDescription;
    Q_PROPERTY (QString GeometryDescription READ GeometryDescription WRITE SetGeometryDescription NOTIFY GeometryDescriptionChanged);

    QString _name;
    Q_PROPERTY (QString Name READ Name WRITE SetName NOTIFY NameChanged);

    QString _smartPlanDescription;
    Q_PROPERTY (QString SmartPlanDescription READ SmartPlanDescription WRITE SetSmartPlanDescription NOTIFY SmartPlanDescriptionChanged);

    int _smartPlanLearnStatus;
    Q_PROPERTY (int SmartPlanLearnStatus READ SmartPlanLearnStatus WRITE SetSmartPlanLearnStatus NOTIFY SmartPlanLearnStatusChanged);

    Core::SmartPlanType _smartPlanType;
    Q_PROPERTY (Core::SmartPlanType SmartPlanType READ SmartPlanType WRITE SetSmartPlanType NOTIFY SmartPlanTypeChanged);

public:
    GeometryDTO::GeometryDTO()
    { }
    virtual ~GeometryDTO()
    { }

    QString GeometryDescription()
    {
        return _geometryDescription;
    }

    QString Name()
    {
        return _name;
    }

    QString SmartPlanDescription()
    {
        return _smartPlanDescription;
    }

    int SmartPlanLearnStatus()
    {
        return _smartPlanLearnStatus;
    }

    Core::SmartPlanType SmartPlanType()
    {
        return _smartPlanType;
    }

public slots:

    void SetGeometryDescription(QString arg)
    {
        if(_geometryDescription != arg) {
            _geometryDescription = arg;
            this->GeometryDescriptionChanged(arg);
        }
    }

    void SetName(QString arg)
    {
        if(_name != arg) {
            _name = arg;
            this->NameChanged(arg);
        }
    }

    void SetSmartPlanDescription(QString arg)
    {
        if(_smartPlanDescription != arg) {
            _smartPlanDescription = arg;
            this->SmartPlanDescriptionChanged(arg);
        }
    }

    void SetSmartPlanLearnStatus(int arg)
    {
        if(_smartPlanLearnStatus != arg) {
            _smartPlanLearnStatus = arg;
            this->SmartPlanLearnStatusChanged(arg);
        }
    }

    void SetSmartPlanType(Core::SmartPlanType arg)
    {
        if(_smartPlanType != arg) {
            _smartPlanType = arg;
            this->SmartPlanTypeChanged(arg);
        }
    }

    void GeometryDTO::Deserialize(const QJsonObject &json)
    {
        SetName(json["Name"].toString());


    }

signals:

    void GeometryDescriptionChanged(QString arg);

    void NameChanged(QString arg);

    void SmartPlanDescriptionChanged(QString arg);

    void SmartPlanLearnStatusChanged(int arg);

    void SmartPlanTypeChanged(Core::SmartPlanType arg);

};

#endif
