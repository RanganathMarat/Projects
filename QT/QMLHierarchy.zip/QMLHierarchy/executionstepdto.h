#ifndef ExecutionStepDTO_HEADER
#define ExecutionStepDTO_HEADER

#include <qobject.h>
#include <QQmlListProperty>
#include <QJsonObject>
#include<QJsonArray>

#include "dtobase.h"

class ExecutionStepDTO : public ElementBase
{
    Q_OBJECT

private:
    QString _scanNumber = "0,0";
    Q_PROPERTY (QString scanNumber READ GetScanNumber WRITE SetScanNumber NOTIFY ScanNumberChangedEvent);

    QString _name = "EStep";
    Q_PROPERTY (QString name READ GetName WRITE SetName NOTIFY NameChangedEvent);

public:
    ExecutionStepDTO::ExecutionStepDTO()
    {
    }

    virtual ~ExecutionStepDTO()
    { }

    QString GetName() const
    {
        return _name;
    }

    QString GetScanNumber() const
    {
        return _scanNumber;
    }

    void ExecutionStepDTO::Deserialize(const QJsonObject &json)
    {
        SetName(json["Name"].toString());
        SetScanNumber(json["ScanNumber"].toString());

        this->ChildElements()->clear();
        QJsonArray childArray = json["ChildElements"].toArray();
        for (int childIndex = 0; childIndex < childArray.size(); ++childIndex)
        {

        }
    }

public slots:
    void SetName(QString arg)
    {
        if (_name != arg) {
            _name = arg;
            NameChangedEvent(arg);
        }
    }

    void SetScanNumber(QString arg)
    {
        if (_scanNumber != arg) {
            _scanNumber = arg;
            ScanNumberChangedEvent(arg);
        }
    }

signals:
    void NameChangedEvent(QString arg);
    void ScanNumberChangedEvent(QString arg);
};
#endif
