#ifndef CodeBehind_HEADER
#define CodeBehind_HEADER

#include <qobject.h>
#include <QQmlListProperty>
#include <QElapsedTimer>
#include <qmessagebox.h>
#include<qjsondocument.h>
#include <QJsonObject>
#include<qdebug.h>
#include<qfile.h>

#include<qbasictimer.h>
#include<QTimerEvent>

#include "examcarddto.h"


class CodeBehind : public QObject
{
    Q_OBJECT

private:
    QBasicTimer timer;
    QByteArray oldJson;    
    ExamCardDTO* _examcardDTO;
    Q_PROPERTY (ExamCardDTO* examcard READ GetExamcard NOTIFY examcardChanged);

    void LoadJson()
    {
        // LOAD JSON FUNCTION
        QElapsedTimer performanceTimer;
        performanceTimer.start();
        QFile loadFile(QStringLiteral("c:\\jsonStream.txt"));
        if (!loadFile.open(QIODevice::ReadOnly)) {
            qDebug()<<"Couldn't open save file.";
            return;
        }
        QByteArray saveData = loadFile.readAll();
        // Compare with old data. Reset only if there is a change in json string
        if(saveData!=oldJson)
        {
            oldJson = saveData;
            QJsonDocument loadDoc(QJsonDocument::fromJson(saveData));
            qDebug()<<"Json parse time : "<<performanceTimer.elapsed();

                ExamCardDTO* temp = new ExamCardDTO();
                temp->Deserialize(loadDoc.object());

                _examcardDTO = temp;
                this->examcardChanged();
                qDebug()<<"Total (parse + render) time : "<<performanceTimer.elapsed();

        }
        performanceTimer.restart();

    }

public:
    CodeBehind::CodeBehind()
    {
        _examcardDTO = new ExamCardDTO();

        // Start timer to read from jsonStream file every 100ms.
        // jsonStream.txt file is updated by server every 50ms with new data(if available).
        timer.start(100, this);
    }

    virtual ~CodeBehind()
    { }

    void CodeBehind::timerEvent(QTimerEvent *event)
    {
        if (event->timerId() == timer.timerId()) {
            LoadJson();
        }
    }

    ExamCardDTO* GetExamcard() const
    {
        return _examcardDTO;
    }

    Q_INVOKABLE void AppendNewScan()
    {
        // ADD NEW SCAN
        QElapsedTimer myTimer;
        myTimer.start();
        ScanSetDTO *ss = new ScanSetDTO();
        ExecutionSequenceDTO *es = new ExecutionSequenceDTO();
        es->SetGeoLinkId(new CellInfoDTO("5"));
        GeometryDTO* gDTO = new GeometryDTO();
        gDTO->SetName("Geo1");
        es->SetGeometryId(new CellInfoDTO(gDTO));
        es->SetName(new CellInfoDTO(QString("NewScan")));
        ss->ChildElements()->append(es);
        _examcardDTO->ChildElements()->insert(1,ss);

        qDebug()<<"Increment time : "<<myTimer.elapsed();
        myTimer.restart();
    }    

    Q_INVOKABLE void ChangeNameCommand()
    {
        ((ExecutionSequenceDTO*)((ScanSetDTO*)_examcardDTO->ChildElements()->at(0))->ChildElements()->at(0))->Name()->SetString("ChangedName");
    }

public slots:


signals:
void examcardChanged();
};

#endif
