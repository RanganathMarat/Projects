#region Copyright 2014 Koninklijke Philips N.V.
//
// All rights reserved. Reproduction in whole or in part is prohibited without 
// the written consent of the copyright owner.
//
#endregion

using System;
using System.Threading;

namespace Philips.PmsMR.UI.Infra.TestTask {
    class BuildTestEventScope : IDisposable {
        public BuildTestEventScope() {
            // Set a named event to broadcast the fact that we are running tests.
            // This must be set before logging, in order to be able to deflect the file-based logging of a non-activated system.
            bool created;
            handle = new EventWaitHandle(
                false,
                EventResetMode.ManualReset,
                Interfaces.Infra.TestTask.Constants.BuildTestEventName,
                out created);
            if (created) {
                handle.Set();
            } else {
                handle.Close();
                handle = null;
            }
        }

        public void Dispose() {
            if (handle != null) {
                handle.Reset();
                handle.Close();
            }
        }

        private readonly EventWaitHandle handle;
    }
}