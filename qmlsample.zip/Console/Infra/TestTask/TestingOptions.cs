﻿#region Copyright 2014 Koninklijke Philips N.V.
//
// All rights reserved. Reproduction in whole or in part is prohibited without 
// the written consent of the copyright owner.
//
#endregion

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Philips.PmsMR.UI.Infra.TestTask {

    public enum TestCategoryType {
        Undefined,        
        Lengthy,
        /// <summary>
        /// Exclusive execution - require shared system resources.
        /// </summary>
        SystemController,
        /// <summary>
        /// Representative tests (system health test with a subset of tests).
        /// </summary>
        UnitTests,
        /// <summary>
        /// All tests for full build test.
        /// </summary>
        BuildTests
    }

    enum TestType {
        /// <summary>
        /// Unit testing of managed .NET code.
        /// </summary>
        ManagedTesting,
        /// <summary>
        /// Source code testing/reflection testing/manifestation testing on the assemblies.
        /// </summary>
        StaticTesting,
    }

    [Serializable]
    public class TestingOptions {

        public TestingOptions() {
            DeliveryDirectory =
                new DirectoryInfo(System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location));
            Repeat = 1;
        }

        public HashSet<string> TestNames;

        public List<FileInfo> AssemblyNames;

        public HashSet<TestCategoryType> TestCategoryTypes;

        /// <summary>
        /// Namespace prefixes that include all tests within the namespace.
        /// </summary>
        public List<string> NamespaceInclusions;

        public bool AbortOnFailure;

        /// <summary>
        /// Detailed logging about test execution.
        /// </summary>
        public bool Verbose;

        /// <summary>
        /// Artifical load to each (affine) processor.
        /// </summary>
        public int? ProcessorLoad;

        /// <summary>
        /// Repeated testing.
        /// </summary>
        public int Repeat;

        /// <summary>
        /// Set if profiling support needs to be enabled
        /// </summary>
        public bool Profiling { get; set; }

        public DirectoryInfo DeliveryDirectory;

        [Flags]
        public enum TestSystemTypes {
            NUnit = 0x01,
            IronPython = 0x02,
            SourceCode = 0x04,
            CommonRuntimeBinaries = 0x08
        }

        public TestSystemTypes TestSystems;

        public TestingOptions CloneForSubtask()
        {
            var retVal = new TestingOptions
            {
                AbortOnFailure = this.AbortOnFailure,
                Profiling = this.Profiling,
                Repeat = 1,
                TestSystems = this.TestSystems,
                Verbose = this.Verbose
            };
            if (AssemblyNames != null)
            {
                retVal.AssemblyNames = AssemblyNames.ToList();
            }
            if (DeliveryDirectory != null)
            {
                retVal.DeliveryDirectory = new DirectoryInfo(DeliveryDirectory.FullName);
            }
            if (NamespaceInclusions != null)
            {
                retVal.NamespaceInclusions = NamespaceInclusions.ToList();
            }
            if (TestCategoryTypes != null)
            {
                retVal.TestCategoryTypes = new HashSet<TestCategoryType>(TestCategoryTypes);
            }
            if (TestNames != null)
            {
                retVal.TestNames = new HashSet<string>(TestNames);
            }
            return retVal;
        }
    }
}
