#region Copyright 2008-2014 Koninklijke Philips N.V.
//
// All rights reserved. Reproduction in whole or in part is prohibited without 
// the written consent of the copyright owner.
//
#endregion

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Security;
using System.Reflection;
using System.Threading;
using Microsoft.Build.Framework;
using Microsoft.Build.Utilities;
using Philips.PmsMR.UI.Infra.TestTask.Log;
using Philips.PmsMR.UI.Infra.TestTask.SystemSurrogate;
using Philips.PmsMR.UI.Infra.Utilities.Misc;
using Process = System.Diagnostics.Process;

namespace Philips.PmsMR.UI.Infra.TestTask {

    /// <summary>
    /// Internal flags for requirement types.
    /// </summary>
    [Flags]
    enum ExecutionGroupRequirementTypes {
        None = 0x0,
        /// <summary>
        /// Runlevels must be down when the test starts
        /// </summary>
        ExclusiveSystemOwnership = 0x02,
        /// <summary>
        /// A mixed-mode test can raise a gmock-failure, which needs to be caught by the nunit 
        /// (i.e., needs to be converted into a nunit failure)
        /// </summary>
        GMockNeeded = 0x08,
    }

    enum TimeRequirementType {
        None,
        Lengthy
    }

    /// <summary>
    /// State the system needs to be in for some of the tests to run.
    /// </summary>
    /// <remarks>
    /// These match to category-attribute contents on special tests.
    /// </remarks>
    [Flags]
    public enum SystemStateRequirements {
        /// <summary>
        /// No system state category strings found.
        /// </summary>
        None = 0x00,
        /// <summary>
        /// "AdminRights" category string.
        /// </summary>
        AdminRights = 0x01,
        /// <summary>
        /// "Activated" category string.
        /// </summary>
        /// <remarks>
        /// For tests that require application services running on a system
        /// </remarks>
        Activated = 0x02,
        /// <summary>
        /// Test cannot be executed within msbuild, but must be hosted by testtask.exe
        /// </summary>
        /// <remarks>
        /// For example, the mixed mode code uses static variables that must reside in default appdomain.
        /// (MSBuild.exe cannot provide an editable default domain)
        /// </remarks>
        TestTaskProcess = 0x04,
        /// <summary>
        /// Test messes up static variables (the system state) and must be executed in total isolation, after which the process/appdomain is exited.
        /// </summary>
        Isolated = 0x08,
        /// <summary>
        /// Test must be executed in a non-default AppDomain.
        /// </summary>
        /// <remarks>
        ///     Note that multiple tests can be executed within the same AppDomain.
        ///     For example, this is for tests that require AppDomain DomainUnloaded-event for the final cleanup.
        /// </remarks>
        AppDomained = 0x10,
        /// <summary>
        /// Executed only if manually specificed (test selected for execution)
        /// </summary>
        ManualExecution = 0x20,
        /// <summary>
        /// Executed only if not running with admin rights.
        /// </summary>
        NoAdminRights = 0x40,
        /// <summary>
        /// Executed only in debug builds.
        /// </summary>
        DebugOnly = 0x80,
    }

    public class TestTask : AppDomainIsolatedTask, ICancelableTask {

        public TestTask() : this(null, true) {
            SetProcessAffinity();
        }

        internal TestTask(SubTestTaskParent optionalParent, bool useTaskLogger = false) {
            TaskLoggingHelper taskLogger = useTaskLogger ? this.Log : null;

            // Event scope must be created before logging
            testEventScope = new BuildTestEventScope();

            this.optionalParent = optionalParent;
            if (Logging.instance == null) {
                logger = new Logging(taskLogger);
                Logging.instance = logger;
            }
            var probing = new[] {
                Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location),
                Path.Combine(
                    Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location),
                    "..",
                    "Build",
                    "Common",
                    "Tasks")
            };
            assemblyResolver =
                new AssemblyResolver(
                    probing);
            if (optionalParent == null) {
                Manager.Instance = new Manager();
            }
        }

        public void Cancel() {
            System.Threading.Tasks.Task.Factory.StartNew(
                () => {
                    if (!Thread.CurrentThread.Join(TimeSpan.FromSeconds(4))) {
                        abortionSuppressor = new AssertSuppressor(true);
                        Logging.Instance.WriteLogErrorEntry("Failed to wait for the tests to exit");
                        Process.GetCurrentProcess().Kill();
                    }
                });

            lock (syncBlock) {
                if (tokenSource != null) {
                    Logging.instance.WriteLogInfoEntry("Cancelling the testing");
                    tokenSource.Cancel();
                }
            }
        }

        public override bool Execute() {
            bool ok = true;

            Remote.ChannelManager.Instance.EnsureChanneling();
            AppDomain.CurrentDomain.UnhandledException += OnUnhandledException;

            try {
                DateTime start = DateTime.UtcNow;

                int testerIndex = 0;
                var testers = new List<TestSystem>();
                int repeat = optionalParent == null && TestingOptions != null ? TestingOptions.Repeat : 1;
                for (int repeatIndex = 0; repeatIndex < repeat; ++repeatIndex) {

                    switch (actualTestMode) {
                        case TestMode.FastTest:
                            TestingOptions = new TestingOptions {
                                NamespaceInclusions = new List<string>(),
                                TestCategoryTypes = new HashSet<TestCategoryType> {
                                TestCategoryType.Undefined
                            },
                                TestSystems = TestingOptions.TestSystemTypes.NUnit
                            };

                            break;
                        case TestMode.SystemControllerTest:
                            TestingOptions = new TestingOptions {
                                NamespaceInclusions = new List<string>(),
                                TestCategoryTypes = new HashSet<TestCategoryType> {
                                TestCategoryType.SystemController,
                            },
                                TestSystems = TestingOptions.TestSystemTypes.NUnit
                            };

                            break;
                        case TestMode.UnitTest:
                            TestingOptions = new TestingOptions {
                                NamespaceInclusions = new List<string>(),
                                TestCategoryTypes = new HashSet<TestCategoryType> {
                                TestCategoryType.UnitTests
                            },
                                TestSystems = TestingOptions.TestSystemTypes.NUnit
                            };
                            break;
                        case TestMode.BuildTest:
                            TestingOptions = new TestingOptions {
                                NamespaceInclusions = new List<string>(),
                                TestCategoryTypes = new HashSet<TestCategoryType> {
                                TestCategoryType.BuildTests
                            },
                                TestSystems = TestingOptions.TestSystemTypes.NUnit | TestingOptions.TestSystemTypes.IronPython |
                                              TestingOptions.TestSystemTypes.SourceCode | TestingOptions.TestSystemTypes.CommonRuntimeBinaries
                            };
                            break;
                        case TestMode.ScriptTest:
                            TestingOptions = new TestingOptions {
                                NamespaceInclusions = new List<string>(),
                                TestCategoryTypes = new HashSet<TestCategoryType> {
                                TestCategoryType.BuildTests
                            },
                                TestSystems = TestingOptions.TestSystemTypes.IronPython
                            };
                            break;
                        case TestMode.SourceTest:
                            TestingOptions = new TestingOptions {
                                NamespaceInclusions = new List<string>(),
                                TestCategoryTypes = new HashSet<TestCategoryType> {
                                TestCategoryType.BuildTests
                            },
                                TestSystems = TestingOptions.TestSystemTypes.SourceCode
                            };
                            break;
                        case TestMode.ManifestTest:
                            TestingOptions = new TestingOptions {
                                NamespaceInclusions = new List<string>(),
                                TestCategoryTypes = new HashSet<TestCategoryType> {
                                TestCategoryType.BuildTests
                            },
                                TestSystems = TestingOptions.TestSystemTypes.CommonRuntimeBinaries
                            };
                            break;
                        case TestMode.NotSet:
                            // Selection comes from the command line
                            break;
                        default:
                            throw new NotImplementedException("TestMode: " + actualTestMode);
                    }

                    if ((TestingOptions.TestSystems & TestingOptions.TestSystemTypes.NUnit) != 0) {
                        testers.Add(new ManagedTestSystem(TestingOptions, tokenSource));
                    }
                    if ((TestingOptions.TestSystems & TestingOptions.TestSystemTypes.SourceCode) != 0) {
                        testers.Add(new SourceCodeTestSystem(TestingOptions, tokenSource));
                    }
                    if (Manager.Instance != null) {
                        if (TestingOptions.TestCategoryTypes.Contains(TestCategoryType.BuildTests) ||
                            TestingOptions.TestCategoryTypes.Contains(TestCategoryType.SystemController)) {
                            Manager.Instance.ProvideNonactivatedServices();
                        }
                    }

                    using (new ArtificialLoader(optionalParent == null, TestingOptions.ProcessorLoad)) {
                        if (repeat != 1) {
                            Logging.Instance.WriteLogInfoEntry(
                                String.Format(
                                    CultureInfo.InvariantCulture,
                                    "Repeat round {0}/{1}",
                                    repeatIndex + 1,
                                    repeat));
                        }
                        for (; testerIndex < testers.Count; ++testerIndex) {
                            using (testers[testerIndex].CreateCanaryScope()) {
                                if (ok || !TestingOptions.AbortOnFailure) {
                                    ok &= testers[testerIndex].Execute();
                                }
                            }
                        }
                    }
                }

                var successCount = testers.Aggregate(0, (i, system) => i + system.SuccessTestCount);
                var skipCount = testers.Aggregate(0, (i, system) => i + system.SkipCount);
                if (optionalParent != null) {
                    optionalParent.SuccessCount = successCount;
                    optionalParent.SkipCount = skipCount;
                    optionalParent.FailedTests = testers.SelectMany(x => x.FailedTests).ToList();
                }

                if (optionalParent == null) {
                    // Log summary only in the root testtask
                    var duration = DateTime.UtcNow - start;
                    var message = ok
                        ? String.Format(
                            CultureInfo.InvariantCulture,
                            "All tests succeeded (Executed {0} tests) in {1:hh\\:mm\\:ss\\.fff}.",
                            successCount,
                            duration)
                        : "Tests failed." +
                          String.Format(
                              CultureInfo.InvariantCulture,
                              " Executed {0} (skipped {1}, failed {2}) tests in {3}",
                              successCount,
                              skipCount,
                              testers.Aggregate(0, (i, system) => i + system.FailedTests.Count),
                              duration);
                    if (ok) {
                        Logging.Instance.WriteLogInfoEntry(message);
                    } else {
                        Logging.Instance.WriteLogErrorEntry(message);
                        var failedTests = testers.SelectMany(x => x.FailedTests).ToArray();
                        if (failedTests.Length > 0) {
                            Logging.Instance.WriteLogErrorEntry("Failure Summary:");
                            foreach (var failedTest in failedTests) {
                                Logging.Instance.WriteLogErrorEntry(
                                    "  Failed Test - " + failedTest);
                            }
                        } else {
                            Logging.Instance.WriteLogErrorEntry("Test framework failure.");
                        }
                    }
                } else {
                    var failedTests = testers.SelectMany(x => x.FailedTests).ToArray();
                    if (failedTests.Length < 1 && !ok) {
                        Logging.Instance.WriteLogErrorEntry("Test framework failure.");
                    }
                }
            } catch (Exception e) {
                Logging.Instance.WriteLogErrorEntry("Unexpected test framework failure: " + e);
                throw;
            } finally {
                lock (syncBlock) {
                    tokenSource.Dispose();
                    tokenSource = null;
                }

                if (Manager.Instance != null) {
                    Manager.Instance.Shutdown();
                }
                if (logger != null) {
                    Logging.instance.Dispose();
                }
                if (testEventScope != null) {
                    testEventScope.Dispose();
                }
            }
            return ok;
        }

        private void OnUnhandledException(object sender, UnhandledExceptionEventArgs e) {
            Log.LogErrorFromException((Exception)e.ExceptionObject, true, true, System.Reflection.Assembly.GetExecutingAssembly().GetName().Name);
            Logging.Instance.WriteLogErrorEntry("Unhandled exception in unit tests", e.ExceptionObject as Exception);
            Process.GetCurrentProcess().Kill();
        }

        /// <summary>
        /// Sets the process affinity, if defined.
        /// </summary>
        private void SetProcessAffinity()
        {
            var affinityMask =
                Environment.GetEnvironmentVariable(
                    Interfaces.Infra.TestTask.Constants.ProcessorAffinity);
            if (affinityMask != null)
            {
                long result;
                if (long.TryParse(affinityMask, out result))
                {
                    System.Diagnostics.Process.GetCurrentProcess().ProcessorAffinity = new IntPtr(result);
                }
            }
        }

        public enum ConfigurationType {
            Debug,
            Release
        }

        /// <summary>
        /// Modes available for msbuild execution.
        /// </summary>
        public enum TestMode {
            NotSet,
            FastTest,
            SystemControllerTest,
            SourceTest,
            ScriptTest,
            ManifestTest,
            UnitTest,
            BuildTest
        }

        [Required]
        public string Configuration {
            get { return actualConfigurationType.ToString(); }
            set { ConfigurationType.TryParse(value, out actualConfigurationType); }
        }

        [Required]
        public string TestModeSelector {
            get { return actualTestMode.ToString(); }
            set {
                TestMode.TryParse(value, out actualTestMode);
            }
        }

        public new IBuildEngine BuildEngine { get; set; }

        public new ITaskHost HostObject { get; set; }

        internal TestingOptions TestingOptions { get; set; }

        private ConfigurationType actualConfigurationType;
        private TestMode actualTestMode;
        private readonly Logging logger;

        private readonly object syncBlock = new object();
        private CancellationTokenSource tokenSource = new CancellationTokenSource();
        private readonly AssemblyResolver assemblyResolver;
        private readonly BuildTestEventScope testEventScope;
        private static AssertSuppressor abortionSuppressor;
        private readonly SubTestTaskParent optionalParent;
    }
}

