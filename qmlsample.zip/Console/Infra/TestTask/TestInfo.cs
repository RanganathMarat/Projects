#region Copyright 2014 Koninklijke Philips N.V.
//
// All rights reserved. Reproduction in whole or in part is prohibited without 
// the written consent of the copyright owner.
//
#endregion

using System.Collections.Generic;
using System.IO;
using NUnit.Framework.Interfaces;

namespace Philips.PmsMR.UI.Infra.TestTask {
    class TestInfo {
        public FileInfo Assembly;
        public IEnumerable<ITest> TestCases;
    }
}