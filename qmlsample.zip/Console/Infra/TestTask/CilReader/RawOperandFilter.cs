﻿#region Copyright Koninklijke Philips Electronics N.V. 2013
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
#endregion

using System;
using System.Collections.Generic;
using System.Linq;

namespace Philips.PmsMR.UI.Infra.TestTask.CilReader {
    class RawOperandFilter<TOperand> : Filter, IRawOperandFilter {
        public RawOperandFilter(Func<TOperand, bool> operandMatcher, string description) {
            this.operandMatcher = operandMatcher;
            Description = description;
        }

        #region IRawOperandFilter Methods
        public bool OperandMatches(bool ctor, IEnumerable<object> operands) {
            return operands.FirstOrDefault(x => x is TOperand && operandMatcher((TOperand)x)) != null;
        }
        #endregion

        private readonly Func<TOperand, bool> operandMatcher;
    }
}
