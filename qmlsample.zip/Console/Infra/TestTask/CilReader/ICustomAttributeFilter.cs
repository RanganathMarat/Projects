﻿#region Copyright Koninklijke Philips Electronics N.V. 2013
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
#endregion

using System.Collections.Generic;

namespace Philips.PmsMR.UI.Infra.TestTask.CilReader {

    enum CustomAttributeMatchType {
        /// <summary>
        /// Not interesting, do not report as a match.
        /// </summary>
        NOP,
        /// <summary>
        /// Report as a match, examine details.
        /// </summary>
        ExamineMembers,
        /// <summary>
        /// Report as a match, do not examine details.
        /// </summary>
        IgnoreMembers,
    }

    interface ICustomAttributeFilter : IFilter {

        /// <summary>
        /// Simple custom attribute check that can only match to the attribute name.
        /// </summary>
        /// <param name="fullCustomAttributeNames"></param>
        /// <returns>Whether to continue analysis into the type</returns>
        CustomAttributeMatchType CustomAttributeMatches(IEnumerable<string> fullCustomAttributeNames);

        /// <summary>
        /// If examination is wanted, or we just want to continue without matching,
        /// subfilters will be used for the contained data.
        /// </summary>
        FilterSet Subfilters { get; }
    }
}
