﻿#region Copyright Koninklijke Philips Electronics N.V. 2013
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
#endregion

using System;

namespace Philips.PmsMR.UI.Infra.TestTask.CilReader {
    internal static class Extensions {
        public static string ToReflectionFullName(this string cecilFullName) {
            return cecilFullName.Replace("/", "+");    
        }

        public static string ToRegularExpressionPattern(this string fullTypeName) {
            return fullTypeName.Replace(".", "\\.").Replace("+", "\\+");
        }

        public static Mono.Cecil.TypeDefinition ToDefinition(this Type self) {
            var module = Mono.Cecil.ModuleDefinition.ReadModule(self.Module.FullyQualifiedName);
            return (Mono.Cecil.TypeDefinition)module.LookupToken(self.MetadataToken);
        }

        public const string ConstructorText = ".ctor";
    }
}
