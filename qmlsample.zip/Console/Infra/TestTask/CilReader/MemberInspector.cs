﻿#region Copyright Koninklijke Philips Electronics N.V. 2013
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
#endregion

using System.Collections.Generic;
using System.Linq;

namespace Philips.PmsMR.UI.Infra.TestTask.CilReader {
    class MemberInspector : IMemberInspector {

        public MemberInspector(FilterSet filterSet) {
            this.filterSet = filterSet;
        }

        #region IMemberInspector Methods
        public void Execute(Mono.Cecil.TypeDefinition type) {
            foreach (var methodDefinition in type.Methods) {
                ProcessMethod(methodDefinition);
            }
        }
        #endregion

        private void ProcessMethod(Mono.Cecil.MethodDefinition methodDefinition) {
            if (!methodDefinition.HasBody) {
                return;
            }

            bool isCtor = methodDefinition.IsConstructor;
            bool isInTestNamespace = methodDefinition.DeclaringType.FullName.Contains(".Tests");
            var operands = ProcessOperands(isCtor, methodDefinition);
            var references = (from op in operands
                             where
                                 (op is Mono.Cecil.MemberReference) &&
                                 !(op is Mono.Cecil.MethodDefinition || op is Mono.Cecil.FieldDefinition)
                             let memberRef = op as Mono.Cecil.MemberReference
                             where
                                 memberRef.DeclaringType != null &&
                                 memberRef.DeclaringType.Scope.MetadataScopeType == Mono.Cecil.MetadataScopeType.AssemblyNameReference
                             select memberRef.DeclaringType.FullName + memberRef.Name).ToArray();

            foreach (var filter in filterSet.ReferenceFilters) {
                if (filter.MethodMatches(isCtor, isInTestNamespace, references)) {
                    filter.OnMatch(methodDefinition.DeclaringType.FullName.ToReflectionFullName() + ":" + methodDefinition.Name);
                }
            }
        }

        private IEnumerable<object> ProcessOperands(bool isCtor, Mono.Cecil.MethodDefinition methodDefinition) {
            var operands = methodDefinition.Body.Instructions.Select(x => x.Operand).ToArray();
            foreach (var operandFilter in filterSet.OperandFilters) {
                if (operandFilter.OperandMatches(isCtor, operands)) {
                    operandFilter.OnMatch(methodDefinition.DeclaringType.FullName.ToReflectionFullName() + ":" + methodDefinition.Name);
                }
            }
            return operands;
        } 

        private readonly FilterSet filterSet;
    }
}
