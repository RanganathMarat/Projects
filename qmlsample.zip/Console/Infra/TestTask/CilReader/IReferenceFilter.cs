﻿#region Copyright Koninklijke Philips Electronics N.V. 2013
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
#endregion

using System.Collections.Generic;

namespace Philips.PmsMR.UI.Infra.TestTask.CilReader {

    /// <summary>
    /// Filter for matching references to external assemblies.
    /// </summary>
    /// <remarks>
    /// An external assembly is defined as any module that is located
    /// outside the assembly that contains the type under inspection.
    /// </remarks>
    interface IReferenceFilter : IFilter {
        /// <summary>
        /// Called to find out, whether the provided full namespace references
        /// to external libraries provide any matches.
        /// </summary>
        /// <param name="ctor">True if the references were located in a constructor</param>
        /// <param name="inTestNamespace">True if references were located in a test namespace</param>
        /// <param name="fullReferenceNames">References methods in external assemblies</param>
        /// <returns>True of a match was found</returns>
        bool MethodMatches(bool ctor, bool inTestNamespace,IEnumerable<string> fullReferenceNames);

    }
}
