﻿#region Copyright Koninklijke Philips Electronics N.V. 2013
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
#endregion

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace Philips.PmsMR.UI.Infra.TestTask.CilReader {

    [Flags]
    enum OccurenceType : uint {
        Anywhere = 0x00,
        /// <summary>
        /// A reference that occurs in constructor.
        /// </summary>
        InCtor = 0x01,
    }

    class ReferenceFilter : Filter, IReferenceFilter {

        public ReferenceFilter(IEnumerable<string> fullReferenceNames, OccurenceType occurence, string description)
            : this(fullReferenceNames, false, occurence, description) {}

        public ReferenceFilter(IEnumerable<string> fullReferenceNames, bool ignoreTests, OccurenceType occurence, string description) {
            fullMatchingReferenceNames = fullReferenceNames;
            this.ignoreTests = ignoreTests;
            this.occurence = occurence;
            Description = description;
        }

        public ReferenceFilter(Regex regularExpression, OccurenceType occurence, string description) 
            : this(regularExpression, false, occurence, description) {}

        public ReferenceFilter(Regex regularExpression, bool ignoreTests, OccurenceType occurence, string description) {
            this.regularExpression = regularExpression;
            this.ignoreTests = ignoreTests;
            this.occurence = occurence;
            Description = description;
        }

        #region IReferenceMethods        
        public bool MethodMatches(bool ctor, bool inTestNamespace, IEnumerable<string> fullReferenceNames) {
            if (ignoreTests && inTestNamespace) {
                return false;
            }
            if ((occurence & OccurenceType.InCtor) != 0 && !ctor) {
                return false;
            }

            if (regularExpression != null) {
                foreach (var referenceName in fullReferenceNames) {
                    if (regularExpression.IsMatch(referenceName)) {
                        Log.LogInfo("found a reference match in " + referenceName);
                        return true;
                    }
                }
                return false;
            }

            return fullReferenceNames.Intersect(fullMatchingReferenceNames).FirstOrDefault() != null;
        }
        #endregion

        private readonly IEnumerable<string> fullMatchingReferenceNames;
        private readonly Regex regularExpression;
        private readonly OccurenceType occurence;
        private readonly bool ignoreTests;

        private static readonly Utilities.Log.LogEvent Log = Utilities.Log.LogEvent.CreateClassLog();
    }
}
