﻿#region Copyright Koninklijke Philips Electronics N.V. 2013
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
#endregion

using System;
using System.Collections.Generic;
using System.Linq;

namespace Philips.PmsMR.UI.Infra.TestTask.CilReader {

    /// <summary>
    /// Inspects an assembly for interesting types.
    /// </summary>
    /// <remarks>
    /// A type is considered to be interesting if it is not to be included by its custom attributes.
    /// The custom attributes are tested with the provided filters.
    /// </remarks>
    internal class Inspector {

        public Inspector(string assemblyPath, IEnumerable<ICustomAttributeFilter> rootAttributeFilters, Func<FilterSet, IMemberInspector> memberInspectorCreator = null) {
            this.assemblyPath = assemblyPath;
            this.rootAttributeFilters = rootAttributeFilters;
            // Use the provided creator function - or fall back using the default, if none provided.
            this.memberInspectorCreator = memberInspectorCreator ?? (set => new MemberInspector(set));
        }

        public void Execute() {
            Log.LogDebug("examines assembly: " + assemblyPath);
            var assemblyDefinition = Mono.Cecil.AssemblyDefinition.ReadAssembly(assemblyPath);
            var typesInAssembly = assemblyDefinition.Modules.SelectMany(m => m.Types);
            foreach (var typeInAssembly in typesInAssembly) {
                foreach (var rootFilter in rootAttributeFilters) {
                    Process(typeInAssembly, rootFilter);
                }
            }
        }

        private void Process(Mono.Cecil.TypeDefinition typeDefinition, ICustomAttributeFilter rootFilter) {
            bool recurse = true;
            switch (rootFilter.CustomAttributeMatches(typeDefinition.CustomAttributes.Select(x => x.AttributeType.FullName.ToReflectionFullName()))) {
                case CustomAttributeMatchType.NOP:
                    break;
                case CustomAttributeMatchType.ExamineMembers:
                    rootFilter.OnMatch(typeDefinition.FullName.ToReflectionFullName());
                    break;
                case CustomAttributeMatchType.IgnoreMembers:
                    rootFilter.OnMatch(typeDefinition.FullName.ToReflectionFullName());
                    recurse = false;
                    break;
            }
            if (recurse) {
                memberInspectorCreator(rootFilter.Subfilters).Execute(typeDefinition);
            }

            foreach (var nestedType in typeDefinition.NestedTypes) {
                Process(nestedType, rootFilter);
            }
        }

        private readonly string assemblyPath;
        private readonly IEnumerable<ICustomAttributeFilter> rootAttributeFilters;
        private readonly Func<FilterSet, IMemberInspector> memberInspectorCreator;

        private static readonly Utilities.Log.LogEvent Log = Utilities.Log.LogEvent.CreateClassLog();
    }
}
