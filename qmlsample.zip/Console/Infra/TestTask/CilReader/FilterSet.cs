﻿#region Copyright Koninklijke Philips Electronics N.V. 2013
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
#endregion

using System.Collections.Generic;
using System.Linq;

namespace Philips.PmsMR.UI.Infra.TestTask.CilReader {
    internal class FilterSet {
        public FilterSet(IEnumerable<ICustomAttributeFilter> customAttributeFilters, IEnumerable<IReferenceFilter> referenceFilters, IEnumerable<IRawOperandFilter> operandFilters) {
            CustomAttributeFilters = customAttributeFilters.ToArray();
            ReferenceFilters = referenceFilters.ToArray();
            OperandFilters = operandFilters.ToArray();
        }

        public IEnumerable<IFilter> All {
            get { return CustomAttributeFilters.Concat<IFilter>(ReferenceFilters).Concat(OperandFilters); }
        }

        public IEnumerable<ICustomAttributeFilter> CustomAttributeFilters { get; private set; }

        public IEnumerable<IReferenceFilter> ReferenceFilters { get; private set; }

        public IEnumerable<IRawOperandFilter> OperandFilters { get; private set; } 
    }
}
