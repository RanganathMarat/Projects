﻿#region Copyright Koninklijke Philips Electronics N.V. 2013
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
#endregion

using System;
using System.Collections.Generic;
using System.Linq;

namespace Philips.PmsMR.UI.Infra.TestTask.CilReader {
    class CustomAttributeFilter : Filter, ICustomAttributeFilter {
        public CustomAttributeFilter(
            IEnumerable<string> fullMatchingAttributeNames, 
            CustomAttributeMatchType matchType, 
            IEnumerable<IReferenceFilter> referenceFilters, 
            IEnumerable<IRawOperandFilter> operandFilters) {
                this.fullMatchingAttributeNames = fullMatchingAttributeNames;
            this.matchType = matchType;
            Subfilters = new FilterSet(new ICustomAttributeFilter[0], referenceFilters, operandFilters);
            foreach (var subFilter in Subfilters.All) {
                subFilter.Matched += OnMatch;
            }            
        }

        #region ICustomAttributeFilter Methods
        public CustomAttributeMatchType CustomAttributeMatches(IEnumerable<string> fullCustomAttributeNames) {
            return fullCustomAttributeNames.Intersect(fullMatchingAttributeNames, StringComparer.InvariantCulture).FirstOrDefault() != null ? 
                matchType : CustomAttributeMatchType.NOP;
        }

        public FilterSet Subfilters { get; private set; }        
        #endregion

        public override void OnMatch(string location, IFilter optionalChildSource = null) {
            if (optionalChildSource != null) {
                base.OnMatch(location,optionalChildSource);
            }
        }

        private readonly IEnumerable<string> fullMatchingAttributeNames;
        private readonly CustomAttributeMatchType matchType;
    }
}
