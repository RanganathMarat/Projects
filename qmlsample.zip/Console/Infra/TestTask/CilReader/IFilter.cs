﻿#region Copyright Koninklijke Philips Electronics N.V. 2013
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
#endregion

namespace Philips.PmsMR.UI.Infra.TestTask.CilReader {

    delegate void MatchedHandler(string location, IFilter srcFilter);

    interface IFilter {

        string Description { get; }

        event MatchedHandler Matched;

        void OnMatch(string location, IFilter optionalChildSource = null);        
    }
}
