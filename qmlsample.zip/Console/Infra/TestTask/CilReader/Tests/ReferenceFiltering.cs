﻿#region Copyright Koninklijke Philips Electronics N.V. 2013
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
#endregion

using System.Text.RegularExpressions;
using NUnit.Framework;

namespace Philips.PmsMR.UI.Infra.TestTask.CilReader.Tests {
    public class ReferenceFiltering : Utilities.UnitTest.TestBed {

        [Test]
        public void MethodMatches_RegularExpressionGiven_RegularExpressionMatchReturnsTrue() {
            var filter = new ReferenceFilter(
                new Regex(typeof(SampleClass).FullName.ToRegularExpressionPattern() + ".*"), OccurenceType.Anywhere, "SampleFilter");
            Assert.IsTrue(filter.MethodMatches(false, false, new [] { "WrongMatch.Hello", typeof(SampleClass).FullName + ".ctor" }), "Constructor function should have been found");
        }

        [Test]
        public void MethodMatches_NonmatchingRegularExpressionGiven_ReturnsFalse() {
            var filter = new ReferenceFilter(
                new Regex(typeof(SampleClass).FullName.ToRegularExpressionPattern() + ".*"), OccurenceType.Anywhere, "SampleFilter");
            Assert.IsFalse(filter.MethodMatches(false, false, new[] { "WrongMatch.Hello" }), "No matches should have been found");
        }

        private class SampleClass  {            
        }
    }
}
