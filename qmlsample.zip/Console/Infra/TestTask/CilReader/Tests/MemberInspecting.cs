﻿#region Copyright Koninklijke Philips Electronics N.V. 2013
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
#endregion

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using NUnit.Framework;
using Rhino.Mocks;

namespace Philips.PmsMR.UI.Infra.TestTask.CilReader.Tests {    

    public class MemberInspecting : Utilities.UnitTest.TestBed {

        [Test]
        public void Execute_ClassFromMarshalByRefObject_ReferenceDetected() {
            var typeDefinition = typeof(SampleMarshalByRefObject).ToDefinition();
            var refFilter = MockRepository.GenerateStub<IReferenceFilter>();
            refFilter.Stub(
                x =>
                x.MethodMatches(
                    Arg<bool>.Is.Equal(true),
                    Arg<bool>.Is.Equal(true),
                    Arg<IEnumerable<string>>.Matches(y => y.Single() == typeof(MarshalByRefObject).FullName + Extensions.ConstructorText))).Return(true);
            var filterSet = new FilterSet(new ICustomAttributeFilter[0], new [] {refFilter}, new IRawOperandFilter[0]);
            var inspector = new MemberInspector(filterSet);
            inspector.Execute(typeDefinition);
            refFilter.AssertWasCalled(x => x.OnMatch(typeof(SampleMarshalByRefObject).FullName + ":" + Extensions.ConstructorText));
        }

        [Test]
        public void Execute_XmlSerializerStaticMemberCalled_CallDetected() {
            var typeDefinition = typeof(SampleXmlSerializer).ToDefinition();
            var refFilter = MockRepository.GenerateStub<IReferenceFilter>();
            refFilter.Stub(
                x =>
                x.MethodMatches(
                    Arg<bool>.Is.Equal(false),
                    Arg<bool>.Is.Equal(true),
                    Arg<IEnumerable<string>>.Matches(y => y.Single().StartsWith(typeof(System.Xml.Serialization.XmlSerializer).FullName)))).Return(true);
            var filterSet = new FilterSet(new ICustomAttributeFilter[0], new[] { refFilter }, new IRawOperandFilter[0]);
            var inspector = new MemberInspector(filterSet);
            inspector.Execute(typeDefinition);
            refFilter.AssertWasCalled(x => x.OnMatch(typeof(SampleXmlSerializer).FullName + ":" + "SampleFunctionUsingSerializer"));
        }

        [Test]
        public void Execute_ThreadCtorCalled_CallDetected() {
            var typeDefinition = typeof(SampleThreadCtor).ToDefinition();
            var refFilter = MockRepository.GenerateStub<IReferenceFilter>();
            refFilter.Stub(
                x =>
                x.MethodMatches(
                    Arg<bool>.Is.Equal(false),
                    Arg<bool>.Is.Equal(true),
                    Arg<IEnumerable<string>>.Matches(y => y.Any(z => z.Equals(typeof(Thread).FullName + Extensions.ConstructorText))))).Return(true);
            var filterSet = new FilterSet(new ICustomAttributeFilter[0], new[] { refFilter }, new IRawOperandFilter[0]);
            var inspector = new MemberInspector(filterSet);
            inspector.Execute(typeDefinition);
            refFilter.AssertWasCalled(x => x.OnMatch(typeof(SampleThreadCtor).FullName + ":" + "CreatesIllegalThread"));
        }

        [Test]
        public void Execute_ThreadMethodCalled_CallNotDetected() {
        }

        [Test]
        public void Execute_EpsilonInClass_UsageDetected() {
            var typeDefinition = typeof(SampleEpsilonContainer).ToDefinition();
            var operandFilter = PrepareDoubleEpsilonFinder(false);
            var filterSet = new FilterSet(new ICustomAttributeFilter[0], new IReferenceFilter[0], new[] { operandFilter });
            var inspector = new MemberInspector(filterSet);
            inspector.Execute(typeDefinition);
            operandFilter.AssertWasCalled(x => x.OnMatch(typeof(SampleEpsilonContainer).FullName + ":" + "SampleEpsilonUsage"));
        }

        [Test]
        public void Execute_EpsilonDeclaredInClass_DeclarationDetected() {
            Assert.AreEqual(Double.Epsilon, new SampleEpsilonDeclarer().myEpsilon);
            var typeDefinition = typeof(SampleEpsilonDeclarer).ToDefinition();
            var operandFilter = PrepareDoubleEpsilonFinder(true);
            var filterSet = new FilterSet(new ICustomAttributeFilter[0], new IReferenceFilter[0], new[] { operandFilter });
            var inspector = new MemberInspector(filterSet);
            inspector.Execute(typeDefinition);
            operandFilter.AssertWasCalled(x => x.OnMatch(typeof(SampleEpsilonDeclarer).FullName + ":" + Extensions.ConstructorText));
        }

        private IRawOperandFilter PrepareDoubleEpsilonFinder(bool ctor) {
            var operandFilter = MockRepository.GenerateStub<IRawOperandFilter>();
            operandFilter.Stub(
                x =>
                x.OperandMatches(
                    Arg<bool>.Is.Equal(ctor),
                    Arg<IEnumerable<object>>.Matches(y => y.Where(z => z is System.Double).Select(z => double.Epsilon.Equals(z)).Single())
                    )).Return(true);
            return operandFilter;
        }

        private class SampleMarshalByRefObject : MarshalByRefObject {
        }

        protected class SampleXmlSerializer {
            private void SampleFunctionUsingSerializer() {
                var sample = System.Xml.Serialization.XmlSerializer.GenerateSerializer(null, null);
            }
        }

        private class SampleEpsilonContainer {
            private double SampleEpsilonUsage() {
                return Double.Epsilon;
            }
        }

        private class SampleEpsilonDeclarer {
            internal readonly double myEpsilon = Double.Epsilon;
        }

        private class SampleThreadCtor {
            void CreatesIllegalThread() {
                var t = new Thread(() => {});
                t = null;
            }
        }
    }    
}
