﻿#region Copyright Koninklijke Philips Electronics N.V. 2013
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
#endregion

using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using NUnit.Framework;
using Rhino.Mocks;

[assembly: InternalsVisibleTo(RhinoMocks.StrongName)]
[assembly: InternalsVisibleTo("DynamicProxyGenAssembly2, PublicKey=0024000004800000940000000602000000240000525341310004000001000100c547cac37abd99c8db225ef2f6c8a3602f3b3606cc9891605d02baa56104f4cfc0734aa39b93bf7852f7d9266654753cc297e7d2edfe0bac1cdcf9f717241550e0a7b191195b7667bb4f64bcb8e2121380fd1d9d46ad2d92d2d15605093924cceaf74c4861eff62abf69b9291ed0a340e113be11e6a7d3113e92484cf7045cc7")]

namespace Philips.PmsMR.UI.Infra.TestTask.CilReader.Tests {

    internal class SampleCustomAttribute : Attribute {        
    }

    [SampleCustom]
    internal class SampleMatchingCustomAttributeDecorated {
    }

    public class Inspecting : Utilities.UnitTest.TestBed {

        private void PrepareInspector(CustomAttributeMatchType matchType, Action<ICustomAttributeFilter, IMemberInspector> executeCallback) {
            var customFilter = MockRepository.GenerateStub<ICustomAttributeFilter>();

            var memberInspector = MockRepository.GenerateStub<IMemberInspector>();
            customFilter.Stub(
                x =>
                x.CustomAttributeMatches(
                    Arg<IEnumerable<string>>.Matches(
                        z => z.Contains(typeof(SampleCustomAttribute).FullName)))).Return(matchType);            
            var inspector = new Inspector(System.Reflection.Assembly.GetExecutingAssembly().Location, new [] {customFilter} , dummy => memberInspector);
            inspector.Execute();
        }

        [Test]
        public void Execute_CustomAttributeFilterProvidedWithIgnoreMembers_DecoratedClassFoundAndIgnored() {
            PrepareInspector(CustomAttributeMatchType.IgnoreMembers, (customFilter, memberInspector) => {
                // Our custom filter must have detected the sample class declared above
                customFilter.AssertWasCalled(x => x.OnMatch(typeof(SampleMatchingCustomAttributeDecorated).FullName));
                // Because the filter returned IgnoreMembers, we must ignore the type and not pass it to the member-examining filters
                memberInspector.AssertWasNotCalled(x => x.Execute(Arg<Mono.Cecil.TypeDefinition>.Is.Equal(typeof(SampleMatchingCustomAttributeDecorated).FullName)));
            });
        }

        [Test, Category("Lengthy")]
        public void Execute_CustomAttributeFilterProvidedWithExamineMembers_DecoratedClassFoundAndExamined() {
            PrepareInspector(CustomAttributeMatchType.ExamineMembers, (customFilter, memberInspector) => {
                // Our custom filter must have detected the sample class declared above
                customFilter.AssertWasCalled(x => x.OnMatch(typeof(SampleMatchingCustomAttributeDecorated).FullName));
                // Because the filter returned ExamineMembers, the type must have been relayed to the member inspector for closer examination
                memberInspector.AssertWasCalled(x => x.Execute(Arg<Mono.Cecil.TypeDefinition>.Matches(y => y.FullName == typeof(SampleMatchingCustomAttributeDecorated).FullName)));
            });
        }
    }

}
