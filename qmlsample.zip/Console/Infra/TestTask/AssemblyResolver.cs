#region Copyright Koninklijke Philips Electronics N.V. 2008
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
#endregion

using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;

namespace Philips.PmsMR.UI.Infra.TestTask {

    /// <summary>
    /// AssemblyResolver for finding the assemblied from a given directory.
    /// </summary>
    /// <remarks>
    /// The class needs to be serializable so that other appdomains can use it as well
    /// (when appdomain resolve-events are tied to the resolver).
    /// It cannot be marshallable, because the event signature is not remotable:
    /// ResolveEventArgs is not serializable.
    /// </remarks>
    [Serializable]
    internal class AssemblyResolver {

        public AssemblyResolver() : this(new[] {
                Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)}) {}

        public AssemblyResolver(IEnumerable<string> probingDirs) : this(probingDirs, AppDomain.CurrentDomain) {}

        public AssemblyResolver(IEnumerable<string> probingDirs, AppDomain domain) {
            directories = new List<string>();
            foreach (string s in probingDirs) {
                if (!String.IsNullOrEmpty(s) && Path.IsPathRooted(s)) {
                    directories.Add(s);
                }
            }

            string local = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            if (!directories.Contains(local)) {
                directories.Add(local);
            }

            domain.AssemblyResolve += OnAssemblyResolve;
        }
        
        private Assembly OnAssemblyResolve(object sender, ResolveEventArgs args) {
            string[] name = args.Name.Split();
            string assem = name[0].Substring(0, name[0].Length - 1);
            if (assem.EndsWith("\\")) {
                assem = assem.Substring(0, assem.Length - 1);
            }

            foreach (string dir in directories) {
                string path = Path.Combine(dir, assem);
                if (File.Exists(path + ".dll")) {
                    return Assembly.LoadFrom(path + ".dll");
                }
                if (File.Exists(path + ".exe")) {
                    return Assembly.LoadFrom(path + ".exe");
                }
            }
            return null;
        }

        private readonly List<string> directories;
    }
}
