#region Copyright 2013-2014 Koninklijke Philips N.V.
//
// All rights reserved. Reproduction in whole or in part is prohibited without 
// the written consent of the copyright owner.
//
#endregion

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using Philips.PmsMR.UI.Infra.TestTask.Log;
using Philips.PmsMR.UI.Infra.TestTask.Remote;
using Philips.PmsMR.UI.Infra.Utilities.Misc;
using Philips.PmsMR.UI.Interfaces.Infra.TestTask;

namespace Philips.PmsMR.UI.Infra.TestTask {

    public class Program {

        const String synopsis = @"Synopsis:
  TestTask  [--abort_on_failure] 
            [--run_src_tests] 
            [--processors <n>]
            [--processor_load <n>]
            [--profiling]
            [-c category] 
            [-n namespace] 
            [-t testName] [--repeat <n>] [assembly] [assembly] ..

  where:
    -t | --test runs the named test(s) - there can be several.
    -c | --category runs the named category 
        (RepresentativeConcurrent, Undefined)
    --abort_on_failure stops with the first encountered failure
    --processors limits the execution to the given number of CPUs
    --processor_load wastes the given percentage in each CPU.
    --progress_listener <assembly name> <listener url>. SW only, addin listener for test execution progress
    --repeat repeats the tests n-times.
    --run_src_tests checks the source code
    --profiling to disable minidump generation for profiling

    assembly is the dll or exe to be tested - there can be several 
    and full names can be provided.
";

        [LoaderOptimization(LoaderOptimization.MultiDomain)]
        static int Main(string[] args) {
            AppDomain.CurrentDomain.UnhandledException += OnUnhandledException;
            using (new BuildTestEventScope()) {
                bool profiling = args.Contains("--profiling");
                return InternalMain(args, profiling);
            }
        }

        static int InternalMain(string[] args, bool profiling) {
            var assemblyNames = new List<string>();
            var testNames = new List<string>();
            var categories = new List<TestCategoryType>();
            var namespaceInclusions = new List<string>();
            bool abortOnFailure = false;
            bool srcTests = false;
            bool scriptTests = false;
            bool manifestTests = false;
            bool verbose = false;
            int repeatCount = 1;
            int? processors = null;
            int? processorLoad = null;

            // SW-generated parameters
            string masterUrl = null;
            int masterPid = -1;
            DateTime masterStartTime = DateTime.MaxValue;
            ProgressListener listener = null;
            int count = 0;
            while (count < args.Length) {
                if (args[count] == "-t" || args[count] == "--test") {
                    testNames.Add(args[++count]);
                } else if (args[count] == "-c" || args[count] == "--category") {
                    TestCategoryType category;
                    if (!TestCategoryType.TryParse(args[++count], out category)) {
                        Console.Error.WriteLine("Invalid test category type given: " + args[count]);
                        return 1;
                    }
                    categories.Add(category);
                } else if (args[count] == "-n" || args[count] == "--namespace") {
                    namespaceInclusions.Add(args[++count]);
                } else if (args[count] == "--abort_on_failure") {
                    abortOnFailure = true;
                } else if (args[count] == "--processors") {
                    processors = Convert.ToInt32(args[++count]);
                } else if (args[count] == "--processor_load") {
                    processorLoad = Convert.ToInt32(args[++count]);
                } else if (args[count] == "--repeat") {
                    repeatCount = Convert.ToInt32(args[++count]);
                } else if (args[count] == "--run_src_tests") {
                    srcTests = true;
                } else if (args[count] == "--run_script_tests") {
                    scriptTests = true;
                } else if (args[count] == "--run_manifest_tests") {
                    manifestTests = true;
                } else if (args[count] == "--verbose") {
                    verbose = true;
                } else if (args[count] == "--parent_url") {
                    masterUrl = args[++count];
                } else if (args[count] == "--parent_pid") {
                    try {
                        masterPid = Int32.Parse(args[++count]);
                    } catch (FormatException) {
                        Console.Error.WriteLine("Invalid parent_pid format: " + String.Join(" ", args));
                        return 1;
                    }
                } else if(args[count] == "--progress_listener") {
                    ChannelManager.Instance.SetupClient();
                    var assemblyName = args[++count];
                    var progressListenerUrl = args[++count];
                    listener = new ProgressListener(assemblyName, progressListenerUrl);
                    if (!listener.Init()) {
                        Console.Error.WriteLine("Unable to access progress listener!");
                        return 1;
                    }
                } else if (args[count] == "--parent_start_time") {
                    masterStartTime = new DateTime(Int64.Parse(args[++count]), DateTimeKind.Utc);
                } else {
                    assemblyNames.Add(args[count]);
                }
                ++count;
            }

            if (processors.HasValue) {
                long affinityMask = ((long)1 << processors.Value) - 1;
                System.Diagnostics.Process.GetCurrentProcess().ProcessorAffinity = new IntPtr(affinityMask);
                Environment.SetEnvironmentVariable(Constants.ProcessorAffinity, affinityMask.ToString(CultureInfo.InvariantCulture));
            }

            try {
                Logging.instance = new Logging();
                Logging.Instance.ProgressListener = listener;

                if (masterUrl != null) {
                    // This is SW-invoked testtask.exe
                    return ExecuteAsSubprocess(masterUrl, new ProcessId(masterPid, masterStartTime));
                }

                // This is a manually executed testtask.exe
                if ((testNames.Count < 1 && assemblyNames.Count < 1 && categories.Count == 0)) {
                    if (!srcTests && !scriptTests && !manifestTests) {
                        Logging.Instance.WriteLogConsoleEntry("Testing targets were not given");
                        Logging.Instance.WriteLogConsoleEntry(synopsis);
                        return 1;
                    }
                }

                var task = new TestTask(null) {
                    TestingOptions = new TestingOptions {
                        AbortOnFailure = abortOnFailure,
                        AssemblyNames = assemblyNames.Select(x => new FileInfo(x)).ToList(),
                        NamespaceInclusions = namespaceInclusions,
                        ProcessorLoad = processorLoad,
                        Repeat = repeatCount,
                        Profiling = profiling,
                        TestNames = testNames.Any() ? new HashSet<string>(testNames) : null,
                        TestCategoryTypes = new HashSet<TestCategoryType>(categories.Count == 0 ? new[] { TestCategoryType.BuildTests } : categories.ToArray()),
                        TestSystems =
                            (!scriptTests && !srcTests && !manifestTests ? TestingOptions.TestSystemTypes.NUnit : 0) | // Default to nunit
                            (scriptTests ? TestingOptions.TestSystemTypes.IronPython : 0) |
                            (srcTests ? TestingOptions.TestSystemTypes.SourceCode : 0) |
                            (manifestTests ? TestingOptions.TestSystemTypes.CommonRuntimeBinaries : 0),
                        Verbose = verbose
                    },
                    
                };

                return task.Execute() ? 0 : 1;
            } finally {
                Logging.instance.Dispose();
                Logging.instance = null;
            }
        }

        private static int ExecuteAsSubprocess(string masterUrl, ProcessId processId) {
            // Kill this process if the parent dies
            var parentProcess = Utilities.Misc.Process.Convert(processId);
            if (parentProcess == null) {
                // Parent is already dead
                Logging.Instance.WriteLogErrorEntry("Cannot find parent TestTask process");
                return 1;
            }
            parentProcess.EnableRaisingEvents = true;
            parentProcess.Exited += (sender, args) => System.Diagnostics.Process.GetCurrentProcess().Kill();
            if (parentProcess.HasExited) {
                // Died during event subscription
                Logging.Instance.WriteLogErrorEntry("Parent TestTask process died while trying on event subscriptions");
                return 1;
            }

            ChannelManager.Instance.SetupClient();
            var parent = Activator.GetObject(typeof(SubTestTaskParent), masterUrl) as SubTestTaskParent;

            if (parent == null) {
                Logging.Instance.WriteLogErrorEntry("Cannot access SubTestTaskParent in the parent TestTask process");
                return 1;
            }

            Logging.instance.InstallParentLogger(parent);

            var task = new TestTask(parent) {
                TestingOptions = parent.Options
            };

            // These have already been figured out by the parent
            task.TestingOptions.AssemblyNames = parent.AssemblyFullNames.Select(x => new FileInfo(x)).ToList();
            task.TestingOptions.TestNames = new HashSet<string>(parent.Tests);

            bool retVal = task.Execute();

            Logging.Instance.WriteLogInfoEntry("Finished executing tests in a subprocess");
            return retVal ? 0 : 1;
        }

        private static void OnUnhandledException(object sender, UnhandledExceptionEventArgs e) {
            Log.LogEvent.Instance.LogError("Unhandled exception", e.ExceptionObject as Exception);
        }

    }

}
