﻿#region Copyright Koninklijke Philips Electronics N.V. 2009
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
#endregion

using System;
using System.Collections;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Ipc;
using System.Security.Principal;

namespace Philips.PmsMR.UI.Infra.TestTask.Remote {

    internal class ChannelManager {

        public static ChannelManager Instance { get { return instance; } }

        public void SetupClient() {
            EnsureChanneling();
        }

        public string SetupServer(MarshalByRefObject root, string objectName) {
            EnsureChanneling();
            var channel = ChannelServices.GetChannel("ipc");
            var refObj = RemotingServices.Marshal(root, objectName);
            return ((IChannelReceiver)channel).GetUrlsForUri(refObj.URI)[0];
        }

        /// <summary>
        /// Ensure that the channels have been created.
        /// </summary>
        internal void EnsureChanneling()
        {
            lock (syncBlock)
            {
                if (remotingChannel != null)
                {
                    return;
                }

                if (remotingChannel != null)
                {
                    // Another thread got there first!
                    return;
                }

                remotingChannel = EnsureHostChanneling();
            }
        }

        /// <summary>
        /// Remoting channels for a hosting application.
        /// </summary>
        private static IChannel EnsureHostChanneling()
        {
            var serverProvider = new BinaryServerFormatterSinkProvider();
            var clientProvider = new BinaryClientFormatterSinkProvider();
            serverProvider.TypeFilterLevel = System.Runtime.Serialization.Formatters.TypeFilterLevel.Full;
            var props = new Hashtable();
            props["portName"] = "UnitTestHost" + Guid.NewGuid().ToString("N");
            UpdateWithDefaultProperties(props);
            IChannel channel = new IpcChannel(props, clientProvider, serverProvider);

            ChannelServices.RegisterChannel(channel, false);
            return channel;
        }

        private static void UpdateWithDefaultProperties(IDictionary props)
        {
            props["exclusiveAddressUse"] = false;

            // SID: S-1-1-0
            var sID = new SecurityIdentifier(WellKnownSidType.WorldSid, null);
            IdentityReference wID = sID.Translate(typeof(NTAccount));
            var everyoneAsString = wID.Value;

            props["authorizedGroup"] = everyoneAsString;
            props["impersonationLevel"] = "Identification";
            props["connectionTimeout"] = new TimeSpan(0, 0, 10);

            // Increase above the default 20 of the ipc channel (AppDomain channel maximum: 64)
            props["priority"] = "30";
        }

        private readonly static ChannelManager instance = new ChannelManager();
        private readonly static object syncBlock = new object();
        private static IChannel remotingChannel;
    }
}
