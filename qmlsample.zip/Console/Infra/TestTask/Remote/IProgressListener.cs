﻿#region Copyright Koninklijke Philips Electronics N.V. 2012
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
#endregion

using System;

namespace Philips.PmsMR.UI.Infra.TestTask.Remote {
    /// <summary>
    /// External listener for testing progress.
    /// </summary>
    /// <remarks>
    /// Initial implementation contains only OnLogEntry. However, this interface
    /// could contain more detailed information about the progress allowing an UI
    /// to show nicely how testing is progressing.
    /// </remarks>
    interface IProgressListener {
        /// <summary>
        /// Called when testing writes a new log entry.
        /// </summary>
        /// <param name="msg">Message</param>
        /// <param name="optionalException">Possible exception related to the message</param>
        /// <param name="error">Whether the message is of type error</param>
        void OnLogEntry(string msg, Exception optionalException, bool error);

    }
}
