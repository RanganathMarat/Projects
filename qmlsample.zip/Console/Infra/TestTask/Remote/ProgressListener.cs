﻿#region Copyright Koninklijke Philips Electronics N.V. 2012
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
#endregion

using System;
using System.Reflection;

namespace Philips.PmsMR.UI.Infra.TestTask.Remote {
    class ProgressListener : IProgressListener {
        public ProgressListener(string assemblyName, string url) {
            this.assemblyName = assemblyName;
            this.url = url;
        }

        public bool Init() {
            var assembly = Assembly.LoadFrom(assemblyName);
            var listenerType = assembly.GetType("ProgressListener");
            if (listenerType == null)
            {
                throw new ApplicationException("Progress listener not found in " + assemblyName);
            }
            listener = Activator.GetObject(listenerType, url);
            onLogEntryMethod = listenerType.GetMethod(
                "OnLogEntry", new[] {typeof(string), typeof(Exception), typeof(bool)});
            return onLogEntryMethod != null;
        }

        #region IProgressListener
        public void OnLogEntry(string msg, Exception optionalException, bool error) {
            onLogEntryMethod.Invoke(listener, new object[] {msg, optionalException, error});
        }
        #endregion

        private readonly string assemblyName;
        private readonly string url;
        private object listener;
        private MethodInfo onLogEntryMethod;
    }
}
