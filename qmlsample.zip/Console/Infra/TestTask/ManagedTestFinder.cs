#region Copyright 2014 Koninklijke Philips N.V.
//
// All rights reserved. Reproduction in whole or in part is prohibited without 
// the written consent of the copyright owner.
//
#endregion

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using NUnit.Framework.Interfaces;
using Philips.PmsMR.UI.Infra.TestTask.Log;
using LogEvent = Philips.PmsMR.UI.Infra.Utilities.Log.LogEvent;

namespace Philips.PmsMR.UI.Infra.TestTask {
    class ManagedTestFinder : IDisposable {

        public ManagedTestFinder(TestingOptions options, CancellationTokenSource cancellationTokenSource) {
            this.options = options;
            localCancellationSource = CancellationTokenSource.CreateLinkedTokenSource(cancellationTokenSource.Token);
            var assemblyEnumerator = new ManagedAssemblyEnumerator(options);
            assemblyEnumerationTask = System.Threading.Tasks.Task.Factory.StartNew(
                () => {
                    try {
                        var allBuiltAssemblies =
                            from assemblyFile in
                                assemblyEnumerator.AssemblyFiles.AsParallel()
                                    .OrderBy(x => x.FullName)
                                    .WithExecutionMode(ParallelExecutionMode.ForceParallelism)
                                    .WithCancellation(localCancellationSource.Token)
                            let buildTask = System.Threading.Tasks.Task.Factory.StartNew(
                                () => {
                                    var builder = new ManagedFixtureBuilder();
                                    return builder.Build(assemblyFile);
                                })
                            select new {
                                AssemblyFile = assemblyFile,
                                BuildTask = buildTask
                            };

                        foreach (var buildInfo in allBuiltAssemblies) {
                            var suiteTask = buildInfo.BuildTask;
                            suiteTask.Wait(localCancellationSource.Token);
                            var suite = suiteTask.Result;

                            if (suite == null) {
                                Log.LogInfo("No tests found in " + buildInfo.AssemblyFile);
                                continue;
                            }
                            var grouped = from test in RecurseTestCases(suite)
                                group test by ExtractAppSpecificInformation(test);
                            foreach (var groupedItems in grouped) {
                                switch (groupedItems.Key) {
                                    case TestGroup.Sequential:
                                        sequentialTests.Add(
                                            new TestInfo {
                                                Assembly = buildInfo.AssemblyFile,
                                                TestCases = SelectTests(options, groupedItems)
                                            });
                                        break;
                                }
                            }
                        }
                    } catch (OperationCanceledException) {
                        Logging.Instance.WriteLogErrorEntry("Test assembly reflection cancelled");
                    } catch (Exception e) {
                        Logging.Instance.WriteLogErrorEntry("Test assembly reflection failed: " + e);
                    } finally {
                        sequentialTests.CompleteAdding();
                    }
                });
        }

        public AttributeInfo GetAttributeInfo(ITest test) {
            return testAttributeInfoMap[test];
        }

        private IEnumerable<ITest> SelectTests(TestingOptions options, IEnumerable<ITest> orderByDescending) {
            if (options.TestNames != null) {
                return orderByDescending.Where(x => options.TestNames.Contains(x.FullName));
            }
            if (options.NamespaceInclusions.Any()) {
                return orderByDescending.Where(x => options.NamespaceInclusions.Any(y => x.FullName.StartsWith(y)));
            }
            return orderByDescending;
        }

        private enum TestGroup {
            /// <summary>
            /// Tests are executed in a test thread sequentially (not in parallel).
            /// </summary>
            Sequential,
        }

        private bool IsManagedOnly(ITest test) {
            return ManagedFixtureBuilder.IsManagedOnly(test.FixtureType.Assembly);
        }

        private TestGroup ExtractAppSpecificInformation(ITest test) {
            var propertyBag = test.Properties;
            var attributeInfo = new AttributeInfo();
            testAttributeInfoMap[test] = attributeInfo;
            if (propertyBag.ContainsKey("Category")) {
                foreach (string category in propertyBag["Category"]) {
                    switch (category) {
                        case "Lengthy":
                            attributeInfo.Time = TimeRequirementType.Lengthy;
                            break;
                        case "SystemController":
                            attributeInfo.ExecutionGroup |= ExecutionGroupRequirementTypes.ExclusiveSystemOwnership;
                            break;
                        case "Representative":
                            attributeInfo.Representative = true;
                            break;
                        case "Manual":
                            attributeInfo.SystemState |= SystemStateRequirements.ManualExecution;
                            break;
                        case "AdminRights":
                            if ((attributeInfo.SystemState & SystemStateRequirements.NoAdminRights) != 0) {
                                throw new ApplicationException("Cannot define both AdminRights and NoAdminRights for " + test.FullName);
                            }
                            attributeInfo.SystemState |= SystemStateRequirements.AdminRights;
                            break;
                        case "NoAdminRights":
                            if ((attributeInfo.SystemState & SystemStateRequirements.AdminRights) != 0) {
                                throw new ApplicationException("Cannot define both AdminRights and NoAdminRights for " + test.FullName);
                            }
                            attributeInfo.SystemState |= SystemStateRequirements.NoAdminRights;
                            break;
                        case "Activated":
                            attributeInfo.SystemState |= SystemStateRequirements.Activated;
                            break;
                        case "DebugOnly":
                            attributeInfo.SystemState |= SystemStateRequirements.DebugOnly;
                            break;
                        case "TestTaskProcess":
                            attributeInfo.SystemState |= SystemStateRequirements.TestTaskProcess;
                            break;
                        case "Isolated":
                            attributeInfo.SystemState |= SystemStateRequirements.Isolated;
                            break;
                        case "AppDomained":
                            attributeInfo.SystemState |= SystemStateRequirements.AppDomained;
                            break;
                    }
                }
            }

            if (!IsManagedOnly(test)) {
                // Mixed mode code must be executed in its own process (static variables must be initialized in default appdomain)
                attributeInfo.SystemState |= SystemStateRequirements.TestTaskProcess;
                attributeInfo.ExecutionGroup |= ExecutionGroupRequirementTypes.GMockNeeded;
            }

            if (attributeInfo.Representative && options.TestCategoryTypes.Contains(TestCategoryType.UnitTests)) {
                attributeInfo.IgnoredCategory = false;
            } else if (options.TestCategoryTypes.Contains(TestCategoryType.BuildTests)) {
                attributeInfo.IgnoredCategory = false;
            } else {
                if (attributeInfo.Time == TimeRequirementType.Lengthy &&
                    !options.TestCategoryTypes.Contains(TestCategoryType.Lengthy)) {
                    attributeInfo.IgnoredCategory = true;
                }
                if ((attributeInfo.ExecutionGroup & ExecutionGroupRequirementTypes.ExclusiveSystemOwnership) != 0 &&
                    !options.TestCategoryTypes.Contains(TestCategoryType.SystemController)) {
                    attributeInfo.IgnoredCategory = true;
                }
                if ((attributeInfo.ExecutionGroup & ManagedTestSystem.ExplicitlyDefinedTestGroups) == 0 &&
                    attributeInfo.Time == TimeRequirementType.None &&
                    !options.TestCategoryTypes.Contains(TestCategoryType.Undefined)) {
                    attributeInfo.IgnoredCategory = true;
                }
            }

            // Default execution in this process and appdomain
            return TestGroup.Sequential;
        }

        private IEnumerable<ITest> RecurseTestCases(ITest test) {
            if (test.IsSuite) {
                foreach (var potentialSuite in test.Tests) {
                    foreach (var testCase in RecurseTestCases(potentialSuite)) {
                        yield return testCase;
                    }
                }
            } else {
                yield return test;
            }
        }

        public IEnumerable<TestInfo> GetSequentialTests() {
            TestInfo info;
            while (sequentialTests.TryTake(out info, WaitForeverTimeout)) {
                yield return info;
            }
        }

        #region IDisposable
        /// <summary>
        /// Disposal flag.
        /// </summary>
        protected bool disposed;

        /// <summary>
        /// Dispose implementation.
        /// </summary>
        public void Dispose() {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Finalizer.
        /// </summary>
        ~ManagedTestFinder() {
            Dispose(false);
        }

        /// <summary>
        /// Finalizer/disposal.
        /// </summary>
        /// <param name="disposing">Set when called from the explicit dispose</param>
        protected virtual void Dispose(bool disposing) {
            if (!disposed) {
                if (disposing) {
                    localCancellationSource.Cancel();
                    assemblyEnumerationTask.Wait();
                    sequentialTests.Dispose();
                } else {
                    System.Diagnostics.Debug.Assert(false, "Forgot to dispose object of type ManagedTestFinder");
                }
                disposed = true;
            }
        }

        /// <summary>
        /// A check for disposal.
        /// </summary>        
        /// <exception cref="ObjectDisposedException">Throws if already disposed of</exception>
        protected void CheckDisposed() {
            if (disposed) {
                System.Diagnostics.Debug.Assert(false, "Trying to use disposed object of type ManagedTestFinder");
                throw new ObjectDisposedException("ManagedTestFinder");
            }
        }
        #endregion

        private readonly ConcurrentDictionary<ITest, AttributeInfo> testAttributeInfoMap = new ConcurrentDictionary<ITest, AttributeInfo>();
        private readonly BlockingCollection<TestInfo> sequentialTests = new BlockingCollection<TestInfo>();
        private readonly CancellationTokenSource localCancellationSource;
        private readonly System.Threading.Tasks.Task assemblyEnumerationTask;
        private readonly TestingOptions options;

        private static readonly TimeSpan WaitForeverTimeout = TimeSpan.FromMilliseconds(-1);
        private static readonly Utilities.Log.LogEvent Log = Utilities.Log.LogEvent.CreateClassLog();
    }
}