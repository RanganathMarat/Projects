﻿#region Copyright 2014 Koninklijke Philips N.V.
//
// All rights reserved. Reproduction in whole or in part is prohibited without 
// the written consent of the copyright owner.
//
#endregion

using System;
using System.Collections.Generic;
using System.Threading;
using Philips.PmsMR.UI.Infra.Utilities.WinApi;

namespace Philips.PmsMR.UI.Infra.TestTask {
    class ArtificialLoader : IDisposable {
        public ArtificialLoader(bool rootTestTask, int? cpuLoadPercentage) {
            if (!rootTestTask || !cpuLoadPercentage.HasValue) {
                return;
            }

            this.cpuLoadPercentage = cpuLoadPercentage.Value;
            var affinityMask = Environment.GetEnvironmentVariable(Interfaces.Infra.TestTask.Constants.ProcessorAffinity);
            long mask;
            if (affinityMask != null && long.TryParse(affinityMask, out mask)) {
                // OK, overriden
            } else {
                mask = ((long)1 << Environment.ProcessorCount) - 1;
            }

            for (int processorIndex = 0; processorIndex < Environment.ProcessorCount; ++processorIndex) {
                long currentMaskBit = (1 << processorIndex);
                if ((mask & currentMaskBit) == 0) {
                    continue;
                }
                Thread thread = new Thread(DoCpuLoadWork);
                cpuLoaders.Add(thread);
                thread.Start(currentMaskBit);
            }
        }

        #region IDisposable
        /// <summary>
        /// Disposal flag.
        /// </summary>        
        protected bool disposed;

        /// <summary>
        /// Dispose implementation.
        /// </summary>
        public void Dispose() {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Finalizer.
        /// </summary>
        ~ArtificialLoader() {
            Dispose(false);
        }

        /// <summary>
        /// Finalizer/disposal.
        /// </summary>
        /// <param name="disposing">Set when called from the explicit dispose</param>
        protected virtual void Dispose(bool disposing) {
            if (!disposed) {
                if (disposing) {
                    lock (syncBlock) {
                        shutdown = true;
                        Monitor.PulseAll(syncBlock);
                    }
                } else {
                    System.Diagnostics.Debug.Assert(false, "Forgot to dispose object of type ArtificialLoader");
                }
                disposed = true;
            }
        }

        /// <summary>
        /// A check for disposal.
        /// </summary>        
        /// <exception cref="ObjectDisposedException">Throws if already disposed of</exception>
        protected void CheckDisposed() {
            if (disposed) {
                System.Diagnostics.Debug.Assert(false, "Trying to use disposed object of type ArtificialLoader");
                throw new ObjectDisposedException("ArtificialLoader");
            }
        }
        #endregion

        private void DoCpuLoadWork(object maskBit) {
            Thread.BeginThreadAffinity();
            Thread.CurrentThread.Priority = ThreadPriority.Highest;

            ProcessSettings.SetCurrentThreadAffinity(new IntPtr((long)maskBit));

            var loadTime =
                TimeSpan.FromMilliseconds(cpuLoadPercentage / (float)(100) * MeasurementPeriod.Milliseconds);
            var restTime = MeasurementPeriod - loadTime;
            int busyLoops = 1;
            while (true) {
                lock (syncBlock) {
                    if (shutdown) {
                        return;
                    }
                }

                TimeSpan creationOffset;
                TimeSpan kernelTime;
                TimeSpan userTime;
                UserIdleTime.GetCurrentThreadTime(out creationOffset, out kernelTime, out userTime);
                TimeSpan usedCpu = kernelTime + userTime;

                for (int index = 0; index < busyLoops; ++index) {
                    var buffer = new byte[busyLoops];
                    new Random().NextBytes(buffer);
                }

                UserIdleTime.GetCurrentThreadTime(out creationOffset, out kernelTime, out userTime);
                TimeSpan usedCpuAfter = kernelTime + userTime;

                UpdateBusyLoopTarget(loadTime, usedCpuAfter - usedCpu, ref busyLoops);

                Thread.CurrentThread.Join((int) restTime.TotalMilliseconds);
            }
        }

        private static void UpdateBusyLoopTarget(TimeSpan loadTime, TimeSpan timeInBusyLoop, ref int busyLoops) {
            var neededIncrease = loadTime - timeInBusyLoop;
            if (neededIncrease > TimeSpan.Zero) {
                // Needed load level has not been reached yet
                if (timeInBusyLoop.TotalMilliseconds > 1e-9) {
                    var estimatedIncreaseNeed = loadTime.TotalMilliseconds / timeInBusyLoop.TotalMilliseconds;
                    if (estimatedIncreaseNeed > 1) {
                        // Prevent overshoots by a moderate max increase of 2
                        busyLoops = (int)(busyLoops * Math.Min(estimatedIncreaseNeed, 2));
                    } else {
                        // Temporary overload, ignore
                    }
                } else {
                    busyLoops *= 2;
                }
            }
        }

        private readonly object syncBlock = new object();
        private bool shutdown;
        private readonly List<Thread> cpuLoaders = new List<Thread>();

        private readonly int cpuLoadPercentage;

        private static readonly TimeSpan MeasurementPeriod = TimeSpan.FromMilliseconds(50);
    }
}
