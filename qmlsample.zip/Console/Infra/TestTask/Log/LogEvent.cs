#region Copyright Koninklijke Philips Electronics N.V. 2006-2009
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
#endregion

namespace Philips.PmsMR.UI.Infra.TestTask.Log {
    internal sealed class LogEvent : Utilities.Log.LogEvent {

        public static Utilities.Log.LogEvent Instance {
            get {
                return SafeCreateInstance(typeof(LogEvent));
            }
        }
    }
}
