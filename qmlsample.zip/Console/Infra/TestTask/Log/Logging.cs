#region Copyright 2012-2014 Koninklijke Philips N.V.
//
// All rights reserved. Reproduction in whole or in part is prohibited without 
// the written consent of the copyright owner.
//
#endregion

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Threading;
using Microsoft.Build.Framework;
using Microsoft.Build.Utilities;
using Philips.PmsMR.UI.Infra.TestTask.Remote;

namespace Philips.PmsMR.UI.Infra.TestTask.Log {

    /// <summary>
    /// Message types for relayed logs
    /// </summary>
    public enum MessageType
    {
        /// <summary>
        /// Informative entry.
        /// </summary>
        Information,
        /// <summary>
        /// Warning entry.
        /// </summary>
        Warning,
        /// <summary>
        /// Error entry.
        /// </summary>
        Error
    }

    [Serializable]
    public class LoggableTestResult
    {
        public string Suite;
        public string TestName;
        public double DurationInSeconds;
        public bool Passed;
    }

    class Logging : IDisposable {

        public Logging(TaskLoggingHelper taskLogger = null) {
            stdOut = Console.Out;
            stdErr = Console.Error;
            this.taskLogger = taskLogger;

            var devNull = new StringWriter();
            Console.SetOut(devNull);
            Console.SetError(devNull);

            backgroundWriter = System.Threading.Tasks.Task.Factory.StartNew(OnWork);
        }

        public static Logging Instance {
            get { return instance; }
        }

        /// <summary>
        /// Progress listener of an AddIn (integrated execution within VS IDE).
        /// </summary>
        /// <remarks>
        /// Required for deflecting the logs into Alt-B,Alt-B background test window.
        /// </remarks>
        public IProgressListener ProgressListener { get; set; }

        public void WriteTestResult(string testSuite, string testName, double durationInSeconds, bool passed)
        {

            if (parentProcessLogger != null)
            {
                    parentProcessLogger.OnTestResult(new LoggableTestResult
                    {
                        DurationInSeconds = durationInSeconds,
                        Passed = passed,
                        Suite = testSuite,
                        TestName = testName
                    });
                return;
            }

            lock (resultsLoggerSyncBlock)
            {
                if (resultsLogger == null)
                {
                    resultsLogger = new StreamWriter(Path.Combine(
                        Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location),
                        "UnitTest.philipsresult"), false);
                }
                resultsLogger.WriteLine(String.Format(CultureInfo.InvariantCulture, "{0}|{1}|{2}|{3}", testSuite, testName, durationInSeconds.ToString(CultureInfo.InvariantCulture), passed ? "SUCCESS" : "FAILED"));
            }
        }

        public void WriteLogConsoleEntry(string message) {
            WriteToConsole(message, null, MessageType.Information);
        }

        public void WriteLogInfoEntry(string message) {
            LogEvent.Instance.LogInfo(message);
            WriteToConsole(message, null, MessageType.Information);
        }

        public void WriteLogWarningEntry(string message) {
            LogEvent.Instance.LogWarning(message);
            WriteToConsole(message, null, MessageType.Warning);
        }

        public void WriteLogErrorEntry(string message) {
            LogEvent.Instance.LogError(message);
            WriteToConsole(message, null, MessageType.Error);
        }

        public void WriteLogErrorEntry(string message, Exception e) {
            LogEvent.Instance.LogError(message, e);
            WriteToConsole(message, e, MessageType.Error);
        }

        public void WriteRemoteLogEntry(string msg, Exception optionalException, MessageType messageType) {
            WriteToConsole(msg, optionalException, messageType);
        }

        #region IDisposable
        /// <summary>
        /// Disposal flag.
        /// </summary>
        protected bool disposed;

        /// <summary>
        /// Dispose implementation.
        /// </summary>
        public void Dispose() {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Finalizer.
        /// </summary>
        ~Logging() {
            Dispose(false);
        }

        /// <summary>
        /// Finalizer/disposal.
        /// </summary>
        /// <param name="disposing">Set when called from the explicit dispose</param>
        protected virtual void Dispose(bool disposing) {
            if (!disposed) {
                if (disposing) {
                    Console.SetOut(stdOut);
                    Console.SetError(stdErr);
                    lock (syncBlock) {
                        shutdown = true;
                        Monitor.PulseAll(syncBlock);
                    }
                    if (!backgroundWriter.Wait(MaximumBackgroundJoinTime)) {
                        throw new TimeoutException("Failed to wait for the logger worker thread to finish");
                    }

                    lock (resultsLoggerSyncBlock)
                    {
                        if (resultsLogger != null)
                        {
                            resultsLogger.Flush();
                            resultsLogger.Close();
                        }
                    }
                } else {
                    System.Diagnostics.Debug.Assert(false, "Forgot to dispose object of type Logging");
                }
                disposed = true;
            }
        }

        /// <summary>
        /// A check for disposal.
        /// </summary>        
        /// <exception cref="ObjectDisposedException">Throws if already disposed of</exception>
        protected void CheckDisposed() {
            if (disposed) {
                System.Diagnostics.Debug.Assert(false, "Trying to use disposed object of type Logging");
                throw new ObjectDisposedException("Logging");
            }
        }
        #endregion

        private void OnWork() {
            bool exit;
            do {
                LogInfo[] accruedLogs;
                lock (syncBlock) {
                    while (queue.Count == 0 && !shutdown) {
                        Monitor.Wait(syncBlock);
                    }
                    accruedLogs = queue.ToArray();
                    queue.Clear();
                    exit = shutdown;
                }

                foreach (var logInfo in accruedLogs) {
                    OutputLog(logInfo);
                }
            } while (!exit);
        }

        private void OutputLog(LogInfo logInfo) {
            if (ProgressListener != null) {
                try
                {
                    ProgressListener.OnLogEntry(logInfo.Message, logInfo.OptionalException,
                        logInfo.MessageType != MessageType.Information);
                }
                catch (System.Runtime.Remoting.RemotingException)
                {
                }
                return;
            }

            string message = logInfo.Message;
            if (logInfo.OptionalException != null) {
                message += " - Exception: " + logInfo.OptionalException;
            }
            System.Diagnostics.Trace.WriteLine(message);
            var prevColor = Console.ForegroundColor;
            switch (logInfo.MessageType) {
                case MessageType.Information:
                    if (taskLogger != null) {
                        taskLogger.LogMessage(MessageImportance.Normal, message);
                    } else {
                        stdOut.WriteLine(message);
                    }
                    break;
                case MessageType.Warning:
                    if (taskLogger != null) {
                        taskLogger.LogWarning(message);
                    } else {
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        try {
                            stdOut.WriteLine(message);
                        } finally {
                            Console.ForegroundColor = prevColor;
                        }
                    }
                    break;
                default:
                    if (taskLogger != null) {
                        taskLogger.LogError(message);
                    } else {
                        Console.ForegroundColor = ConsoleColor.Red;
                        try {
                            stdErr.WriteLine(message);
                        } finally {
                            Console.ForegroundColor = prevColor;
                        }
                    }
                    break;
            }
        }

        private void WriteToConsole(string msg, Exception optionalException, MessageType messageType) {
            if (parentProcessLogger != null) {
                try {
                    parentProcessLogger.OnLogEntry(msg, optionalException, messageType);
                } catch (Exception) {
                    if (optionalException != null) {
                        parentProcessLogger.OnLogEntry("Cannot remote an exception: " + optionalException.GetType().FullName + ", message was " + optionalException, null, MessageType.Error);
                    }
                    throw;
                }
                return;
            }

            lock (syncBlock) {
                queue.Add(new LogInfo { Message = msg, MessageType = messageType, OptionalException = optionalException });
                Monitor.PulseAll(syncBlock);
            }
        }

        private readonly System.Threading.Tasks.Task backgroundWriter;
        private readonly TaskLoggingHelper taskLogger;
        private readonly TextWriter stdOut;
        private readonly TextWriter stdErr;
        private static SubTestTaskParent parentProcessLogger;

        private class LogInfo {
            public string Message;
            public Exception OptionalException;
            public MessageType MessageType;
        }

        private readonly object syncBlock = new object();
        private List<LogInfo> queue = new List<LogInfo>();
        private bool shutdown;
        private static readonly TimeSpan MaximumBackgroundJoinTime = TimeSpan.FromMinutes(5);

        private readonly object resultsLoggerSyncBlock = new object();
        private StreamWriter resultsLogger;

        internal static Logging instance;

        internal void InstallParentLogger(SubTestTaskParent parent) {
            parentProcessLogger = parent;
        }
    }
}
