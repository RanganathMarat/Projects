#region Copyright 2014 Koninklijke Philips N.V.
//
// All rights reserved. Reproduction in whole or in part is prohibited without 
// the written consent of the copyright owner.
//
#endregion

using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using Philips.PmsMR.UI.Infra.TestTask.CilReader;
using Philips.PmsMR.UI.Infra.TestTask.Log;
using Philips.PmsMR.UI.Infra.TestTask.Snooper;

namespace Philips.PmsMR.UI.Infra.TestTask {
    internal class SourceCodeTestSystem : TestSystem {
        private readonly TestingOptions options;
        private readonly CancellationTokenSource tokenSource;

        public SourceCodeTestSystem(TestingOptions options, CancellationTokenSource tokenSource) {
            this.options = options;
            this.tokenSource = tokenSource;
        }

        public override bool Execute() {
            IList<FileInfo> fileList;
            if (options.AssemblyNames != null && options.AssemblyNames.Count > 0) {
                fileList = options.AssemblyNames;
            } else {
                fileList = IgnoranceManager.Instance.FindValidEntries(
                    new DirectoryInfo(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)),
                    IgnoranceType.IgnoreThirdPartyFiles | IgnoranceType.IgnoreMultimodule | IgnoranceType.IgnoreNativeModules | IgnoranceType.IgnoreSelf);
            }

            bool retVal = true;
            foreach (var info in fileList) {
                string testPath = info.FullName;
                Logging.Instance.WriteLogInfoEntry("Reference check for " + testPath);

                string reply = ExamineAssembly(testPath, RootFilters);
                if (String.IsNullOrEmpty(reply)) {
                    reply = FileSpecificCheck(info);
                }
                if (!String.IsNullOrEmpty(reply)) {
                    Logging.Instance.WriteLogErrorEntry(reply);
                    FailedTests.Add(testPath);
                    retVal = false;
                    if (options.AbortOnFailure) {
                        break;
                    }
                } else {
                    SuccessTestCount += 1;
                }
            }

            return SuccessTestCount > 0 && retVal;
        }

        internal static string FileSpecificCheck(FileInfo file) {
            var filename = file.Name;
            if (!FileSpecificFilters.ContainsKey(filename)) {
                return null;
            }
            var filters = FileSpecificFilters[filename];
            return ExamineAssembly(file.FullName, filters);
        }

        internal static string ExamineAssembly(string testPath, ICustomAttributeFilter[] rootFilters) {
            var builder = new StringBuilder();
            MatchedHandler actOnError = (location, filter) => {
                Logging.Instance.WriteLogErrorEntry("Reference check for " + location + " failed - " + filter.Description);
                builder.AppendLine(location + " failed - " + filter.Description);
            };

            foreach (var filter in rootFilters) {
                filter.Matched += actOnError;
            }
            try {
                var inspector = new Inspector(testPath, rootFilters);
                inspector.Execute();
            } finally {
                foreach (var filter in rootFilters) {
                    filter.Matched -= actOnError;
                }
            }

            return builder.ToString();
        }

        internal static readonly ICustomAttributeFilter[] RootFilters = {
            new CustomAttributeFilter(
                new [] {typeof(Interfaces.Infra.Utilities.UnitTest.SourceChecks.IgnoreMarshalByRefObjectAttribute).FullName},
                CustomAttributeMatchType.IgnoreMembers, 
                new [] {new ReferenceFilter(new [] {typeof(MarshalByRefObject).FullName + Extensions.ConstructorText}, OccurenceType.InCtor, "Direct MarshalByRefObject inheritance"), }, 
                new IRawOperandFilter[0]),
            new CustomAttributeFilter(
                new [] {typeof(Interfaces.Infra.Utilities.UnitTest.SourceChecks.IgnoreXmlSerializerAttribute).FullName},
                CustomAttributeMatchType.IgnoreMembers, 
                new [] {new ReferenceFilter(
                    new Regex(typeof(System.Xml.Serialization.XmlSerializer).FullName.ToRegularExpressionPattern() + "\\..*", RegexOptions.Compiled), 
                    OccurenceType.Anywhere, "Usage of slow System.Xml.Serialization.XmlSerializer class"), }, 
                new IRawOperandFilter[0]),
            new CustomAttributeFilter(
                new [] {typeof(Interfaces.Infra.Utilities.UnitTest.SourceChecks.IgnoreDoubleEpsilonUsageAttribute).FullName}, 
                CustomAttributeMatchType.IgnoreMembers, 
                new IReferenceFilter[0], 
                new IRawOperandFilter[] {new RawOperandFilter<double>(Double.Epsilon.Equals, "Absurd Epsilon usage")}), 
        };

        internal static readonly IDictionary<string, ICustomAttributeFilter[]> FileSpecificFilters = new Dictionary<string, ICustomAttributeFilter[]> {
        };

    }
}