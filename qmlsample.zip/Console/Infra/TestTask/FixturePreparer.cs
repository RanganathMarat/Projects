#region Copyright 2014 Koninklijke Philips N.V.
//
// All rights reserved. Reproduction in whole or in part is prohibited without 
// the written consent of the copyright owner.
//
#endregion

using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using NUnit.Framework.Interfaces;
using NUnit.Framework.Internal;
using NUnit.Framework.Internal.Commands;
using Philips.PmsMR.UI.Infra.TestTask.Log;
using LogEvent = Philips.PmsMR.UI.Infra.Utilities.Log.LogEvent;

namespace Philips.PmsMR.UI.Infra.TestTask {
    class FixturePreparer {
        public FixturePreparer(FixtureStore store, ITest test, AttributeInfo attributeInfo) {
            testSuite = (TestSuite)test.Parent;
            this.store = store;

            if (attributeInfo.ExecutionGroup != store.CurrentExecutionGroup) {
                store.CurrentExecutionGroup = attributeInfo.ExecutionGroup;
                PrepareForExecutionGroup(attributeInfo.ExecutionGroup);
            } else {
                PrepareForExecutionOfTest(test, attributeInfo.ExecutionGroup);
            }

            if (store.CurrentFixtureType != test.FixtureType) {
                if (store.CurrentFixtureType != null) {
                    GroupTearDown();
                }
                store.CurrentFixtureType = test.FixtureType;
                var parent = (TestSuite)test.Parent;
                Logging.Instance.WriteLogInfoEntry("    Test Fixture: " + parent.FullName);
                var setup = new OneTimeSetUpCommand(parent, new List<SetUpTearDownItem>(), new List<TestActionItem>());
                setup.Execute(store.ExecutionContext);
            }
        }

        public void GroupTearDown() {
            var tearDown = new OneTimeTearDownCommand(testSuite, new List<SetUpTearDownItem>(), new List<TestActionItem>());
            tearDown.Execute(store.ExecutionContext);
        }

        private void PrepareForExecutionOfTest(ITest test, ExecutionGroupRequirementTypes group) {
            if ((group & ExecutionGroupRequirementTypes.ExclusiveSystemOwnership) != 0) {
                Log.LogInfo("Exclusive system ownership required for a test");
            }
        }

        private void PrepareForExecutionGroup(ExecutionGroupRequirementTypes newGroup) {
        }

        private readonly TestSuite testSuite;
        private readonly FixtureStore store;

        private static readonly Utilities.Log.LogEvent Log = Utilities.Log.LogEvent.CreateClassLog();
    }
}