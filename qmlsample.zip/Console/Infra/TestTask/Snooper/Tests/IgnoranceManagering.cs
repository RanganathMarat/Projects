﻿#region Copyright Koninklijke Philips Electronics N.V. 2013
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
#endregion

using System.Collections.Generic;
using System.IO;
using System.Linq;
using NUnit.Framework;

namespace Philips.PmsMR.UI.Infra.TestTask.Snooper.Tests {

    public class IgnoranceManagering : Utilities.UnitTest.TestBed {
        [Test]
        public void FilterOutIgnored_IgnoreSelfDefined_RunningAssemblyRemovedFromList() {
            var thisExecutable =System.Reflection.Assembly.GetExecutingAssembly().Location;
            var fileList = new List<FileInfo> {
                new FileInfo(thisExecutable),
                new FileInfo("NonExistentFile249A53B9-AD95-4D04-A39D-098A94A992E1")
            };
            IgnoranceManager.FilterOutIgnored(fileList, IgnoranceType.IgnoreSelf);
            Assert.IsTrue(fileList.Single().Name != thisExecutable, "TestTask was removed from the list");
        }
    }

}
