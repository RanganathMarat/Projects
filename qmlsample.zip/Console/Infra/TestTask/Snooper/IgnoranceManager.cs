#region Copyright Koninklijke Philips Electronics N.V. 2009
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
#endregion

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Philips.PmsMR.UI.Infra.TestTask.Snooper {

    [Flags]
    enum IgnoranceType {
        IgnoreMultimodule = 0x01,
        IgnoreWithoutResources = 0x02,
        IgnoreNativeModules = 0x04,
        IgnoreThirdPartyFiles = 0x08,
        IgnoreSelf = 0x10
    }

    /// <summary>
    /// Contains knowledge about files to be ignored
    /// (3rd party files not to be tested)
    /// </summary>
    class IgnoranceManager {

        static IgnoranceManager() {
            string rootDir = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
            GenerateIgnorance(new DirectoryInfo(rootDir));
        }

        public static IgnoranceManager Instance {
            get { return instance; }
        }

        public List<System.IO.FileInfo> FindValidEntries(System.IO.DirectoryInfo rootDir) {
            return FindValidEntries(rootDir, IgnoranceType.IgnoreThirdPartyFiles);
        }

        public List<System.IO.FileInfo> FindValidEntries(System.IO.DirectoryInfo rootDir, IgnoranceType ignoranceFlags) {
            var fileList = new List<System.IO.FileInfo>();
            foreach (string pattern in ValidAssemblySearchTerms) {
                try {
                    fileList.AddRange(rootDir.GetFiles(pattern));
                } catch (IOException e) {
                    throw new ApplicationException("Failed to dig out files from " + rootDir.FullName, e);
                }
            }
            FilterOutIgnored(fileList, ignoranceFlags);
            return fileList;
        }

        public bool IsValidEntry(FileInfo info, IgnoranceType ignoranceFlags) {
            if (!ValidAssemblyExtensions.Contains(Path.GetExtension(info.Name).ToLower())) {
                return false;
            }
            var fileList = new List<FileInfo> { info };
            FilterOutIgnored(fileList, ignoranceFlags);
            return fileList.Count == 1;
        }

        internal static void FilterOutIgnored(List<FileInfo> fileList, IgnoranceType ignoranceFlags) {
            int index = 0;
            do {
                index = fileList.FindIndex(index, delegate(FileInfo info) {
                    if (info == null) {
                        return false;
                    }

                    if ((ignoranceFlags & IgnoranceType.IgnoreThirdPartyFiles) != 0) {
                        // Exclude 3rd party assemblies
                        if (nameIsMap.ContainsKey(info.Name.ToLowerInvariant())) {
                            return true;
                        }
                    }

                    // Exclude .vshost.exe's (visual studio hosting files)
                    string[] parts = info.Name.Split('.');
                    if (parts.Length >= 3) {
                        if (parts[parts.Length - 2].ToLowerInvariant() == "vshost") {
                            return true;
                        }
                    }

                    if (Array.Exists(AllwaysIgnored, name => info.Name.ToLowerInvariant() == name.ToLowerInvariant())) {
                        return true;
                    }

                    if ((ignoranceFlags & IgnoranceType.IgnoreNativeModules) != 0) {
                        // Exclude native binaries
                        if (!IsAssembly(info.FullName)) {
                            return true;
                        }
                    }

                    if ((ignoranceFlags & IgnoranceType.IgnoreSelf) != 0) {
                        if (string.Compare(
                            info.FullName,
                            System.Reflection.Assembly.GetExecutingAssembly().Location, StringComparison.InvariantCulture) == 0) {
                            return true;
                        }
                    }

                    if ((ignoranceFlags & IgnoranceType.IgnoreMultimodule) != 0) {
                        if (Array.FindIndex<string>(IgnoredMultimoduleAssemblies, delegate(string name) { return info.Name.ToLowerInvariant() == name.ToLowerInvariant(); }) >= 0) {
                            return true;
                        }
                    }

                    if ((ignoranceFlags & IgnoranceType.IgnoreWithoutResources) != 0) {
                        if (Array.FindIndex(IgnoredWithoutResourceAssemblies, x => info.Name.ToLowerInvariant() == x.ToLowerInvariant()) >= 0) {
                            return true;
                        }
                    }

                    return false;
                });
                if (index >= 0) {
                    fileList.RemoveAt(index);
                }
            } while (index >= 0);
        }

        private IgnoranceManager() {
        }

        private static void GenerateIgnorance(DirectoryInfo rootDir) {
            nameIsMap =
                ManagedAssemblyEnumerator.BlacklistedAssemblyNames.ToDictionary(
                    x => x.ToLowerInvariant(), s => true);
        }

        private static bool IsAssembly(string path) {
            try {
                System.Reflection.AssemblyName.GetAssemblyName(path);
                return true;
            } catch (BadImageFormatException) {
                return false;
            }
        }

        private readonly static string[] ValidAssemblyExtensions = new[] { ".exe", ".dll", ".pyd" };
        private static readonly string[] ValidAssemblySearchTerms = ValidAssemblyExtensions.Select(x => "*" + x).ToArray();

        /// <summary>
        /// Multimodule assemblies (typically mixed mode stuff is too hard for Cecil)
        /// </summary>
        private static readonly string[] IgnoredMultimoduleAssemblies = new string[0];

        private readonly static string[] IgnoredWithoutResourceAssemblies = new string[] {
        };

        private readonly static string[] AllwaysIgnored =
        {
            "msvcp100d.dll",
            "msvcr100d.dll",
            "msvcp100.dll",
            "msvcr100.dll",
            "msvcm90d.dll",
            "msvcp90d.dll",
            "msvcr90d.dll",
            "msvcm90.dll",
            "msvcp90.dll",
            "msvcr90.dll",
        };

        private static Dictionary<string, bool> nameIsMap = new Dictionary<string, bool>();
        private static readonly IgnoranceManager instance = new IgnoranceManager();
    }
}
