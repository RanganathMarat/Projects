﻿#region Copyright Koninklijke Philips Electronics N.V. 2009-2014
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
#endregion

using System;
using System.IO;
using System.Reflection;
using System.Threading.Tasks;
using Philips.PmsMR.UI.Infra.TestTask.Log;

namespace Philips.PmsMR.UI.Infra.TestTask.SystemSurrogate {
    class Manager {

        /// <summary>
        /// This is only available in the root testtask appdomain.
        /// </summary>
        public static Manager Instance { get; set; }

        public void ProvideNonactivatedServices() {
        }

        public void Shutdown() {
        }

        public void EnsurePrepared() {
        }

    }
}
