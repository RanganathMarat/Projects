#region Copyright 2014 Koninklijke Philips N.V.
//
// All rights reserved. Reproduction in whole or in part is prohibited without 
// the written consent of the copyright owner.
//
#endregion

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using Philips.PmsMR.UI.Infra.TestTask.Log;

namespace Philips.PmsMR.UI.Infra.TestTask {
    class ManagedAssemblyEnumerator {
        public ManagedAssemblyEnumerator(TestingOptions options) {
            if (options.AssemblyNames != null && options.AssemblyNames.Any()) {
                AssemblyFiles = options.AssemblyNames;
                Logging.Instance.WriteLogInfoEntry(
                    String.Format(CultureInfo.InvariantCulture,
                        "Using a user-provided list of {0} assemblies", options.AssemblyNames.Count()));
            } else {
                Logging.Instance.WriteLogInfoEntry(String.Format(CultureInfo.InvariantCulture, "Examining assemblies in {0}", options.DeliveryDirectory.FullName));
                Func<string, IEnumerable<FileInfo>> searchFunc = pattern =>
                    from file in
                        options.DeliveryDirectory.EnumerateFiles(pattern, SearchOption.TopDirectoryOnly)
                    select file;
                var assemblies = searchFunc("*.dll").Concat(searchFunc("*.exe")).Where(
                    x => !BlacklistedAssemblyNames.Contains(x.Name) && !x.Name.EndsWith("vshost.exe", true, CultureInfo.InvariantCulture));
                AssemblyFiles = assemblies;
            }
        }

        public IEnumerable<FileInfo> AssemblyFiles;

        internal static readonly HashSet<string> BlacklistedAssemblyNames = new HashSet<string> {
            "Microsoft.VisualStudio.DebuggerVisualizers.dll", "dbghelp.dll",
            "mscoree.dll",
            "msvcp100d.dll", "msvcp100.dll",
            "msvcr100d.dll", "msvcr100.dll",
            "Castle.Core.dll", "Mono.Cecil.dll", 
            "Microsoft.Dynamic.dll", "Microsoft.Scripting.dll", "Microsoft.Scripting.Metadata.dll",
            "nunitlite.dll", "nunit.framework.dll", "Rhino.Mocks.dll",
            "protobuf-net.dll",
        };

    }
}