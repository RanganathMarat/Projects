#region Copyright 2014 Koninklijke Philips N.V.
//
// All rights reserved. Reproduction in whole or in part is prohibited without 
// the written consent of the copyright owner.
//
#endregion

using System;
using System.Collections;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using NUnit.Framework.Interfaces;
using NUnit.Framework.Internal;
using NUnit.Framework.Internal.Builders;
using Philips.PmsMR.UI.Infra.TestTask.Log;

namespace Philips.PmsMR.UI.Infra.TestTask {
    /// <summary>
    /// We cannot use DefaultTestAssemblyBuilder from nunit, it is not thread-safe.
    /// </summary>
    class ManagedFixtureBuilder {
        public ITest Build(FileInfo assemblyFile) {
            Assembly assembly;
            try {
                assembly = Assembly.LoadFrom(assemblyFile.FullName);
            } catch (Exception) {
                Logging.Instance.WriteLogErrorEntry("Failed to load " + assemblyFile.FullName +
                                                    ", our application path is " + AppDomain.CurrentDomain.SetupInformation.ApplicationBase +
                                                    " and our working dir is " + Environment.CurrentDirectory);
                throw;
            }

            Type[] testTypes;
            try
            {
                testTypes = assembly.GetTypes();
            }
            catch (ReflectionTypeLoadException e)
            {
                foreach (var loadException in e.LoaderExceptions)
                {
                    Logging.Instance.WriteLogErrorEntry("Failed to load " + assemblyFile.FullName + ", " + loadException);
                }
                throw;
            }

            var builder = new NUnitTestFixtureBuilder();

            try {
                var fixtures =
                    (from testType in testTypes
                        let suite = builder.BuildFrom(testType)
                        where suite != null
                        select suite).ToList();
                return fixtures.Count > 0 ? BuildTestAssembly(assemblyFile, assembly, fixtures) : null;
            } catch (Exception) {
                Logging.Instance.WriteLogErrorEntry(String.Format(CultureInfo.InvariantCulture, "Failed to build tests in assembly {0}", assemblyFile.FullName));
                throw;
            }
        }

        internal static bool IsManagedOnly(Assembly assembly) {
            var module = assembly.ManifestModule;
            PortableExecutableKinds peKinds;
            ImageFileMachine imageFileMachine;
            module.GetPEKind(out peKinds, out imageFileMachine);
            return (peKinds & PortableExecutableKinds.ILOnly) != 0;
        }

        private TestSuite BuildTestAssembly(FileInfo assemblyFile, Assembly assembly, IList fixtures) {
            TestSuite testAssembly = new TestAssembly(assembly, assemblyFile.FullName);

            if (fixtures.Count == 0) {
                testAssembly.RunState = RunState.NotRunnable;
                testAssembly.Properties.Set(PropertyNames.SkipReason, "Has no TestFixtures");
            } else {
                var treeBuilder = new NamespaceTreeBuilder(testAssembly);
                treeBuilder.Add(fixtures);
                testAssembly = treeBuilder.RootSuite;
            }

            testAssembly.ApplyAttributesToTest(assembly);

            testAssembly.Properties.Set(PropertyNames.ProcessID, System.Diagnostics.Process.GetCurrentProcess().Id);
            testAssembly.Properties.Set(PropertyNames.AppDomain, AppDomain.CurrentDomain.FriendlyName);
            testAssembly.Sort();

            return testAssembly;
        }

    }
}