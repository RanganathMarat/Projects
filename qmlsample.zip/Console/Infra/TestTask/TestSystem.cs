#region Copyright 2014 Koninklijke Philips N.V.
//
// All rights reserved. Reproduction in whole or in part is prohibited without 
// the written consent of the copyright owner.
//
#endregion

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using Philips.PmsMR.UI.Infra.TestTask.Log;

namespace Philips.PmsMR.UI.Infra.TestTask {
    /// <summary>
    /// An abstract base class for test systems.
    /// </summary>
    /// <remarks>
    /// Although the whole testtask is only for testing .NET code, it contains different test systems
    /// for testing various aspects of the code. For example, different test systems are needed
    /// to statically checking for contract violations in reflected code vs. NUnit tests, which
    /// are exercised by running them through the NUnit execution framework.
    /// </remarks>
    abstract class TestSystem {
        protected TestSystem() {
            FailedTests = new List<string>();
            TestCanary = new Canary(GetType().FullName);
        }

        /// <summary>
        /// Execute method can be called multiple times (e.g., repeated testing)
        /// </summary>
        /// <returns></returns>
        public abstract bool Execute();

        public int SuccessTestCount { get; protected set; }
        public List<string> FailedTests { get; protected set; }
        public int SkipCount { get; protected set; }

        public Canary TestCanary { get; private set; }

        public IDisposable CreateCanaryScope() {
            return new CanaryScope(TestCanary);
        }

        public class Canary {

            public Canary(string name) {
                this.name = name;
            }

            /// <summary>
            /// This method needs to be called regularly - otherwise we assume the testing to be stuck and will commit a seppuku.
            /// </summary>
            public void KeepCanaryAlive() {
                lock (syncBlock) {
                    latestKeepalive = DateTime.UtcNow;
                    Monitor.PulseAll(syncBlock);
                }
            }

            public void Launch() {
                if (canaryTask != null) {
                    throw new InvalidOperationException("Canary has already been launched");
                }
                lock (syncBlock) {
                    shutdownCanary = false;
                    latestKeepalive = DateTime.UtcNow;
                }

                canaryTask = Task.Factory.StartNew(() => {
                    lock (syncBlock) {
                        while (!shutdownCanary) {
                            if (!Monitor.Wait(
                                    syncBlock,
                                    Interfaces.Infra.Utilities.UnitTest.Constants.MaximumUnitTestWaitTimeout)) {
                                if (suspendCount <= 0) {
                                    if ((DateTime.UtcNow - latestKeepalive) >=
                                        TimeSpan.FromMilliseconds(
                                            Interfaces.Infra.Utilities.UnitTest.Constants.MaximumUnitTestWaitTimeout)) {
                                        try {
                                            var message = "Canary timeouted, unit tests seem to be stuck in " + name +
                                                          ", latest keepalive: " + latestKeepalive;
                                            LogEvent.Instance.LogError(message);
                                            Logging.Instance.WriteLogErrorEntry(
                                                "Unit tests detected a deadlock, see log for details");
                                        } finally {
                                            Process.GetCurrentProcess().Kill();
                                        }
                                    } else {
                                        LogEvent.Instance.LogDebug("Canary " + name + " continuing wait, latest keepalive: " + latestKeepalive);
                                    }
                                } else {
                                    LogEvent.Instance.LogDebug("Canary " + name + " suspended - continuing wait, suspension count: " + suspendCount);
                                }
                            }
                        }
                        LogEvent.Instance.LogDebug("Canary " + name + " shuts down");
                    }
                });
            }

            /// <summary>
            /// Canary is not needed anymore, unit tests have been finished
            /// </summary>
            public void ShutdownCanary() {
                lock (syncBlock) {
                    shutdownCanary = true;
                    Monitor.PulseAll(syncBlock);
                }
                if (canaryTask != null) {
                    canaryTask.Wait();
                }
            }

            public IDisposable SuspendCanary() {
                return new Suspender(this);
            }

            private void Suspend(bool set) {
                lock (syncBlock) {
                    if (set) {
                        ++suspendCount;
                        LogEvent.Instance.LogDebug("Canary " + name + " suspending, count " + suspendCount);
                    } else {
                        --suspendCount;
                        LogEvent.Instance.LogDebug("Canary " + name + " suspend stopping, count " + suspendCount);
                    }
                    latestKeepalive = DateTime.UtcNow;
                    Monitor.PulseAll(syncBlock);
                }
            }

            private class Suspender : IDisposable {

                public Suspender(Canary parent) {
                    this.parent = parent;
                    parent.Suspend(true);
                }

                #region IDisposable
                /// <summary>
                /// Disposal flag.
                /// </summary>
                protected bool disposed;

                /// <summary>
                /// Dispose implementation.
                /// </summary>
                public void Dispose() {
                    Dispose(true);
                    GC.SuppressFinalize(this);
                }

                /// <summary>
                /// Finalizer.
                /// </summary>
                ~Suspender() {
                    Dispose(false);
                }

                /// <summary>
                /// Finalizer/disposal.
                /// </summary>
                /// <param name="disposing">Set when called from the explicit dispose</param>
                protected virtual void Dispose(bool disposing) {
                    if (!disposed) {
                        if (disposing) {
                            parent.Suspend(false);
                        } else {
                            System.Diagnostics.Debug.Assert(false, "Forgot to dispose object of type Suspender");
                        }
                        disposed = true;
                    }
                }

                /// <summary>
                /// A check for disposal.
                /// </summary>        
                /// <exception cref="ObjectDisposedException">Throws if already disposed of</exception>
                protected void CheckDisposed() {
                    if (disposed) {
                        System.Diagnostics.Debug.Assert(false, "Trying to use disposed object of type Suspender");
                        throw new ObjectDisposedException("Suspender");
                    }
                }
                #endregion

                private readonly Canary parent;
            }

            private readonly object syncBlock = new object();
            private DateTime latestKeepalive = DateTime.MinValue;
            private bool shutdownCanary;
            private int suspendCount;
            private Task canaryTask;

            private readonly string name;
        }

        private class CanaryScope : IDisposable {

            public CanaryScope(Canary canary) {
                this.canary = canary;
                canary.Launch();
            }

            #region IDisposable
            /// <summary>
            /// Disposal flag.
            /// </summary>        
            protected bool disposed;

            /// <summary>
            /// Dispose implementation.
            /// </summary>
            public void Dispose() {
                Dispose(true);
                GC.SuppressFinalize(this);
            }

            /// <summary>
            /// Finalizer.
            /// </summary>
            ~CanaryScope() {
                Dispose(false);
            }

            /// <summary>
            /// Finalizer/disposal.
            /// </summary>
            /// <param name="disposing">Set when called from the explicit dispose</param>
            protected virtual void Dispose(bool disposing) {
                if (!disposed) {
                    if (disposing) {
                        canary.ShutdownCanary();
                    } else {
                        System.Diagnostics.Debug.Assert(false, "Forgot to dispose object of type CanaryScope");
                    }
                    disposed = true;
                }
            }

            /// <summary>
            /// A check for disposal.
            /// </summary>
            /// <exception cref="ObjectDisposedException">Throws if already disposed of</exception>
            protected void CheckDisposed() {
                if (disposed) {
                    System.Diagnostics.Debug.Assert(false, "Trying to use disposed object of type CanaryScope");
                    throw new ObjectDisposedException("CanaryScope");
                }
            }
            #endregion

            private readonly Canary canary;
        }
    }
}