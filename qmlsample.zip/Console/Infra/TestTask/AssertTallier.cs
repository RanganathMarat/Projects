#region Copyright 2014 Koninklijke Philips N.V.
//
// All rights reserved. Reproduction in whole or in part is prohibited without 
// the written consent of the copyright owner.
//
#endregion

using System.Threading;
using Philips.PmsMR.UI.Infra.Utilities.Misc;

namespace Philips.PmsMR.UI.Infra.TestTask {
    class AssertTallier {
        public static bool CheckForUnhandledAsserts(bool forceFinalizationBeforeCheck) {
            if (forceFinalizationBeforeCheck) {
                new FinalizationWait().CollectAndWaitForPendingFinalizers(
                    Interfaces.Infra.Utilities.UnitTest.Constants.DefaultConditionWaitTimeout);
            }
            return CollectAssertEvents();
        }

        private static bool CollectAssertEvents() {
            var unhandledAssertEvent = new EventWaitHandle(
                false, EventResetMode.ManualReset, Utilities.Misc.TraceListener.UnhandledAssertEventName);
            if (unhandledAssertEvent.WaitOne(0, true)) {
                unhandledAssertEvent.Reset();
                return true;
            }
            return false;
        }
    }
}