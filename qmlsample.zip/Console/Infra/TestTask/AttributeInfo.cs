#region Copyright 2014 Koninklijke Philips N.V.
//
// All rights reserved. Reproduction in whole or in part is prohibited without 
// the written consent of the copyright owner.
//
#endregion

namespace Philips.PmsMR.UI.Infra.TestTask {
    class AttributeInfo {
        public ExecutionGroupRequirementTypes ExecutionGroup;
        public TimeRequirementType Time;
        public SystemStateRequirements SystemState;
        public bool Representative;
        public bool IgnoredCategory;
    }
}