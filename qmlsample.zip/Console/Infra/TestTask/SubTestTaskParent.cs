#region Copyright 2014 Koninklijke Philips N.V.
//
// All rights reserved. Reproduction in whole or in part is prohibited without 
// the written consent of the copyright owner.
//
#endregion

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using NUnit.Framework.Interfaces;
using Philips.PmsMR.UI.Infra.TestTask.Log;
using Philips.PmsMR.UI.Infra.TestTask.Remote;
using Philips.PmsMR.UI.Interfaces.Infra.Utilities.UnitTest.SourceChecks;

namespace Philips.PmsMR.UI.Infra.TestTask {
    /// <summary>
    /// A parent that nurtures a child process.
    /// </summary>
    [IgnoreMarshalByRefObject]
    public class SubTestTaskParent : MarshalByRefObject {
        public SubTestTaskParent() {
            OurURL = ChannelManager.Instance.SetupServer(this, "PhilipsTestTaskBeakon");
        }

        public void Reset(IEnumerable<ITest> tests, TestingOptions options) {
            Tests = tests.Select(x => x.FullName).ToArray();
            AssemblyFullNames = tests.Select(x => x.FixtureType.Assembly.Location).Distinct(StringComparer.InvariantCulture).ToArray();
            Options = options;
            FailedTests = new List<string>();
            SuccessCount = 0;
            SkipCount = 0;
        }

        public TestingOptions Options { get; private set; }

        public string OurURL { get; private set; }

        public IEnumerable<string> AssemblyFullNames { get; private set; }

        /// <summary>
        /// Tests to be executed by the subprocess.
        /// </summary>
        public IEnumerable<string> Tests { get; private set; }

        /// <summary>
        /// Number of successful tests reported by the subprocess.
        /// </summary>
        public int SuccessCount { get; set; }

        public IList<string> FailedTests { get; set; }

        public int SkipCount { get; set; }

        public void OnLogEntry(string msg, Exception optionalException, MessageType messageType) {
            Logging.Instance.WriteRemoteLogEntry(msg, optionalException, messageType);
        }

        public void OnTestResult(LoggableTestResult testResult)
        {
            Logging.Instance.WriteTestResult(testResult.Suite, testResult.TestName, testResult.DurationInSeconds, testResult.Passed);
        }

        /// <summary>
        /// A singleton.
        /// </summary>
        /// <returns></returns>
        public override object InitializeLifetimeService()
        {
            return null;
        }

        internal static void OnAppDomainedExecution() {
            var parent = AppDomain.CurrentDomain.GetData(ParentAppDomainDataKey) as SubTestTaskParent;

            Logging.instance = new Logging();
            bool retVal = false;
            try {
                Logging.instance.InstallParentLogger(parent);
                var task = new TestTask(parent) {
                    TestingOptions = parent.Options
                };

                // These have already been figured out by the parent
                task.TestingOptions.AssemblyNames = parent.AssemblyFullNames.Select(x => new FileInfo(x)).ToList();
                task.TestingOptions.TestNames = new HashSet<string>(parent.Tests);
                retVal = task.Execute();
            } finally {
                AppDomain.CurrentDomain.SetData(ReturnAppDomainDataKey, retVal);
                Logging.instance.Dispose();
            }
        }

        internal const string ParentAppDomainDataKey = "PhilipsMRTestTaskParent";
        internal const string ReturnAppDomainDataKey = "PhilipsMRTestTaskReturn";
    }
}