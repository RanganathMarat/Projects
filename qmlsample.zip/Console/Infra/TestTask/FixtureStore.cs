#region Copyright 2014 Koninklijke Philips N.V.
//
// All rights reserved. Reproduction in whole or in part is prohibited without 
// the written consent of the copyright owner.
//
#endregion

using System;
using System.Collections.Generic;
using NUnit.Framework.Interfaces;
using NUnit.Framework.Internal;

namespace Philips.PmsMR.UI.Infra.TestTask {
    class FixtureStore : IDisposable {
        public FixtureStore(TestExecutionContext context) {
            ExecutionContext = context;
            AppDomainedTests = new List<ITest>();
            SubProcessTests = new List<ITest>();
            IsolatedTests = new HashSet<ITest>();
        }
        public Type CurrentFixtureType;
        public ExecutionGroupRequirementTypes CurrentExecutionGroup;

        public TestExecutionContext ExecutionContext { get; private set; }

        public FixturePreparer Preparer { get; set; }

        public List<ITest> AppDomainedTests;

        public List<ITest> SubProcessTests;

        public HashSet<ITest> IsolatedTests;

        #region IDisposable
        /// <summary>
        /// Disposal flag.
        /// </summary>
        protected bool disposed;

        /// <summary>
        /// Dispose implementation.
        /// </summary>
        public void Dispose() {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Finalizer.
        /// </summary>
        ~FixtureStore() {
            Dispose(false);
        }

        /// <summary>
        /// Finalizer/disposal.
        /// </summary>
        /// <param name="disposing">Set when called from the explicit dispose</param>
        protected virtual void Dispose(bool disposing) {
            if (!disposed) {
                if (disposing) {
                    if (Preparer != null) {
                        Preparer.GroupTearDown();
                        Preparer = null;
                    }
                } else {
                    System.Diagnostics.Debug.Assert(false, "Forgot to dispose object of type FixtureStore");
                }
                disposed = true;
            }
        }

        /// <summary>
        /// A check for disposal.
        /// </summary>
        /// <exception cref="ObjectDisposedException">Throws if already disposed of</exception>
        protected void CheckDisposed() {
            if (disposed) {
                System.Diagnostics.Debug.Assert(false, "Trying to use disposed object of type FixtureStore");
                throw new ObjectDisposedException("FixtureStore");
            }
        }
        #endregion

    }
}