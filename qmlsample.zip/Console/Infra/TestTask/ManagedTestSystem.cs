#region Copyright 2014 Koninklijke Philips N.V.
//
// All rights reserved. Reproduction in whole or in part is prohibited without 
// the written consent of the copyright owner.
//
#endregion

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Remoting;
using System.Text;
using System.Threading;
using NUnit.Framework.Interfaces;
using NUnit.Framework.Internal;
using NUnit.Framework.Internal.Execution;
using Philips.PmsMR.UI.Infra.TestTask.Log;
using Philips.PmsMR.UI.Infra.Utilities.Misc;
using Philips.PmsMR.UI.Infra.Utilities.WinApi;
using Process = System.Diagnostics.Process;

namespace Philips.PmsMR.UI.Infra.TestTask {
    /// <summary>
    /// Runs .NET NUnitTests
    /// </summary>
    class ManagedTestSystem : TestSystem {

        private readonly TestingOptions options;
        private readonly CancellationTokenSource tokenSource;
        public ManagedTestSystem(TestingOptions options, CancellationTokenSource tokenSource) {
            this.options = options;
            this.tokenSource = tokenSource;
        }

        public override bool Execute() {
            bool ok = true;
            Logging.Instance.WriteLogInfoEntry("Looking for assemblies");
            using (var finder = new ManagedTestFinder(options, tokenSource)) {
                var tests = finder.GetSequentialTests();

                ok &= ExecuteTests(finder, tests);
                if (!ok && options.AbortOnFailure) {
                    return false;
                }

                if (options.Verbose) {
                    Logging.Instance.WriteLogInfoEntry("Managed tests executed");
                }
            }

            const bool forceFinalization = true;
            if (AssertTallier.CheckForUnhandledAsserts(forceFinalization)) {
                Logging.Instance.WriteLogErrorEntry("Unhandled assert detected after running all managed tests");
                ok = false;
            }

            return ok;
        }

        private bool ExecuteTests(ManagedTestFinder finder, IEnumerable<TestInfo> tests) {
            var context = new TestExecutionContext();
            using (var fixtureStore = new FixtureStore(context)) {
                bool retVal = true;
                List<TestInfo> cachedTestSuites = null;
                foreach (ExecutionGroupRequirementTypes executionGroup in new[] {
                    ExecutionGroupRequirementTypes.None, 
                    ExecutionGroupRequirementTypes.ExclusiveSystemOwnership
                }) {
                    if (TrySkippingExecutionGroup(executionGroup)) {
                        continue;
                    }
                    IEnumerable<TestInfo> tempTestSuiteCollection;
                    if (cachedTestSuites == null) {
                        cachedTestSuites = new List<TestInfo>();
                        tempTestSuiteCollection = tests;
                    } else {
                        // Second round - do not use exhausted iterator, but use the data collected on the first round
                        tempTestSuiteCollection = cachedTestSuites;
                    }
                    foreach (var suite in tempTestSuiteCollection) {
                        if (ReferenceEquals(tempTestSuiteCollection, tests)) {
                            cachedTestSuites.Add(suite);
                        }
                        var currentExecutionGroupData = executionGroup;
                        bool loggedAssemblyParticipation = false;
                        var testInfos = from test in suite.TestCases
                            let attributeInfo = finder.GetAttributeInfo(test)
                            where
                                (attributeInfo.ExecutionGroup & currentExecutionGroupData) != 0 ||
                                (currentExecutionGroupData == ExecutionGroupRequirementTypes.None && (ExplicitlyDefinedTestGroups & attributeInfo.ExecutionGroup) == 0)
                            orderby test.FullName
                            select new {
                                AttributeInfo = attributeInfo,
                                Test = test
                            };
                        foreach (var testInfo in testInfos) {
                            var test = testInfo.Test;
                            var attributeInfo = testInfo.AttributeInfo;
                            if (TrySkippingTest(attributeInfo, test, fixtureStore)) {
                                continue;
                            }

                            if (!loggedAssemblyParticipation) {
                                // This algorithm contained tests, log it
                                Logging.Instance.WriteLogInfoEntry("  Testing assembly " + suite.Assembly.Name);
                                loggedAssemblyParticipation = true;
                            }

                            // This will run the teardown for the previous fixture/setup for the test fixture 
                            // (if it has not been executed before)
                            fixtureStore.Preparer = new FixturePreparer(fixtureStore, test, attributeInfo);
                            TestCanary.KeepCanaryAlive();
                            var testResult = RunSingleTest(test, context, attributeInfo);

                            if (tokenSource.IsCancellationRequested) {
                                Logging.Instance.WriteLogWarningEntry("Testing aborted due to an explicit cancel request");
                                return false;
                            }

                            var status = testResult == null ? TestStatus.Failed : testResult.ResultState.Status;
                            switch (status) {
                                case TestStatus.Failed:
                                    retVal = false;
                                    FailedTests.Add(test.FullName);
                                    var builder = new StringBuilder();
                                    builder.AppendLine("Test failed: " + test.FullName);
                                    if (testResult != null) {
                                        builder.AppendLine(testResult.Message);
                                        builder.Append(testResult.StackTrace);
                                    }
                                    Logging.Instance.WriteLogErrorEntry(builder.ToString());
                                    Logging.Instance.WriteTestResult(suite.Assembly.Name, test.FullName, testResult.Duration.TotalSeconds, false);
                                    if (options.AbortOnFailure) {
                                        return false;
                                    }
                                    break;
                                case TestStatus.Passed:
                                    Logging.Instance.WriteTestResult(suite.Assembly.Name, test.FullName, testResult.Duration.TotalSeconds, true);
                                    ++SuccessTestCount;
                                    break;
                                case TestStatus.Skipped:
                                    ++SkipCount;
                                    break;
                                default:
                                    throw new ApplicationException(
                                        "Unknown result: " + testResult.ResultState.Status);
                            }
                        }
                    }
                }

                if (!TryExecuting(fixtureStore.AppDomainedTests, TryExecutingAppDomainedTests, fixtureStore.IsolatedTests)) {
                    return false;
                }

                if (!TryExecuting(fixtureStore.SubProcessTests, TryExecutingSubprocessTests, fixtureStore.IsolatedTests)) {
                    return false;
                }

                if (fixtureStore.Preparer == null && fixtureStore.AppDomainedTests.Count == 0 && fixtureStore.SubProcessTests.Count == 0) {
                    Logging.Instance.WriteLogErrorEntry("No tests found!");
                    return false;
                }

                return retVal;
            }

        }

        private bool TryExecuting(IEnumerable<ITest> tests, Func<List<ITest>, bool> executor, HashSet<ITest> isolationSet) {
            var nonIsolated = new List<ITest>();
            bool retVal = true;
            foreach (var test in tests) {
                if (isolationSet.Contains(test)) {
                    var logMessage = "Test is flagged as Isolated, running separately: " + test.Name;
                    if (options.Verbose) {
                        Logging.Instance.WriteLogInfoEntry(logMessage);
                    } else {
                        LogEvent.Instance.LogInfo(logMessage);
                    }
                    if (!executor(
                        new List<ITest> {
                            test
                        })) {
                        retVal = false;
                        if (options.AbortOnFailure) {
                            return false;
                        }
                    }
                } else {
                    nonIsolated.Add(test);
                }
            }
            if (nonIsolated.Count > 0) {
                retVal &= executor(nonIsolated);
            }
            return retVal;
        }

        private bool TryExecutingAppDomainedTests(List<ITest> appDomainedTests) {
            if (appDomainedTests.Count == 0) {
                return true;
            }

            Logging.Instance.WriteLogInfoEntry("Starting a testtask appdomain for " + appDomainedTests.Count + " tests.");
            if (parentRole == null) {
                parentRole = new SubTestTaskParent();
            }
            var subprocessParent = parentRole;
            var subOptions = options.CloneForSubtask();
            subOptions.TestSystems = TestingOptions.TestSystemTypes.NUnit;
            subprocessParent.Reset(appDomainedTests, subOptions);
            var setup = AppDomain.CurrentDomain.SetupInformation;
            setup.ApplicationBase = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            var dom = AppDomain.CreateDomain("AppDomained Tests", AppDomain.CurrentDomain.Evidence, setup);
            try {
                dom.SetData(SubTestTaskParent.ParentAppDomainDataKey, subprocessParent);

                using (TestCanary.SuspendCanary()) {
                    // Let the appdomained tests handle their own canaries
                    dom.DoCallBack(SubTestTaskParent.OnAppDomainedExecution);
                }

                SuccessTestCount += subprocessParent.SuccessCount;
                FailedTests.AddRange(subprocessParent.FailedTests);
                SkipCount += subprocessParent.SkipCount;
                if ((bool)dom.GetData(SubTestTaskParent.ReturnAppDomainDataKey)) {

                    const bool forceFinalization = true;
                    if (AssertTallier.CheckForUnhandledAsserts(forceFinalization)) {
                        Logging.Instance.WriteLogErrorEntry("Unhandled assert detected after running appdomained tests");
                        return false;
                    }

                    if (subprocessParent.SuccessCount != appDomainedTests.Count) {
                        Logging.Instance.WriteLogErrorEntry (
                        "Testtask execution count in appdomain - " + subprocessParent.SuccessCount + " - did not match expected " + appDomainedTests.Count);
                        var builder = new StringBuilder("Failed appdomain tests:\n");
                        foreach (var test in appDomainedTests) {
                            builder.AppendLine(test.FullName);
                        }
                        Logging.Instance.WriteLogErrorEntry(builder.ToString());
                        return false;
                    }

                    Logging.Instance.WriteLogInfoEntry(
                        "Testtask appdomain finished executing " + subprocessParent.SuccessCount + " successful tests");
                    return true;
                }

                return false;
            } catch (RemotingException e) {
                Logging.Instance.WriteLogErrorEntry("Testtask appdomain failed executing: " + e);
                return false;
            } catch (Exception e) {
                Logging.Instance.WriteLogErrorEntry("Testtask appdomain failed executing: " + e);
                throw;
            } finally {
                // This will fire DomainUnloaded event which will allow the tests to clean up
                AppDomain.Unload(dom);
            }
        }

        private bool TryExecutingSubprocessTests(List<ITest> subprocessTests) {
            if (subprocessTests.Count == 0) {
                return true;
            }

            Logging.Instance.WriteLogInfoEntry("Starting a testtask subprocess for " + subprocessTests.Count + " tests.");
            if (parentRole == null) {
                parentRole = new SubTestTaskParent();
            }
            var subprocessParent = parentRole;
            var subOptions = options.CloneForSubtask();
            subOptions.TestSystems = TestingOptions.TestSystemTypes.NUnit;
            subprocessParent.Reset(subprocessTests, subOptions);
            var process = new Process {
                StartInfo = new ProcessStartInfo {
                    Arguments = CreateSubprocessArguments(subprocessParent),
                    CreateNoWindow = true,
                    FileName = Assembly.GetExecutingAssembly().Location,
                    UseShellExecute = false,
                    WorkingDirectory = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)
                }
            };

            bool killed = false;
            try {
                var exitedEvent = new ManualResetEvent(false);
                process.EnableRaisingEvents = true;
                process.Exited += (sender, args) => exitedEvent.Set();
                process.Start();

                using (TestCanary.SuspendCanary()) {
                    // Let the subprocess handle its own canaries
                    WaitHandle.WaitAny(new[] {tokenSource.Token.WaitHandle, exitedEvent});
                }
            } finally {
                if (!process.HasExited) {
                    Logging.Instance.WriteLogErrorEntry("Failed to wait for the testtask subprocess to exit");
                    killed = true;
                    process.Kill();
                }
                SuccessTestCount += subprocessParent.SuccessCount;
                FailedTests.AddRange(subprocessParent.FailedTests);
                SkipCount += subprocessParent.SkipCount;
                Logging.Instance.WriteLogInfoEntry("Testtask subprocess finished executing " + subprocessParent.SuccessCount + " successful tests");
            }
            return !killed && process.ExitCode == 0;
        }

        private string CreateSubprocessArguments(SubTestTaskParent subprocessParent) {
            var ourProcess = ProcessId.CurrentProcessId;
            var basicArguments = String.Format(
                CultureInfo.InvariantCulture,
                "--parent_url {0} --parent_pid {1} --parent_start_time {2}",
                subprocessParent.OurURL,
                ourProcess.Pid,
                ourProcess.StartTimeTicks);

            var builder = new StringBuilder(basicArguments);
            if (options.Profiling) {
                builder.Append(" --profiling ");
            }
            return builder.ToString();
        }

        private TestResult RunSingleTest(ITest test, TestExecutionContext context, AttributeInfo attributeInfo) {
            var actualTest = test as Test;
            var workItem = WorkItem.CreateWorkItem(actualTest, null);
            workItem.InitializeContext(context);
            var syncBlock = new object();
            bool finished = false;
            EventHandler runCompleted = (sender, args) => {
                lock (syncBlock) {
                    finished = true;
                    Monitor.PulseAll(syncBlock);
                }
            };
            workItem.Completed += runCompleted;

            Logging.Instance.WriteLogInfoEntry("      " + test.Name + ((attributeInfo.Time & TimeRequirementType.Lengthy) != 0 ? " [Lengthy]" : ""));

            // Work item takes care of setup and teardown methods within execution
            workItem.Execute();

            workItem.Completed -= runCompleted;
            lock (syncBlock) {
                while (!finished) {
                    Monitor.Wait(syncBlock);
                }
            }
            Logging.Instance.WriteLogInfoEntry(
                String.Format(CultureInfo.InvariantCulture,
                    "      {0} {1}. Duration: {2}",
                    test.Name,
                    workItem.Result.ResultState.Status,
                    workItem.Result.Duration.ToString(@"hh\:mm\:ss\:fff", CultureInfo.InvariantCulture)));

            if ((attributeInfo.ExecutionGroup & ExplicitlyDefinedTestGroups) == 0) {
                string warningDetail = null;
                if (attributeInfo.Time == TimeRequirementType.None) {
                    if (workItem.Result.Duration > LengthyWarningLimit) {
                        warningDetail = "has not been marked as lengthy";
                    }
                } else if (attributeInfo.Time == TimeRequirementType.Lengthy) {
                    if (workItem.Result.Duration < LengthyWarningLimit) {
                        // Don't care, better to err in this direction
                    }
                }
                if (warningDetail != null) {
#if DEBUG
                    Logging.Instance.WriteLogWarningEntry(
                        String.Format(
                            CultureInfo.InvariantCulture,
                            "Test {0} " + warningDetail + ", but duration was {1} (limit: {2})",
                            test.FullName,
                            workItem.Result.Duration,
                            LengthyWarningLimit));
#endif
                }
            }

            const bool forceFinalization = false;
            if (AssertTallier.CheckForUnhandledAsserts(forceFinalization)) {
                Logging.Instance.WriteLogErrorEntry("Unhandled assert detected after running " + test.Name);
                return null;
            }

            return workItem.Result;
        }

        private bool TrySkippingTest(AttributeInfo attributeInfo, ITest test, FixtureStore fixtureStore) {
            if (options.TestNames != null) {
                // We have already explicitly selected this test to be run
            } else {
                if (test.RunState == RunState.Ignored) {
                    Logging.Instance.WriteLogInfoEntry(
                        String.Format(CultureInfo.InvariantCulture, "      {0} skipped (explicitly ignored)", test.Name));
                    return true;
                }

                if (attributeInfo.IgnoredCategory) {
                    if (options.Verbose) {
                        Logging.Instance.WriteLogInfoEntry(
                            String.Format(CultureInfo.InvariantCulture, "      {0} skipped (category ignored)", test.Name));
                    }
                    return true;
                }

                if ((attributeInfo.SystemState & SystemStateRequirements.ManualExecution) != 0) {
                    if (options.Verbose) {
                        Logging.Instance.WriteLogInfoEntry(
                            String.Format(CultureInfo.InvariantCulture, "      {0} skipped (category manual)", test.Name));
                    }
                    return true;
                }

                if ((attributeInfo.SystemState & SystemStateRequirements.AdminRights) != 0) {
                    if (!UserProcess.HasAdminRights) {
                        Logging.Instance.WriteLogInfoEntry(
                            String.Format(CultureInfo.InvariantCulture, "      {0} skipped, (no admin rights)", test.Name));
                        return true;
                    }
                }

                if ((attributeInfo.SystemState & SystemStateRequirements.NoAdminRights) != 0) {
                    if (UserProcess.HasAdminRights) {
                        Logging.Instance.WriteLogInfoEntry(
                            String.Format(CultureInfo.InvariantCulture, "      {0} skipped, (admin rights)", test.Name));
                        return true;
                    }
                }

                if ((attributeInfo.SystemState & SystemStateRequirements.DebugOnly) != 0) {
#if DEBUG
#else
                    Logging.Instance.WriteLogInfoEntry(
                            String.Format(CultureInfo.InvariantCulture, "      {0} skipped, (release build)", test.Name));
                    return true;
#endif
                }

            }

            if ((attributeInfo.SystemState & SystemStateRequirements.Isolated) != 0) {
                if ((attributeInfo.SystemState &
                     (SystemStateRequirements.TestTaskProcess | SystemStateRequirements.AppDomained)) == 0) {
                    throw new ApplicationException("Test has been declared as isolated, but TestTaskProcess/AppDomained category has not been given");
                }
                fixtureStore.IsolatedTests.Add(test);
            }

            if ((attributeInfo.SystemState & SystemStateRequirements.TestTaskProcess) != 0) {
                if (!ExecutedAsTestTask) {
                    // Postpone execution to a separate process
                    fixtureStore.SubProcessTests.Add(test);
                    return true;
                }
            }

            if ((attributeInfo.SystemState & SystemStateRequirements.AppDomained) != 0) {
                if (ExecutedInOriginalTestTaskAppDomain) {
                    // Postpone execution to a separate appdomain
                    fixtureStore.AppDomainedTests.Add(test);
                    return true;
                }
            }

            return false;
        }

        private bool TrySkippingExecutionGroup(ExecutionGroupRequirementTypes key) {

            if ((key & ExplicitlyDefinedTestGroups) == 0) {
                if (!CategoriesThatNeedUndefinedTests.Overlaps(options.TestCategoryTypes)) {
                    Logging.Instance.WriteLogInfoEntry(
                        "Skipping undefined category tests, test categories do not require them");
                    return true;
                }
                Logging.Instance.WriteLogInfoEntry("Undefined-category tests:");
                return false;
            }
            if ((key & ExecutionGroupRequirementTypes.ExclusiveSystemOwnership) != 0) {
                if (!CategoriesThatNeedSystemControl.Overlaps(options.TestCategoryTypes)) {
                    Logging.Instance.WriteLogInfoEntry(
                        "Skipping system controller tests, test categories do not require them");
                    return true;
                }
                Logging.Instance.WriteLogInfoEntry("SystemController-category tests:");
                return false;
            }
            throw new NotImplementedException("Unknown execution group: " + key);
        }

        private bool ExecutedInOriginalTestTaskAppDomain {
            get {
                return AppDomain.CurrentDomain.GetData(SubTestTaskParent.ParentAppDomainDataKey) == null;
            }
        }

        internal static readonly bool ExecutedAsTestTask =
            StringComparer.InvariantCulture.Equals(
                Process.GetCurrentProcess().ProcessName.ToLower(),
                Path.GetFileNameWithoutExtension(Assembly.GetExecutingAssembly().Location).ToLower());

        internal const ExecutionGroupRequirementTypes ExplicitlyDefinedTestGroups =
            ExecutionGroupRequirementTypes.ExclusiveSystemOwnership;

        private SubTestTaskParent parentRole;

        private static readonly HashSet<TestCategoryType> CategoriesThatNeedUndefinedTests =
            new HashSet<TestCategoryType> { TestCategoryType.BuildTests, TestCategoryType.Undefined, TestCategoryType.UnitTests };
        private static readonly HashSet<TestCategoryType> CategoriesThatNeedSystemControl =
            new HashSet<TestCategoryType> { TestCategoryType.BuildTests, TestCategoryType.UnitTests, TestCategoryType.SystemController };

        private static readonly TimeSpan LengthyWarningLimit = TimeSpan.FromSeconds(2.0);
    }
}