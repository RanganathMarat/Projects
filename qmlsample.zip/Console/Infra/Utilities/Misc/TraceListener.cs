#region Copyright Koninklijke Philips Electronics N.V. 2006-2007
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
#endregion

using System;
using System.Diagnostics;
using System.Threading;
using Philips.PmsMR.UI.Infra.Utilities.Systems;

namespace Philips.PmsMR.UI.Infra.Utilities.Misc
{

    /// <summary>
    /// Customized, suppressable debug asserter and debugger autoattacher
    /// </summary>
    public class TraceListener : System.Diagnostics.DefaultTraceListener
    {

        /// <summary>
        /// Default ctor - will examine application settings
        /// to deduce debugger autoattaching.
        /// </summary>
        public TraceListener()
            : this(false)
        {
        }

        /// <summary>
        /// Replaces the default trace listener by itself.
        /// </summary>
        /// <param name="forceAutoattaching">If set, skips autoattaching tests</param>
        public TraceListener(bool forceAutoattaching)
        {
            bool profiling = IsProfiling();

            if (!Awareness.IsUnderBuildTest())
            {
                if (profiling)
                {
                    return;
                }
            }

            InstallListener();
        }

        #region IDisposable
        /// <summary>
        /// Disposal/Finalizing.
        /// </summary>
        /// <param name="disposing">Set if disposing</param>
        protected override void Dispose(bool disposing)
        {
            if (oldListener != null)
            {
                // Restore situation
                Debug.Listeners.Add(oldListener);
                Debug.Listeners.Remove(this);
                oldListener = null;
            }
            base.Dispose(disposing);
        }
        #endregion

        /// <summary>
        /// Suppressable failures
        /// </summary>
        /// <param name="message">as per DefaultTraceListener</param>
        /// <param name="detailMessage">as per DefaultTraceListener</param>
        public override void Fail(string message, string detailMessage)
        {
            var globalWait = AssertSuppressor.CreateSemaphore(GlobalAssertSuppressionReleaseCount, GlobalAssertSuppressionReleaseCount);
            globalWait.WaitOne();
            int currentCount = globalWait.Release();

            bool assertSuppressed = true;
            bool globalAssertSuppression = currentCount != GlobalAssertSuppressionReleaseCount - 1;
            if (!globalAssertSuppression)
            {
                object domainSuppression = AppDomain.CurrentDomain.GetData(AssertSuppressor.GlobalAssertSuppressionName);
                bool domainSuppressed = domainSuppression != null && (bool)domainSuppression;
                if (!domainSuppressed)
                {
                    bool logicalCallContextSuppressed = AssertSuppressor.IsLogicalCallContextSuppressed();
                    if (!logicalCallContextSuppressed)
                    {
                        assertSuppressed = false;
                    }
                }
            }


            if (!assertSuppressed)
            {
#if (DEBUG || NUnitTest)
                // Prevents visual studio lock-ups with ill-timed asserts
                if (Debugger.IsAttached)
                {
                    Debugger.Break();
                    return;
                }
#endif
                // TODO: LogError("Unhandled assert: " + message + ", detail: " + detailMessage + ". Stack: " + new StackTrace());
                var unhandledAssertEvent = new EventWaitHandle(false, EventResetMode.ManualReset, UnhandledAssertEventName);
                unhandledAssertEvent.Set();
                base.Fail(message, detailMessage);
            }
        }

        /// <summary>
        /// Global name for the unhandled assert event.
        /// </summary>
        public const String UnhandledAssertEventName = "TraceUnhandledAssert";

        #region Private methods
        private void InstallListener()
        {
            foreach (var traceListener in Debug.Listeners)
            {
                if (traceListener is TraceListener)
                {
                    // NOP, we already have an listener
                    oldListener = null;
                    return;
                }
                if (traceListener is DefaultTraceListener)
                {
                    oldListener = traceListener as System.Diagnostics.TraceListener;
                }
            }

            Debug.Listeners.Remove("Default");
            Debug.Listeners.Add(this);
        }


        private static bool IsProfiling()
        {
            string profilingStr = Environment.GetEnvironmentVariable("COR_ENABLE_PROFILING");
            if (!String.IsNullOrEmpty(profilingStr))
            {
                if (profilingStr.ToLower(System.Globalization.CultureInfo.InvariantCulture) == "0x1")
                {
                    return true;
                }
                try
                {
                    return (Convert.ToInt32(profilingStr, System.Globalization.CultureInfo.InvariantCulture) != 0);
                }
                catch (FormatException)
                {
                    try
                    {
                        return Convert.ToInt32(profilingStr, 16) != 0;
                    }
                    catch (FormatException)
                    {
                        return Convert.ToBoolean(profilingStr, System.Globalization.CultureInfo.InvariantCulture);
                    }
                }
            }

            return false;
        }

        #endregion

        internal const int GlobalAssertSuppressionReleaseCount = 16384;

        private System.Diagnostics.TraceListener oldListener;
    }
}
