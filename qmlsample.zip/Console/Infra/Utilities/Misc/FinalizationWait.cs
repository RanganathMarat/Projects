#region Copyright Koninklijke Philips Electronics N.V. 2006
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
#endregion

using System;
using System.Threading;

namespace Philips.PmsMR.UI.Infra.Utilities.Misc {
    /// <summary>
    /// Helper class to support performing garbage collection and waiting pending finalizers
    /// with timeout.
    /// </summary>
    /// <remarks>
    /// Should be used only in situations that require that objects finalizer is called before
    /// continuing. This should be a rare situation!
    /// </remarks>
    public class FinalizationWait {

        /// <summary>
        /// Perform garbage collection and wait for pending finalizers.
        /// </summary>
        /// <param name="timeout">Timeout in ms to wait for finalization</param>
        /// <returns>True if succesfully finalized</returns>
        public bool CollectAndWaitForPendingFinalizers(int timeout) {
            lock (this) {
                completed = false;

                var thread = new Thread(WaitForFinalizationWorker);
                thread.Start();

                if (!completed) {
                    if (!Monitor.Wait(this, timeout)) {
                        thread.Abort();
                        return false;
                    }
                }
                System.Diagnostics.Debug.Assert(completed);
            }
            return true;
        }

        #region Private
        private void WaitForFinalizationWorker() {
            Thread.CurrentThread.Name = "WaitForFinalization";

            GC.Collect();
            GC.WaitForPendingFinalizers();

            lock (this) {
                completed = true;
                Monitor.PulseAll(this);
            }
        }

        private bool completed;
        #endregion
    }
}
