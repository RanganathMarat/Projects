﻿#region Copyright Koninklijke Philips Electronics N.V. 2010
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
#endregion

using System;
using System.Globalization;
using Philips.PmsMR.UI.Interfaces.Infra.Utilities.Misc;

namespace Philips.PmsMR.UI.Infra.Utilities.Misc {

    /// <summary>
    /// Process id implementation.
    /// </summary>
    [Serializable]
    public class ProcessId : IProcessId {

        /// <summary>
        /// Source data copying ctor.
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="startTime"></param>
        public ProcessId(int pid, DateTime startTime) {
            Pid = pid;
            StartTimeTicks = startTime.Ticks;
        }

        /// <summary>
        /// Source data extracting ctor.
        /// </summary>
        /// <param name="srcProcess"></param>
        public ProcessId(System.Diagnostics.Process srcProcess) {
            Pid = srcProcess.Id;
            StartTimeTicks = srcProcess.StartTime.Ticks;
        }

        /// <summary>
        /// Pid of the source process.
        /// </summary>
        public int Pid { get; private set; }

        /// <summary>
        /// Start time of the source process.
        /// </summary>
        public Int64 StartTimeTicks { get; private set; }

        /// <summary>
        /// Access the underlying process - null if not valid.
        /// </summary>
        public System.Diagnostics.Process UnderlyingProcess {
            get {
                try {
                    var process = System.Diagnostics.Process.GetProcessById(Pid);
                    if (process == null) {
                        return null;
                    }
                    if (process.StartTime.Ticks == StartTimeTicks) {
                        return process;
                    }
                } catch (ArgumentException) {
                } catch (System.ComponentModel.Win32Exception) {
                } catch (InvalidOperationException) { }
                return null;
            }
        }

        /// <summary>
        /// Unique id string.
        /// </summary>
        public string Id {
            get { return String.Format(CultureInfo.InvariantCulture, "{0}:{1}", Pid, StartTimeTicks);}
        }

        /// <summary>
        /// Information about the current process
        /// </summary>
        public static ProcessId CurrentProcessId {
            get {
                var current = System.Diagnostics.Process.GetCurrentProcess();
                return new ProcessId(current.Id, current.StartTime);
            }
        }

        #region IEquatable<IProcessId> Members

        /// <summary>
        /// Process id equals implementation.
        /// </summary>
        /// <param name="other"></param>
        /// <returns></returns>
        public bool Equals(IProcessId other) {
            if (other == null) {
                return false;
            }
            return Pid == other.Pid && StartTimeTicks == other.StartTimeTicks;
        }

        #endregion

        #region IComparable<IProcessId> Members

        /// <summary>
        /// Process id comparison implementation.
        /// </summary>
        /// <param name="other"></param>
        /// <returns></returns>
        public int CompareTo(IProcessId other) {
            if (other == null) {
                return -1;
            }
            int pidDiff = Pid.CompareTo(other.Pid);
            return pidDiff == 0 ? StartTimeTicks.CompareTo(other.StartTimeTicks) : pidDiff;
        }

        #endregion

        /// <summary>
        /// Equals override.
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public override bool Equals(object obj) {
            if (obj == null) {
                return false;
            }
            if (obj is IProcessId) {
                return Equals((IProcessId)obj);
            }
            return false;
        }

        /// <summary>
        /// GetHashCode override.
        /// </summary>
        /// <returns></returns>
        public override int GetHashCode() {
            return Pid.GetHashCode();
        }

        /// <summary>
        /// String conversion override.
        /// </summary>
        /// <returns></returns>
        public override string ToString() {
            return String.Format(
                CultureInfo.InvariantCulture,
                "Process Id {0} (start time {1})",
                Pid,
                new DateTime(StartTimeTicks));
        }
    }

}
