#region Copyright Koninklijke Philips Electronics N.V. 2006
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
#endregion

using System;
using System.Diagnostics;
using System.Security.AccessControl;
using System.Security.Principal;
using System.Threading;
using Philips.PmsMR.UI.Interfaces.Infra.Utilities.UnitTest.SourceChecks;

namespace Philips.PmsMR.UI.Infra.Utilities.Misc {

    /// <summary>
    /// Suppresses debug asserts and tracing when the object is not disposed.
    /// </summary>
    /// <remarks>
    /// Suppressing is based on the call-context (including remote-calls).
    /// Note that if you have a strcture where the asserts are spawned from
    /// another thread, but as a consequence of your call, the suppression
    /// needs to be created explicitly in the other threads. For example:
    /// when unloading an appdomain.
    /// </remarks>
    /// <example>
    /// <code>
    /// using (new AssertSuppressor()) {
    /// ...
    ///     // NOP
    ///     System.Diagnostics.Debug.Assert(false);
    /// ...
    /// }
    /// </code>
    /// </example>
    public class AssertSuppressor : IDisposable {

        /// <summary>
        /// Default ctor.
        /// </summary>
        /// <remarks>
        /// Suppresses only those asserts that are generated within the call context.
        /// </remarks>
        public AssertSuppressor() : this(false) {
        }

        /// <summary>
        /// Initializing ctor
        /// </summary>
        /// <param name="globalSuppression">
        /// If set, will suppress asserts in all components (i.e., users of TraceListeners).
        /// If reset, will suppress only those asserts that are generated within the call context
        /// </param>
        public AssertSuppressor(bool globalSuppression) {
            if (!globalSuppression) {
                var data = System.Runtime.Remoting.Messaging.CallContext.LogicalGetData(CallContextTag) as AssertSuppressingData;
                if (data == null) {
                    System.Runtime.Remoting.Messaging.CallContext.LogicalSetData(CallContextTag, new AssertSuppressingData());
                    set = true;
                }
            } else {
                globalWait = CreateSemaphore(TraceListener.GlobalAssertSuppressionReleaseCount, TraceListener.GlobalAssertSuppressionReleaseCount);
                globalWait.WaitOne();
            }
        }

        /// <summary>
        /// Test for assert suppression in the current logical call context.
        /// </summary>
        /// <returns></returns>
        public static bool IsLogicalCallContextSuppressed() {
            var currentData =
                System.Runtime.Remoting.Messaging.CallContext.LogicalGetData(CallContextTag);
            return currentData != null;
        }

        /// <summary>
        /// Suppresses asserts from the current domain.
        /// </summary>
        /// <param name="suppress"></param>
        [Conditional("DEBUG")]
        public static void SuppressDomainAsserts(bool suppress) {
            AppDomain.CurrentDomain.SetData(GlobalAssertSuppressionName, suppress);
        }

        /// <summary>
        /// Global name for assert suppression domain key/semaphore.
        /// </summary>
        public const String GlobalAssertSuppressionName = "TraceAssertsGloballySuppressed";

        #region IDisposable Methods
        /// <summary>
        /// Disposing of the instance.
        /// </summary>
        public void Dispose() {
            if (set) {
                // It was us!
                var data = System.Runtime.Remoting.Messaging.CallContext.LogicalGetData(CallContextTag) as AssertSuppressingData;
                if (data != null)
                {
                    System.Runtime.Remoting.Messaging.CallContext.FreeNamedDataSlot(CallContextTag);
                }
            }

            if (globalWait != null) {
                globalWait.Release();
                globalWait.Close();
            }
        }
        #endregion

        internal static Semaphore CreateSemaphore(int initialCount, int maximumCount) {
            var security = new SemaphoreSecurity();
            var sID = new SecurityIdentifier(WellKnownSidType.WorldSid, null);
            var rule = new SemaphoreAccessRule(sID, SemaphoreRights.FullControl, AccessControlType.Allow);
            security.AddAccessRule(rule);

            bool createdNew;
            return new Semaphore(initialCount, maximumCount, @"Global\" + GlobalAssertSuppressionName, out createdNew, security);
        }

        [IgnoreMarshalByRefObject]
        internal class AssertSuppressingData : MarshalByRefObject, System.Runtime.Remoting.Messaging.ILogicalThreadAffinative {
        }

        internal const String CallContextTag = "PhilipsTraceSuppressor";

        private readonly bool set;

        private readonly Semaphore globalWait;
    }

}
