﻿#region Copyright Koninklijke Philips Electronics N.V. 2010
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
#endregion

using System;
using System.Threading;
using Philips.PmsMR.UI.Interfaces.Infra.Utilities.Misc;

namespace Philips.PmsMR.UI.Infra.Utilities.Misc {

    /// <summary>
    /// Wrapper for the diagnostic process class.
    /// </summary>
    public class Process : IProcess {

        /// <summary>
        /// Initializing ctor.
        /// </summary>
        /// <param name="process"></param>
        public Process(System.Diagnostics.Process process) {
            this.process = process;
        }

        /// <summary>
        /// Converts an id to an existing process into a process object.
        /// </summary>
        /// <param name="existingProcess"></param>
        /// <returns></returns>
        public static IProcess Convert(IProcessId existingProcess) {
            var process = System.Diagnostics.Process.GetProcessById(existingProcess.Pid);
            if (process.StartTime.Ticks == existingProcess.StartTimeTicks) {
                return new Process(process);
            }
            return null;
        }

        /// <summary>
        /// Auxiliary method to read standard streams without deadlocks.
        /// </summary>
        /// <remarks>
        /// If process wait for exit is called, or streams are read in incorrect order, a child process will deadlock.
        /// </remarks>
        /// <param name="process"></param>
        /// <param name="stdOutHandler">Handler for reading standard output stream line at a time</param>
        /// <param name="stdErrHandler">Handler for reading standard error stream line at a time</param>
        /// <param name="cancellationToken">Token for cancelling the stream reading by killing the process</param>
        /// <param name="timeoutInMS">Instead of cancellation, the maximum wait time for the function call can be given explicitly</param>
        /// <returns>False if the process timeouts</returns>
        public static bool SafeStandardStreamRead(
            System.Diagnostics.Process process, 
            Action<string> stdOutHandler = null, 
            Action<string> stdErrHandler = null, 
            CancellationToken? cancellationToken = null,
            int timeoutInMS = int.MaxValue) {
            Action<object, System.Diagnostics.DataReceivedEventArgs, Action<string>> handler = (s, e, act) => {
                var data = e.Data;
                if (data == null) {
                    return;
                }
                act(data);                
            };

            if (process.StartInfo.RedirectStandardOutput) {
                if (stdOutHandler == null) {
                    throw new ArgumentException("RedirectStandardOutput was defined but a handler was not given", "stdOutHandler");
                }
                process.OutputDataReceived += (s, e) => handler(s, e, stdOutHandler);
                process.BeginOutputReadLine();
            }
            if (process.StartInfo.RedirectStandardError) {
                if (stdErrHandler == null) {
                    throw new ArgumentException("RedirectStandardError was defined but a handler was not given", "stdOutHandler");
                }
                process.ErrorDataReceived += (s, e) => handler(s, e, stdErrHandler);
                process.BeginErrorReadLine();
            }           
            
            if (cancellationToken != null) {
                cancellationToken.Value.Register(process.Kill);
            }
            if (!process.WaitForExit(timeoutInMS)) {
                return false;
            }
            return cancellationToken != null ? 
                !cancellationToken.Value.IsCancellationRequested :
                true;
        }

        #region IProcess Members

        /// <summary>
        /// Process lifetime event.
        /// </summary>
        public event EventHandler Exited {
            add {
                process.Exited += value;
            }
            remove {
                process.Exited -= value;
            }
        }

        /// <summary>
        /// Process exit status.
        /// </summary>
        public bool HasExited {
            get { return process.HasExited; }
        }

        /// <summary>
        /// Process event status.
        /// </summary>
        public bool EnableRaisingEvents { get { return process.EnableRaisingEvents;} set { process.EnableRaisingEvents = value;} }

        /// <summary>
        /// Process id conversion.
        /// </summary>
        public IProcessId Id { get { return new ProcessId(process); } }
        #endregion

        /// <summary>
        /// Descriptive string.
        /// </summary>
        /// <returns></returns>
        public override string ToString() {
            return Id.ToString();
        }

        private readonly System.Diagnostics.Process process;
    }

}
