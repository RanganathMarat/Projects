#region Copyright Koninklijke Philips Electronics N.V. 2006
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
#endregion 
using System;
using System.Collections.Generic;
using System.Text;

#if NUnitTest
using NUnit.Framework;
using System.Diagnostics;
#pragma warning disable 1591
namespace P5.Private.Utilities.Misc.Tests {
    [TestFixture]
    public class AssertSuppressing {

        [Test]
        public void SuppressAssertation() {
            HifuTraceListener customListener = new HifuTraceListener();
            using (new AssertSuppressor()) {
                System.Diagnostics.Debug.Assert(false);
            }
            GC.KeepAlive(customListener);
        }

        [Test]
        public void TryDoubleListening() {
            HifuTraceListener customListener = new HifuTraceListener();
            HifuTraceListener customListener2 = new HifuTraceListener();

            int listenerCount = 0;
            foreach (TraceListener listener in Debug.Listeners) {
                if (listener is HifuTraceListener) {
                    ++listenerCount;
                }
            }
            Assert.IsTrue(listenerCount == 1);

            using (new AssertSuppressor()) {
                System.Diagnostics.Debug.Assert(false);
            }
            GC.KeepAlive(customListener);
            GC.KeepAlive(customListener2);
        }

        [Test]
        public void TryDoubleSuppressing() {
            HifuTraceListener customListener = new HifuTraceListener();
            using (new AssertSuppressor()) {
                using (new AssertSuppressor()) {
                    System.Diagnostics.Debug.Assert(false);
                }
            }
            GC.KeepAlive(customListener);
        }
    }
}
#pragma warning restore 1591
#endif // NUnitTest