#region Copyright Koninklijke Philips Electronics N.V. 2005-2011
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
#endregion

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.Contracts;
using System.Security.AccessControl;
using System.Security.Principal;
using System.Threading;
using Philips.PmsMR.UI.Interfaces.Infra.Utilities.Log;

namespace Philips.PmsMR.UI.Infra.Utilities.Log
{

    /// <summary>
    /// Abstract base class to be inherited by namespace specific LogEvent classes.
    /// </summary>
    /// <remarks>
    /// <para>
    /// There are four logging levels:
    /// <list>
    /// <item>Error: fatal errors from which recovery is not possible</item>
    /// <item>Warning: warnings and minor errors where recovery is possible</item>
    /// <item>Info: informational entries</item>
    /// <item>Debug: entries that might help to solve dynamic behaviour problems at field for example
    /// hardware communication</item>
    /// </list>
    /// </para>
    /// <para>
    /// To create a class logger that reflects the class name and uses it as a prefix on log messages:
    /// <code>
    /// class MyClass {
    ///     private static readonly LogEvent Log = LogEvent.CreateClassLog();
    /// }
    /// </code>
    /// To create a standalone logger:
    /// <code>
    /// using Log = Philips.PmsMR.UI.Infra.Utilities.Log;
    ///
    /// namespace Application {
    ///     internal sealed class LogEvent : Log.LogEvent {
    ///         public static Log.LogEvent Instance {
    ///             get {
    ///                 return SafeCreateInstance(typeof(LogEvent));
    ///             }
    ///         }
    ///     }
    /// }
    /// </code>
    /// </para>
    /// </remarks>
    abstract public class LogEvent : ILogEvent
    {
        static LogEvent()
        {
            bool created;
            var security = new MutexSecurity();
            var sID = new SecurityIdentifier(WellKnownSidType.WorldSid, null);
            var rule = new MutexAccessRule(sID, MutexRights.FullControl, AccessControlType.Allow);
            security.AddAccessRule(rule);
            namedMutex = new Mutex(false, @"Global\PhilipsMRLoggerD81F905106894748BA9DACFD36F7E273", out created, security);
        }

        #region ILogEvent Members

        /// <summary>
        /// Log error message.
        /// </summary>
        /// <param name="description"></param>
        public void LogError(string description)
        {
            PerformLog(LogLevel.Error, 0, description, null);
        }

        /// <summary>
        /// Log error message with associated exception.
        /// </summary>
        /// <param name="description"></param>
        /// <param name="e"></param>
        public void LogError(string description, Exception e)
        {
            PerformLog(LogLevel.Error, 0, description, e);
        }

        /// <summary>
        /// Log warning message.
        /// </summary>
        /// <param name="description">A warning message</param>
        public void LogWarning(string description)
        {
            PerformLog(LogLevel.Warning, 0, description, null);
        }

        /// <summary>
        /// Log warning message with an associated exception.
        /// </summary>
        /// <param name="description">A warning message</param>
        /// <param name="e">The associated exception</param>
        public void LogWarning(string description, Exception e)
        {
            PerformLog(LogLevel.Warning, 0, description, e);
        }

        /// <summary>
        /// Log info message.
        /// </summary>
        /// <param name="description"></param>
        public void LogInfo(string description)
        {
            PerformLog(LogLevel.Info, 0, description, null);
        }

        /// <summary>
        /// Log info message with associated exception.
        /// </summary>
        /// <param name="description"></param>
        /// <param name="e"></param>
        public void LogInfo(string description, Exception e)
        {
            PerformLog(LogLevel.Info, 0, description, e);
        }

        /// <summary>
        /// Log debug message.
        /// </summary>
        /// <param name="description"></param>
        public void LogDebug(string description)
        {
            PerformLog(LogLevel.Debug, 0, description, null);
        }

        /// <summary>
        /// Log debug message with associated exception.
        /// </summary>
        /// <param name="description"></param>
        /// <param name="e"></param>
        public void LogDebug(string description, Exception e)
        {
            PerformLog(LogLevel.Debug, 0, description, e);
        }

        #endregion

        /// <summary>
        /// Class-specific log, prepends the class name to generated log messages.
        /// </summary>
        /// <returns></returns>
        public static LogEvent CreateClassLog()
        {
            var stack = new StackTrace();

            string ns = "<unknown>";
            string name = "<unknown>";
            for (int indx = 1; indx < stack.FrameCount; ++indx)
            {
                var stackFrame = stack.GetFrame(indx);
                var method = stackFrame.GetMethod();
                var declaringType = method.DeclaringType;
                if (!declaringType.IsGenericType)
                {
                    ns = declaringType.Namespace;
                    name = declaringType.Name;
                    break;
                }
            }

            return CreateInstance(null, new ClassLog(ns, name));
        }

        #region Protected methods

        /// <summary>
        /// Protected constructor. Since log event should be singleton object, inheriting class should also not 
        /// have a public constructor.
        /// </summary>
        protected LogEvent()
        {
            Init("", null, GetType().Namespace);
        }

        /// <summary>
        /// Create a an LogEvent instance thread safely.
        /// </summary>
        /// <param name="type">Log-class to be created</param>
        /// <returns>A log-class instance on success</returns>
        protected static LogEvent SafeCreateInstance(Type type)
        {
            return CreateInstance(type, null);
        }

        /// <summary>
        /// Additional prefix to be pre-pended to the log messages.
        /// </summary>
        protected string Prefix { get; set; }
        #endregion

        #region Private

        private static LogEvent CreateInstance(Type type, LogEvent precreatedEvent)
        {
            Contract.Ensures(Contract.Result<LogEvent>() != null);
            lock (syncBlock)
            {
                LogEvent instance = precreatedEvent;
                if (instance != null || !instanceDictionary.TryGetValue(type, out instance))
                {
                    if (instance == null)
                    {
                        Type[] types = Type.EmptyTypes;
                        instance = (LogEvent)type.GetConstructor(types).Invoke(null);
                        instanceDictionary[type] = instance;
                    }
                }

                return instance;
            }
        }

        private string FormattedDescription(string description)
        {
            return Prefix == null ? description : Prefix + description;
        }

        private void PerformLog(LogLevel logLevel, int eventId, string description, Exception exception)
        {
            var timestamp = DateTime.UtcNow;
            var message = exception != null ?
                    FormattedDescription(description) + Environment.NewLine + exception :
                    FormattedDescription(description);

            // TODO: a simple console logger, replace with MR SW logger
            bool acquiredMutex = false;
            try
            {
                try
                {
                    namedMutex.WaitOne();
                }
                catch (AbandonedMutexException)
                {
                }
                acquiredMutex = true;

                switch (logLevel)
                {
                    case LogLevel.Debug:
                        Console.Out.WriteLine(timestamp + ":D: " + message);
                        break;
                    case LogLevel.Info:
                        Console.Out.WriteLine(timestamp + ":I: " + message);
                        break;
                    case LogLevel.Warning:
                        Console.Error.WriteLine(timestamp + ":W: " + message);
                        break;
                    case LogLevel.Error:
                        Console.Error.WriteLine(timestamp + ":E: " + message);
                        break;
                    default:
                        throw new ApplicationException("Unknown log level: " + logLevel);
                }
            }
            finally
            {
                if (acquiredMutex)
                {
                    namedMutex.ReleaseMutex();
                }
            }
        }

        class ClassLog : LogEvent
        {
            public ClassLog(string ns, string name)
                : this(ns, name, name + " ")
            {
            }

            private ClassLog(string ns, string name, string explicitPrefix)
            {
                Prefix = explicitPrefix;
            }
        }

        private void Init(string componentId, string idRangeName, string nameSpace)
        {
        }

        #endregion

        #region Private fields
        private static readonly object syncBlock = new object();
        private static readonly IDictionary<Type, LogEvent> instanceDictionary = new Dictionary<Type, LogEvent>();
        private static readonly Mutex namedMutex;
        #endregion
    }
}
