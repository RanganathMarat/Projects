#region Copyright Koninklijke Philips Electronics N.V. 2005-2011
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
#endregion
using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace Philips.PmsMR.UI.Infra.Utilities.Log {
    /// <summary>
    /// Abstract base class to be inherited by namespace specific LogEvent classes.
    /// </summary>
    /// <remarks>
    /// <para>
    /// There are four logging levels:
    /// <list>
    /// <item>Error: fatal errors from which recovery is not possible</item>
    /// <item>Warning: warnings and minor errors where recovery is possible</item>
    /// <item>Info: informational entries</item>
    /// <item>Debug: entries that might help to solve dynamic behaviour problems at field for example
    /// hardware communication</item>
    /// </list>
    /// </para>
    /// <para>
    /// Implement following class in each namespace using logging and update LogOriginatorIds.xml.
    /// <code>
    /// using Log = Philips.PmsMR.UI.Infra.Utilities.Log;
    ///
    /// namespace Philips.PmsMR.UI.Application {
    ///     internal sealed class LogEvent : Log.LogEvent {
    ///         public static Log.LogEvent Instance {
    ///             get {
    ///                 return SafeCreateInstance(typeof(LogEvent));
    ///             }
    ///         }
    ///     }
    /// }
    /// </code>
    /// </para>
    /// </remarks>
    abstract public class LogEvent : Interfaces.Utilities.Log.ILogEvent {

        #region ILogEvent Members

        /// <summary>
        /// Log error message.
        /// </summary>
        /// <param name="description"></param>
        public void LogError(string description) {
            PerformLog(LogLevel.Error, 0, description, null);
        }

        /// <summary>
        /// Log error message with associated exception.
        /// </summary>
        /// <param name="description"></param>
        /// <param name="e"></param>
        public void LogError(string description, Exception e) {
            PerformLog(LogLevel.Error, 0, description, e);
        }

        /// <summary>
        /// Log error message with event id.
        /// </summary>
        /// <param name="eventId"></param>
        /// <param name="description"></param>
        public void LogError(int eventId, string description) {
            PerformLog(LogLevel.Error, eventId, description, null);
        }

        /// <summary>
        /// Log error message with event id and associated exception.
        /// </summary>
        /// <param name="eventId"></param>
        /// <param name="description"></param>
        /// <param name="e"></param>
        public void LogError(int eventId, string description, Exception e) {
            PerformLog(LogLevel.Error, eventId, description, e);
        }

        /// <summary>
        /// Logs an error and asserts.
        /// </summary>
        /// <param name="description">String that will be logged and asserted</param>
        public void LogErrorAndAssert(string description) {
            LogError(description);
            Debug.Assert(false, description);
        }

        /// <summary>
        /// Logs an error and asserts.
        /// </summary>
        /// <param name="description">String that will be logged and asserted</param>
        /// <param name="e">The associated exception</param>
        public void LogWarningAndAssert(string description, Exception e) {
            LogWarning(description, e);
            Debug.Assert(false, description + ": " + e);
        }

        /// <summary>
        /// Logs an error and throws.
        /// </summary>
        /// <param name="description">String that will be logged and asserted</param>
        /// <exception cref="System.ApplicationException">Throws an application exception</exception>
        public void LogWarningAndThrow(string description) {
            LogWarning(description);
            throw new ApplicationException(description);
        }

        /// <summary>
        /// Logs a warning, asserts, and then throws.
        /// </summary>
        /// <param name="description">String that will be logged, asserted, and thrown</param>
        /// <exception cref="System.ApplicationException">Throws an application exception</exception>
        public void LogWarningAssertAndThrow(string description) {
            LogWarningAndAssert(description);
            throw new ApplicationException(description);
        }

        /// <summary>
        /// Logs an error, asserts, and then throws.
        /// </summary>
        /// <param name="description">String that will be logged, asserted, and thrown</param>
        /// <exception cref="System.ApplicationException">Throws an application exception</exception>
        public void LogErrorAssertAndThrow(string description) {
            LogErrorAndAssert(description);
            throw new ApplicationException(description);
        }

        /// <summary>
        /// Logs an error, asserts, and then throws.
        /// </summary>
        /// <param name="description">String that will be logged, asserted, and thrown</param>
        /// <param name="e"></param>
        /// <exception cref="System.ApplicationException">Throws an application exception</exception>
        public void LogErrorAssertAndThrow(string description, Exception e) {
            LogErrorAndAssert(description, e);
            throw new ApplicationException(description, e);
        }

        /// <summary>
        /// Log warning message.
        /// </summary>
        /// <param name="description">A warning message</param>
        public void LogWarning(string description) {
            PerformLog(LogLevel.Warning, 0, description, null);
        }

        /// <summary>
        /// Log warning message with an associated exception.
        /// </summary>
        /// <param name="description">A warning message</param>
        /// <param name="e">The associated exception</param>
        public void LogWarning(string description, Exception e) {
            PerformLog(LogLevel.Warning, 0, description, e);
        }

        /// <summary>
        /// Log warning message with event id.
        /// </summary>
        /// <param name="eventId"></param>
        /// <param name="description"></param>
        public void LogWarning(int eventId, string description) {
            PerformLog(LogLevel.Warning, eventId, description, null);
        }

        /// <summary>
        /// Log warning message with event id and associated exception.
        /// </summary>
        /// <param name="eventId">Detailed source id</param>
        /// <param name="description">String that will be logged</param>
        /// <param name="e">Associated exception</param>
        public void LogWarning(int eventId, string description, Exception e) {
            PerformLog(LogLevel.Warning, eventId, description, e);
        }

        /// <summary>
        /// Logs a warning and asserts.
        /// </summary>
        /// <param name="description">String that will be logged and asserted</param>
        public void LogWarningAndAssert(string description) {
            PerformLog(LogLevel.Warning, 0, description, null);
            Debug.Assert(false, description);
        }

        /// <summary>
        /// Logs a warning and asserts.
        /// </summary>
        /// <param name="description">String that will be logged and asserted</param>
        /// <param name="e">Associated exception</param>
        public void LogErrorAndAssert(string description, Exception e) {
            PerformLog(LogLevel.Error, 0, description, e);
            Debug.Assert(false, description + ": " + e);
        }

        /// <summary>
        /// Log info message.
        /// </summary>
        /// <param name="description"></param>
        public void LogInfo(string description) {
            PerformLog(LogLevel.Info, 0, description, null);
        }

        /// <summary>
        /// Log info message with associated exception.
        /// </summary>
        /// <param name="description"></param>
        /// <param name="e"></param>
        public void LogInfo(string description, Exception e) {
            PerformLog(LogLevel.Info, 0, description, e);
        }

        /// <summary>
        /// Log info message with event id.
        /// </summary>
        /// <param name="eventId"></param>
        /// <param name="description"></param>
        public void LogInfo(int eventId, string description) {
            PerformLog(LogLevel.Info, eventId, description, null);
        }

        /// <summary>
        /// Log info message with event id and associated exception.
        /// </summary>
        /// <param name="eventId"></param>
        /// <param name="description"></param>
        /// <param name="e"></param>
        public void LogInfo(int eventId, string description, Exception e) {
            PerformLog(LogLevel.Info, eventId, description, e);
        }

        /// <summary>
        /// Log debug message.
        /// </summary>
        /// <param name="description"></param>
        public void LogDebug(string description) {
            PerformLog(LogLevel.Debug, 0, description, null);
        }

        /// <summary>
        /// Log debug message with associated exception.
        /// </summary>
        /// <param name="description"></param>
        /// <param name="e"></param>
        public void LogDebug(string description, Exception e) {
            PerformLog(LogLevel.Debug, 0, description, e);
        }

        /// <summary>
        /// Log debug message with event id.
        /// </summary>
        /// <param name="eventId"></param>
        /// <param name="description"></param>
        public void LogDebug(int eventId, string description) {
            PerformLog(LogLevel.Debug, eventId, description, null);
        }

        /// <summary>
        /// Log debug message with event id and associated exception.
        /// </summary>
        /// <param name="eventId"></param>
        /// <param name="description"></param>
        /// <param name="e"></param>
        public void LogDebug(int eventId, string description, Exception e) {
            PerformLog(LogLevel.Debug, eventId, description, e);
        }

        /// <summary>
        /// Log message with given log level.
        /// </summary>
        /// <param name="level"></param>
        /// <param name="description"></param>
        public void Log(LogLevel level, string description) {
            PerformLog(level, 0, description, null);
        }

        /// <summary>
        /// Log message with given log level and event id.
        /// </summary>
        /// <param name="level"></param>
        /// <param name="eventId"></param>
        /// <param name="description"></param>
        public void Log(LogLevel level, int eventId, string description) {
            PerformLog(level, eventId, description, null);
        }

        /// <summary>
        /// Log message with given log level.
        /// </summary>
        /// <param name="level"></param>
        /// <param name="description"></param>
        /// <param name="e"></param>
        public void Log(LogLevel level, string description, Exception e) {
            PerformLog(level, 0, description, e);
        }

        /// <summary>
        /// Log message with given log level and event id.
        /// </summary>
        /// <param name="level"></param>
        /// <param name="eventId"></param>
        /// <param name="description"></param>
        /// <param name="e"></param>
        public void Log(LogLevel level, int eventId, string description, Exception e) {
            PerformLog(level, eventId, description, e);
        }

        /// <summary>
        /// User confirmed warnings and errors should be logged through this
        /// </summary>
        /// <param name="error">The error or warning to be logged</param>
        /// <param name="confirmType">User-provided confirmation type</param>
        public void Log(Interfaces.Utilities.Error.IError error, Interfaces.Utilities.Error.ConfirmationType confirmType) {
            if (error == null) {
                LogWarning("<Unidentifiable error requested for logging>");
                return;
            }
            try {
                String msg;
                LogLevel logLevel;
                switch (error.Severity) {
                    case Interfaces.Utilities.Error.SeverityEnum.ErrorUnrecoverable:
                    case Interfaces.Utilities.Error.SeverityEnum.ErrorUserConfirmation:
                    case Interfaces.Utilities.Error.SeverityEnum.ErrorUserInterventionHigh:
                    case Interfaces.Utilities.Error.SeverityEnum.ErrorUserInterventionLow:
                    case Interfaces.Utilities.Error.SeverityEnum.ErrorUserInterventionMedium:
                        logLevel = LogLevel.Error;
                        msg = "Error";
                        break;
                    case Interfaces.Utilities.Error.SeverityEnum.Warning:
                    case Interfaces.Utilities.Error.SeverityEnum.WarningUserConfirmation:
                    case Interfaces.Utilities.Error.SeverityEnum.WarningUserIntervention:
                        logLevel = LogLevel.Warning;
                        msg = "Warning";
                        break;
                    case Interfaces.Utilities.Error.SeverityEnum.Information:
                        logLevel = LogLevel.Info;
                        msg = "Information";
                        break;
                    default:
                        logLevel = LogLevel.Warning;
                        msg = "Unknown severity";
                        break;
                }
                String text = "Confirmed " + msg + " with " + confirmType + ": " + error.ErrorGuid + ", Caption: " + error.Caption;
                Log(logLevel, text);
            } catch (Exception e) {
                LogWarning("Illegal error requested for logging", e);
                return;
            }
        }

        /// <summary>
        /// A query to figure out, whether we need to output messages at the given log level.
        /// This can be used to turn off performance heavy log-related code (e.g., debug logs in release execution)
        /// </summary>
        /// <param name="level"></param>
        /// <returns></returns>
        public bool IsActive(LogLevel level) {
            lock (syncBlock) {
                if (logger == null) {
                    return false;
                }
            }
            switch (level) {
                case LogLevel.Debug:
                    return config.Debug;
                case LogLevel.Info:
                    return config.Info;
                case LogLevel.Warning:
                    return config.Warning;
                case LogLevel.Error:
                    return config.Error;
                default:
                    Debug.Assert(false, level.ToString());
                    return true;
            }
        }

        /// <summary>
        /// Check whether log messages with given event id and log level are active, that is, they would be written to log database.
        /// </summary>
        /// <remarks>
        /// <para>
        /// Some code can be optimized by using this information to not to even try to log some messages when those messages would not be 
        /// written to log database.
        /// </para>
        /// </remarks>
        /// <param name="eventId"></param>
        /// <param name="level"></param>
        /// <returns></returns>
        public bool IsActive(int eventId, LogLevel level) {
            lock (syncBlock) {
                if (logger == null) {
                    return false;
                }
            }
            if (AppDomain.CurrentDomain.IsFinalizingForUnload()) {
                // The damage is already done - do not timeout appdomain unloading
                return false;
            }

            try {
                Configuration.EventIdConfiguration eventIdConfig = config.GetEventIdConfiguration(eventId);
                if (eventIdConfig != null) {
                    switch (level) {
                        case LogLevel.Debug:
                            return eventIdConfig.Debug;
                        case LogLevel.Info:
                            return eventIdConfig.Info;
                        case LogLevel.Warning:
                            return eventIdConfig.Warning;
                        case LogLevel.Error:
                            return eventIdConfig.Error;
                        default:
                            System.Diagnostics.Debug.Assert(false, level.ToString());
                            return true;
                    }
                }
            } catch (System.Xml.Schema.XmlSchemaValidationException e) {
                // The Pattern constraining facet is invalid - Thread was being aborted.
                Misc.ExceptionHelper.AppendCurrentStackTraceToExceptionData(e);
                if (!e.ToString().Contains("Thread was being aborted")) {
                    throw;
                }
                // This will autothrow (we are catching a thread abort exception masquerading as a XmlSchemaValidationException)
            }
            return IsActive(level);
        }

        #endregion

        /// <summary>
        /// Logger type
        /// </summary>
        public enum LoggerType {
            /// <summary>
            /// Normal, configured logging.
            /// </summary>
            Default,
            /// <summary>
            /// Logging with Windows event logger.
            /// </summary>
            WindowsEventLogger
        }

        /// <summary>
        /// Class-specific log, prepends the class name to generated log messages.
        /// </summary>
        /// <returns></returns>
        public static LogEvent CreateClassLog() {
            var stack = new StackTrace();

            string ns = "<unknown>";
            string name = "<unknown>";
            for (int indx = 1; indx < stack.FrameCount; ++indx) {
                var stackFrame = stack.GetFrame(indx);
                var method = stackFrame.GetMethod();
                var declaringType = method.DeclaringType;
                if (!declaringType.IsGenericType) {
                    ns = declaringType.Namespace;
                    name = declaringType.Name;
                    break;
                }
            }

            return CreateInstance(null, new ClassLog(ns, name));
        }

        /// <summary>
        /// Creates a Windows event logger.
        /// </summary>
        /// <returns></returns>
        public static LogEvent CreateEventLog(string namespaceId) {
            return CreateInstance(null, new EventLog(namespaceId, "EventLog"));
        }

        #region Protected methods
        /// <summary>
        /// Protected constructor. Since log event should be singleton object, inheriting class should also not 
        /// have a public constructor.
        /// </summary>
        protected LogEvent() : this(LoggerType.Default) { }

        /// <summary>
        /// Protected constructor. Since log event should be singleton object, inheriting class should also not 
        /// have a public constructor.
        /// </summary>
        protected LogEvent(LoggerType loggerType) {
            Init("", Interfaces.Utilities.Log.Constants.ConsoleIdRangeName, GetType().Namespace, loggerType);
        }

        /// <summary>
        /// Protected constructor for explicit namespacing.
        /// </summary>
        /// <remarks>
        /// Used by scripting framework.
        /// </remarks>
        /// <param name="nameSpace"></param>
        protected LogEvent(string nameSpace) : this(Interfaces.Utilities.Log.Constants.ConsoleIdRangeName, nameSpace) { }

        /// <summary>
        /// Protected constructor for explicit id range selection and namespacing.
        /// </summary>
        /// <param name="idRangeName">Range identifier</param>
        /// <param name="nameSpace">Namespace within the range</param>
        protected LogEvent(string idRangeName, string nameSpace) : this("", idRangeName, nameSpace) { }

        /// <summary>
        /// Protected constructor for explicit component, id range selection, and namespacing.
        /// </summary>
        /// <param name="componentId">Id of the component</param>
        /// <param name="idRangeName">Range identifier</param>
        /// <param name="nameSpace">Namespace within the range</param>
        protected LogEvent(string componentId, string idRangeName, string nameSpace) : this(componentId, idRangeName, nameSpace, LoggerType.Default, Implementer.CreateLogger, Implementer.CreateEventLogger, LogIdManager.Instance) { }

        /// <summary>
        /// Create a an LogEvent instance thread safely.
        /// </summary>
        /// <param name="type">Log-class to be created</param>
        /// <returns>A log-class instance on success</returns>
        protected static LogEvent SafeCreateInstance(Type type) {
            return CreateInstance(type, null);
        }

        /// <summary>
        /// Additional prefix to be pre-pended to the log messages.
        /// </summary>
        protected string Prefix { get; set; }
        #endregion

        #region Internal
        internal LogEvent(
            string componentId,
            string idRangeName,
            string nameSpace,
            LoggerType loggerType,
            Func<ILogger> loggerCreator,
            Func<IBackupLogger> backupLoggerCreator,
            ILogIdManager logIdManager) {
            this.loggerCreator = loggerCreator;
            this.backupLoggerCreator = backupLoggerCreator;
            this.logIdManager = logIdManager;
            Init(componentId, idRangeName, nameSpace, LoggerType.Default);
        }

        internal ILogger CurrentLogger {
            get {
                lock (syncBlock) {
                    return logger;
                }
            }
        }

        #endregion

        #region Private

        private static LogEvent CreateInstance(Type type, LogEvent precreatedEvent) {
            Contract.Ensures(Contract.Result<LogEvent>() != null);
            lock (syncBlock) {
                LogEvent instance = precreatedEvent;
                if (instance != null || !instanceDictionary.TryGetValue(type, out instance)) {
                    if (instance == null) {
                        Type[] types = Type.EmptyTypes;
                        instance = (LogEvent)type.GetConstructor(types).Invoke(null);
                        instanceDictionary[type] = instance;
                    }

                    object obj = AppDomain.CurrentDomain.GetData(Interfaces.Utilities.Log.Constants.DisableLogConfigAppDomainData);
                    bool disableConfig = (obj != null) ? (obj as string) == Boolean.TrueString : false;
                    if (!disableConfig && instance.logger != null) {
                        instance.config = Configuration.ConfigurationData.Instance.GetSourceConfiguration(instance.id);
                    }
                }

                return instance;
            }
        }

        private string FormattedDescription(string description) {
            return Prefix == null ? description : Prefix + description;
        }

        private void PerformLog(LogLevel logLevel, int eventId, string description, Exception exception) {
            if (!IsActive(eventId, logLevel)) {
                return;
            }
            var timestamp = DateTime.UtcNow;
            var message = exception != null ?
                    FormattedDescription(description) + Environment.NewLine + ExceptionFormatter.ExceptionToDetailedString(exception) :
                    FormattedDescription(description);
            ILogger tmp;
            lock (syncBlock) {
                tmp = logger;
            }
            if (tmp == null) {
                throw new ApplicationException("Logging is not available");
            }

            try {
                switch (logLevel) {
                    case LogLevel.Debug:
                        tmp.LogDebug(timestamp, id, eventId, message);
                        break;
                    case LogLevel.Info:
                        tmp.LogInfo(timestamp, id, eventId, message);
                        break;
                    case LogLevel.Warning:
                        tmp.LogWarning(timestamp, id, eventId, message);
                        break;
                    case LogLevel.Error:
                        tmp.LogError(timestamp, id, eventId, message);
                        break;
                    default:
                        throw new ApplicationException("Unknown log level: " + logLevel);
                }
            } catch (Private.Interfaces.FrameworkComponents.Log.LogException e) {
                if (AppDomain.CurrentDomain.IsFinalizingForUnload()) {
                    // Too late
                    throw new ApplicationException("Logging is not available, appdomain is finalizing");
                }
                lock (syncBlock) {
                    if (tmp is IBackupLogger) {
                        throw new ApplicationException("An attempt to use a backup logger failed", e);
                    }
                    if (logger is IBackupLogger) {
                        // Somebody changed the log for us, let's give it a try
                    } else {
                        // We are the first one to detect a logging problem. Reverting to the backup log.
                        logger = backupLoggerCreator();
                        if (logger == null) {
                            throw new ApplicationException("Failed to create a backup log", e);
                        }
                    }
                }
                PerformLog(logLevel, eventId, description, exception);
            }
        }

        class ClassLog : LogEvent {
            public ClassLog(string ns, string name)
                : this(ns, name, name + " ", LoggerType.Default) {
            }

            public ClassLog(string ns, string name, LoggerType loggerType)
                : this(ns, name, name + " ", loggerType) {
            }

            private ClassLog(string ns, string name, string explicitPrefix, LoggerType loggerType)
                : base(loggerType) {
                id = logIdManager.GetId("", Interfaces.Utilities.Log.Constants.ConsoleIdRangeName, ns);
                Prefix = explicitPrefix;
            }
        }

        class EventLog : ClassLog {
            public EventLog(string ns, string name) : base(ns, name, LoggerType.WindowsEventLogger) { }
        }

        private void Init(string componentId, string idRangeName, string nameSpace, LoggerType loggerType) {
            if (loggerCreator == null) {
                loggerCreator = Implementer.CreateLogger;
            }
            if (backupLoggerCreator == null) {
                backupLoggerCreator = Implementer.CreateEventLogger;
            }
            if (logIdManager == null) {
                logIdManager = LogIdManager.Instance;
            }

            id = logIdManager.GetId(componentId, idRangeName, nameSpace);

            // Default config, until we get one from the config repository.
            config = new Configuration.EventSourceConfiguration(true, true, true, true);

            switch (loggerType) {
                case LoggerType.WindowsEventLogger:
                    logger = Implementer.CreateEventLogger();
                    break;
                default:
                    logger = loggerCreator();
                    break;
            }
        }

        #endregion

        #region Private fields
        private static readonly object syncBlock = new object();
        private static readonly IDictionary<Type, LogEvent> instanceDictionary = new Dictionary<Type, LogEvent>();

        private Func<ILogger> loggerCreator;
        private Func<IBackupLogger> backupLoggerCreator;
        private ILogIdManager logIdManager;

        private int id;
        private Configuration.EventSourceConfiguration config;
        private ILogger logger;
        #endregion
    }
}
