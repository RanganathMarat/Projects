﻿#region Copyright Koninklijke Philips Electronics N.V. 2009
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
#endregion

using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;

namespace Philips.PmsMR.UI.Infra.Utilities.WinApi {

    /// <summary>
    /// Execution of a process in the user session of a given process.
    /// </summary>
    /// <remarks>
    /// Needed for services in the post-XP World, where all services run 
    /// in session0 and cannot access the UI or message queues of arbitrary processes.
    /// </remarks>
    public class UserProcess {

        /// <summary>
        /// Initializing ctor.
        /// </summary>
        /// <param name="parentProcess">Process, whose user desktop is to be used for executing a process</param>
        public UserProcess(Process parentProcess) {
            // Attempt to retrieve the user token handle of the given process
            IntPtr processHandle = OpenProcess(ProcessAccessFlags.All, false, (uint)parentProcess.Id);
            try {
                IntPtr tokenHandle;
                OpenProcessToken(processHandle, ProcessTokenAccessFlags.TokenDuplicate, out tokenHandle);
                try {
                    SECURITY_ATTRIBUTES securityAttributes = new SECURITY_ATTRIBUTES();
                    securityAttributes.nLength = (uint) Marshal.SizeOf(securityAttributes);
                    DuplicateTokenEx(
                        tokenHandle,
                        ProcessTokenAccessFlags.TokenAssignPrimary | ProcessTokenAccessFlags.TokenDuplicate | ProcessTokenAccessFlags.TokenQuery,
                        ref securityAttributes,
                        SECURITY_IMPERSONATION_LEVEL.SecurityIdentification,
                        TOKEN_TYPE.TokenPrimary,
                        out userToken);
                    CloseHandle(tokenHandle);
                    tokenHandle = IntPtr.Zero;
                } finally {
                    if (tokenHandle != IntPtr.Zero) {
                        CloseHandle(tokenHandle);
                    }
                }
            } finally {
                if (processHandle != IntPtr.Zero) {
                    CloseHandle(processHandle);
                }
            }
        }

        /// <summary>
        /// Freeing of unmanaged user token.
        /// </summary>
        ~UserProcess() {
            if (userToken != IntPtr.Zero) {
                CloseHandle(userToken);
            }
        }

        /// <summary>
        /// Returns true if the current thread has been elevated to the admin status.
        /// </summary>
        public static bool HasAdminRights {
            get {
                IntPtr sidData = IntPtr.Zero;
                try {
                    SID_IDENTIFIER_AUTHORITY sidAuthority = new SID_IDENTIFIER_AUTHORITY(new Byte[] { 0, 0, 0, 0, 0, 5 });
                    if (AllocateAndInitializeSid(
                        ref sidAuthority,
                        2,
                        (int)SubauthorityType.SECURITY_BUILTIN_DOMAIN_RID,
                        (int)SubauthorityType.DOMAIN_ALIAS_RID_ADMINS,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0,
                        out sidData)) {
                        bool isMember;
                        // NULL handle means that the impersonation token of the calling thread is used.
                        IntPtr tokenHandle = IntPtr.Zero;
                        if (CheckTokenMembership(tokenHandle, sidData, out isMember)) {
                            return isMember;
                        }
                    }
                } finally {
                    if (sidData != IntPtr.Zero) {
                        FreeSid(sidData);
                    }
                }
                return false;
            }
        }

        /// <summary>
        /// Execute the given command line
        /// </summary>
        /// <param name="commandLine">Command line to execute as impersonated user</param>
        /// <param name="workingDir">Working directory for the command</param>
        /// <param name="process">Launched process</param>
        /// <returns></returns>
        public bool Execute(string commandLine, DirectoryInfo workingDir, out ProcessWrapper process) {
            if (userToken == IntPtr.Zero) {
                process = null;
                return false;
            }
            IntPtr env = CreateEnvironmentBlock();

            // We could do LoadUserProfile here, but in our case, utilities provide all the necessary path info
            RawProcess raw = null;
            try {                
                SECURITY_ATTRIBUTES securityAttributesForProcess = new SECURITY_ATTRIBUTES();
                SECURITY_ATTRIBUTES securityAttributesForThread = new SECURITY_ATTRIBUTES();
                securityAttributesForProcess.nLength = (uint)Marshal.SizeOf(securityAttributesForProcess);
                securityAttributesForThread.nLength = (uint)Marshal.SizeOf(securityAttributesForThread);

                STARTUPINFO si = new STARTUPINFO();
                si.cb = (uint)Marshal.SizeOf(si);

                // NULL: inherit desktop and window station
                // empty string: may create a new desktop and window station (if one does not exist)
                si.lpDesktop = null;
                si.dwFlags = 0;
                si.wShowWindow = SW_HIDE;

                PROCESS_INFORMATION processInfo = new PROCESS_INFORMATION();
                bool result = CreateProcessAsUser(
                    userToken,
                    null,
                    commandLine,
                    ref securityAttributesForProcess,
                    ref securityAttributesForThread,
                    false,
                    ProcessCreationFlags.CREATE_UNICODE_ENVIRONMENT | ProcessCreationFlags.CREATE_NO_WINDOW,
                    env,
                    workingDir.FullName,
                    ref si,
                    out processInfo);
                raw = new RawProcess(processInfo);
                if (!result) {
                    process = null;
                } else {
                    process = new ProcessWrapper(Process.GetProcessById((int)processInfo.dwProcessId), raw);
                }

                return result;

            } finally {
                if (env != IntPtr.Zero) {
                    DestroyEnvironmentBlock(env);
                }
            }
        }

        private IntPtr CreateEnvironmentBlock() {
            IntPtr block = IntPtr.Zero;

            const bool inheritExecutingProcess = false;
            bool retVal = CreateEnvironmentBlock(ref block, userToken, inheritExecutingProcess);
            if (retVal == false) {
                throw new ApplicationException("Failed to create environment: " + Marshal.GetLastWin32Error());
            }
            return block;
        }

        /// <summary>
        /// Wrapper for native and managed process data
        /// </summary>
        public class ProcessWrapper {
            internal ProcessWrapper(Process real, RawProcess raw) {
                RealProcess = real;
                RawProcess = raw;
            }

            /// <summary>
            /// True if the process has exited
            /// </summary>
            public bool HasExited {
                get {
                    return RealProcess.HasExited;
                }
            }

            /// <summary>
            /// Exit code of the process.
            /// </summary>
            public int ExitCode {
                get {
                    uint ret;
                    GetExitCodeProcess(RawProcess.ProcessInfo.hProcess, out ret);
                    unchecked {
                        return (int) ret;
                    }
                }
            }

            /// <summary>
            /// Access to the real process.
            /// </summary>
            /// <remarks>
            /// note that exit code will not be available through the managed process instance.
            /// </remarks>
            public Process RealProcess { get; private set; }

            internal RawProcess RawProcess { get; private set; }
        }

        internal class RawProcess {
            internal RawProcess(PROCESS_INFORMATION info) {
                ProcessInfo = info;
            }
            ~RawProcess() {
                if (ProcessInfo.hThread != IntPtr.Zero) {
                    CloseHandle(ProcessInfo.hThread);
                }
                if (ProcessInfo.hProcess != IntPtr.Zero) {
                    CloseHandle(ProcessInfo.hProcess);
                }                
            }

            public PROCESS_INFORMATION ProcessInfo { get; private set; }
        }

        private readonly IntPtr userToken;

        /// <summary>
        /// See WinAPI
        /// </summary>
        private const int SW_HIDE = 0;

        #region PInvokes for WINAPI
        [StructLayout(LayoutKind.Sequential)]
        internal struct PROCESS_INFORMATION {
            public IntPtr hProcess;
            public IntPtr hThread;
            public uint dwProcessId;
            public uint dwThreadId;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct SECURITY_ATTRIBUTES {
            public uint nLength;
            public IntPtr lpSecurityDescriptor;
            public bool bInheritHandle;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct STARTUPINFO {
            public uint cb;
            public string lpReserved;
            public string lpDesktop;
            public string lpTitle;
            public uint dwX;
            public uint dwY;
            public uint dwXSize;
            public uint dwYSize;
            public uint dwXCountChars;
            public uint dwYCountChars;
            public uint dwFillAttribute;
            public uint dwFlags;
            public short wShowWindow;
            public short cbReserved2;
            public IntPtr lpReserved2;
            public IntPtr hStdInput;
            public IntPtr hStdOutput;
            public IntPtr hStdError;
        }

        private struct SID_IDENTIFIER_AUTHORITY {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
            public byte[] Value;
            public SID_IDENTIFIER_AUTHORITY(byte[] value) {
                Value = value;
            }
        };

        [Flags]
        private enum SubauthorityType {
            SECURITY_BUILTIN_DOMAIN_RID = 0x20,
            DOMAIN_ALIAS_RID_ADMINS = 0x220
        }

        private enum SECURITY_IMPERSONATION_LEVEL {
            SecurityAnonymous,
            SecurityIdentification,
            SecurityImpersonation,
            SecurityDelegation
        }

        private enum TOKEN_TYPE {
            TokenPrimary = 1,
            TokenImpersonation
        }

        [Flags]
        private enum ProcessAccessFlags : uint {
            All = 0x001F0FFF,
            Terminate = 0x00000001,
            CreateThread = 0x00000002,
            VmOperation = 0x00000008,
            VmRead = 0x00000010,
            VmWrite = 0x00000020,
            DupHandle = 0x00000040,
            SetInformation = 0x00000200,
            QueryInformation = 0x00000400,
            Synchronize = 0x00100000
        }

        [DllImport("kernel32.dll")]
        private static extern IntPtr OpenProcess(ProcessAccessFlags dwDesiredAccess, [MarshalAs(UnmanagedType.Bool)] bool bInheritHandle,
           uint dwProcessId);

        [Flags]
        private enum ProcessTokenAccessFlags : uint {
            StandardRightsRequired = 0x000F0000,
            StandardRightsRead = 0x00020000,
            TokenAssignPrimary = 0x0001,
            TokenDuplicate = 0x0002,
            TokenImpersonate = 0x0004,
            TokenQuery = 0x0008,
            TokenQuerySource = 0x0010,
            TokenAdjustPrivileges = 0x0020,
            TokenAdjustGroups = 0x0040,
            TokenAdjustDefault = 0x0080,
            TokenAdjustSessionid = 0x0100,
            TokenRead = (StandardRightsRead | TokenQuery),
            TokenAllAccess = (StandardRightsRequired | TokenAssignPrimary |
                TokenDuplicate | TokenImpersonate | TokenQuery | TokenQuerySource |
                TokenAdjustPrivileges | TokenAdjustGroups | TokenAdjustDefault |
                TokenAdjustSessionid)
        }

        [DllImport("advapi32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool OpenProcessToken(IntPtr processHandle, ProcessTokenAccessFlags desiredAccess, out IntPtr tokenHandle);

        [DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private extern static bool DuplicateTokenEx(
            IntPtr hExistingToken,
            ProcessTokenAccessFlags dwDesiredAccess,
            ref SECURITY_ATTRIBUTES lpTokenAttributes,
            SECURITY_IMPERSONATION_LEVEL ImpersonationLevel,
            TOKEN_TYPE TokenType,
            out IntPtr phNewToken);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool CloseHandle(
            IntPtr hHandle);

        [DllImport("userenv.dll", SetLastError = true)]
        private static extern bool CreateEnvironmentBlock(
            ref IntPtr lpEnvironment,
            IntPtr hToken,
            bool bInherit);

        [DllImport("userenv.dll", SetLastError = true)]
        private static extern bool DestroyEnvironmentBlock(IntPtr lpEnvironment);

        [Flags]
        private enum ProcessCreationFlags : uint {
            CREATE_UNICODE_ENVIRONMENT = 0x00000400,
            CREATE_NO_WINDOW = 0x08000000
        }

        [DllImport("advapi32.dll", SetLastError = true)]
        private static extern bool CreateProcessAsUser(
            IntPtr hToken,
            string lpApplicationName,
            string lpCommandLine,
            ref SECURITY_ATTRIBUTES lpProcessAttributes,
            ref SECURITY_ATTRIBUTES lpThreadAttributes,
            bool bInheritHandles,
            ProcessCreationFlags creationFlags,
            IntPtr lpEnvironment,
            string lpCurrentDirectory,
            ref STARTUPINFO lpStartupInfo,
            out PROCESS_INFORMATION lpProcessInformation);

        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool GetExitCodeProcess(IntPtr hProcess, out uint lpExitCode);

        [DllImport("advapi32.dll", SetLastError = true)]
        private static extern bool CheckTokenMembership(IntPtr tokenHandle, IntPtr sid, out bool isMember);

        [DllImport("advapi32.dll", SetLastError = true)]
        private static extern bool AllocateAndInitializeSid(
            ref SID_IDENTIFIER_AUTHORITY pIdentifierAuthority,
            byte nSubAuthorityCount,
            int dwSubAuthority0, int dwSubAuthority1,
            int dwSubAuthority2, int dwSubAuthority3,
            int dwSubAuthority4, int dwSubAuthority5,
            int dwSubAuthority6, int dwSubAuthority7,
            out IntPtr pSid);

        [DllImport("advapi32.dll")]
        private static extern IntPtr FreeSid(IntPtr pSid);
        #endregion
    }
        
}
