﻿#region Copyright Koninklijke Philips Electronics N.V. 2011
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
#endregion
using System;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;

namespace Philips.PmsMR.UI.Infra.Utilities.WinAPI {

    /// <summary>
    /// Class for changing process settings.
    /// </summary>
    public static class ProcessSettings {
        
        /// <summary>
        /// Ensure that the current process has normal I/O priorities.
        /// </summary>
        /// <remarks>Processes started by Windows 7 startup script get Very Low I/O priority.
        /// This increases the priority to Normal.</remarks>
        public unsafe static void EnsureNormalIOPriorities() {
            int sizeofResult = 0;
            uint ioPriority = 0;
            // -1 == current process
            NtQueryInformationProcess(-1, PROCESS_INFORMATION_CLASS.ProcessIoPriority, (IntPtr)(&ioPriority), 4, ref sizeofResult);
            // 2 == normal priority
            if (ioPriority < 2) {
                ioPriority = 2;
                NtSetInformationProcess(-1, PROCESS_INFORMATION_CLASS.ProcessIoPriority, (IntPtr)(&ioPriority), 4);
            }
        }

        /// <summary>
        /// Sets the processor affinity to the current thread.
        /// </summary>
        /// <param name="cpuMask">Bitmask for the affinity</param>
        public static void SetCurrentThreadAffinity(IntPtr cpuMask) {
            var currentThread = GetCurrentThreadId();
            var thread = Process.GetCurrentProcess().Threads.Cast<ProcessThread>().Single(t => t.Id == currentThread);
            // Set the thread's processor affinity
            thread.ProcessorAffinity = cpuMask;
        }

        private enum PROCESS_INFORMATION_CLASS : int {
            ProcessBasicInformation = 0,
            ProcessQuotaLimits,
            ProcessIoCounters,
            ProcessVmCounters,
            ProcessTimes,
            ProcessBasePriority,
            ProcessRaisePriority,
            ProcessDebugPort,
            ProcessExceptionPort,
            ProcessAccessToken,
            ProcessLdtInformation,
            ProcessLdtSize,
            ProcessDefaultHardErrorMode,
            ProcessIoPortHandlers,
            ProcessPooledUsageAndLimits,
            ProcessWorkingSetWatch,
            ProcessUserModeIOPL,
            ProcessEnableAlignmentFaultFixup,
            ProcessPriorityClass,
            ProcessWx86Information,
            ProcessHandleCount,
            ProcessAffinityMask,
            ProcessPriorityBoost,
            ProcessDeviceMap,
            ProcessSessionInformation,
            ProcessForegroundInformation,
            ProcessWow64Information,
            ProcessImageFileName,
            ProcessLUIDDeviceMapsEnabled,
            ProcessBreakOnTermination,
            ProcessDebugObjectHandle,
            ProcessDebugFlags,
            ProcessHandleTracing,
            ProcessIoPriority,
            ProcessExecuteFlags,
            ProcessResourceManagement,
            ProcessCookie,
            ProcessImageInformation,
            ProcessCycleTime,
            ProcessPagePriority,
            ProcessInstrumentationCallback,
            ProcessThreadStackAllocation,
            ProcessWorkingSetWatchEx,
            ProcessImageFileNameWin32,
            ProcessImageFileMapping,
            ProcessAffinityUpdateMode,
            ProcessMemoryAllocationMode,
            MaxProcessInfoClass
        }

        [DllImport("ntdll.dll", SetLastError = true)]
        private static extern int NtSetInformationProcess(int processHandle,
           PROCESS_INFORMATION_CLASS processInformationClass, IntPtr processInformation, uint processInformationLength);

        [DllImport("ntdll.dll", SetLastError = true)]
        private static extern int NtQueryInformationProcess(int processHandle,
           PROCESS_INFORMATION_CLASS processInformationClass, IntPtr processInformation, int processInformationLength,
           ref int returnLength);

        [DllImport("kernel32.dll")]
        internal static extern IntPtr GetCurrentThread();

        [DllImport("kernel32.dll")]
        private static extern uint GetCurrentThreadId();
    }
}
