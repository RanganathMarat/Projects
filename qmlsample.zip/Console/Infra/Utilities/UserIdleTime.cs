﻿#region Copyright 2008-2014 Koninklijke Philips N.V.
//
// All rights reserved. Reproduction in whole or in part is prohibited without 
// the written consent of the copyright owner.
//
#endregion
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

namespace Philips.PmsMR.UI.Infra.Utilities.WinAPI {

    /// <summary>
    /// Remotable object for user idle time.
    /// </summary>
    public class RemotableUserIdleTime : Public.Utilities.Lifetime.SingletonServerSideObject {
        /// <summary>
        /// Time the user has been idle (no interactive inputs).
        /// </summary>
        /// <returns></returns>
        public TimeSpan GetUserIdleTime() {
            TimeSpan? idle = UserIdleTime.GetUserIdleTime();
            if (idle == null) {
                return new TimeSpan(0);
            }
            return idle.Value;
        }
    }

    /// <summary>
    /// User session data.
    /// </summary>
    public static class UserIdleTime {

        /// <summary>
        /// Time the user has been idle (no interactive inputs).
        /// </summary>
        /// <returns>null if time cannot be deduced</returns>
        public static TimeSpan? GetUserIdleTime() {
            var lastInputInfo = new LastInputInfo();
            lastInputInfo.cbSize = (uint)Marshal.SizeOf(lastInputInfo);
            if (GetLastInputInfo(ref lastInputInfo)) {
                var now = new TimeSpan(GetTickCount() * TimeSpan.TicksPerMillisecond);
                var lastInput = new TimeSpan(lastInputInfo.dwTime * TimeSpan.TicksPerMillisecond);
                return now - lastInput;
            }
            return null;
        }

        /// <summary>
        /// Get CPU time information about the current thread.
        /// </summary>
        /// <param name="creationOffset"></param>
        /// <param name="kernelTime"></param>
        /// <param name="userTime"></param>
        public static void GetCurrentThreadTime(out TimeSpan creationOffset, out TimeSpan kernelTime, out TimeSpan userTime) {
            long lpCreationTime;
            long lpExitTime;
            long lpKernelTime;
            long lpUserTime;
            if (GetThreadTimes(ProcessSettings.GetCurrentThread(), out lpCreationTime, out lpExitTime, out lpKernelTime, out lpUserTime)) {
                creationOffset = new TimeSpan(lpCreationTime);
                kernelTime = new TimeSpan(lpKernelTime);
                userTime = new TimeSpan(lpUserTime);
            } else {
                throw new InvalidOperationException("Cannot get thread times from the current thread");
            }
        }

        [DllImport("User32.dll")]
        private static extern bool GetLastInputInfo(ref LastInputInfo lastInputInfo);

        [DllImport("Kernel32.dll")]
        private static extern uint GetTickCount();

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool GetThreadTimes(IntPtr hThread, out long lpCreationTime, out long lpExitTime, out long lpKernelTime, out long lpUserTime);

        private struct LastInputInfo {
            public uint cbSize;
            public uint dwTime;
        }
    }

}
