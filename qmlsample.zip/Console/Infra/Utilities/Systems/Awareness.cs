#region Copyright Koninklijke Philips Electronics N.V. 2005-2015
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
#endregion

using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using Philips.PmsMR.UI.Interfaces.Infra.TestTask;

namespace Philips.PmsMR.UI.Infra.Utilities.Systems {

    /// <summary>
    /// Awareness of the other systems and components.
    /// </summary>
    public static class Awareness {

        /// <summary>
        /// Is system under automated unit/system testing.
        /// </summary>
        /// <returns></returns>
        public static bool IsUnderBuildTest() {
            EventWaitHandle handle = null;
            try {
                handle = new EventWaitHandle(false, EventResetMode.ManualReset, Constants.BuildTestEventName);
                if (handle.WaitOne(0, true)) {
                    // TestTask.exe has set its event
                    return true;
                }
            } finally {
                if (handle != null) {
                    handle.Close();
                }
            }

            return false;
        }

    }

}
