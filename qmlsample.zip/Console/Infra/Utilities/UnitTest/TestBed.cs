﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

#if NUnitTest
using NUnit.Framework;

namespace Philips.PmsMR.UI.Infra.Utilities.UnitTest
{
    /// <summary>
    /// Base class for unit tests.
    /// </summary>
    [TestFixture]
    public class TestBed
    {
    }
}
#endif // NUnitTest
