﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Philips.PmsMR.UI.Interfaces.Presenter
{
    [Serializable]
    public class InvalidWidgetException : Exception
    {
        public InvalidWidgetException() { }

        public InvalidWidgetException(string message) : base(message) { }

        public InvalidWidgetException(string message, Exception e) : base(message, e) { }

        /// <summary>
        /// Serialization constructor.
        /// </summary>
        /// <param name="info"></param>
        /// <param name="context"></param>
        protected InvalidWidgetException(SerializationInfo info, StreamingContext context) : base(info, context) { }
    }
}
