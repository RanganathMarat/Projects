﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Philips.PmsMR.UI.Interfaces.Presenter.ZeroMQMessages.Requests
{
    public class ScrollClick
    {
        /// <summary>
        /// TODO: move ids to a common header class
        /// </summary>
        public string ParentId;

        public string ButtonId;

        /// <summary>
        /// TODO: enum instead of a string zmqLeft, zmqRight, ..
        /// </summary>
        public string ScrollDirection;
    }
}
