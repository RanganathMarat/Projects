﻿namespace Philips.PmsMR.UI.Interfaces.Presenter.ZeroMQMessages.Requests
{
    /// <summary>
    /// Widget creation message.
    /// </summary>
    public class Creation
    {
        public string ParentId;

        public string WidgetId;

        public string WidgetType;
    }
}
