﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Philips.PmsMR.UI.Interfaces.Presenter.ZeroMQMessages.Requests
{
    public class DragAndDrop
    {
        public string WidgetId;

        public string Command;
    }
}
