﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Philips.PmsMR.UI.Interfaces.Presenter.ZeroMQMessages.Requests
{
    /// <summary>
    /// Notification synchronization request.
    /// </summary>
    /// <remarks>
    /// Generation count on the view layer is lagging, new notifications are requested.
    /// </remarks>
    public class Sync
    {
        /// <summary>
        /// TODO: this to int64
        /// </summary>
        public string GenerationCount;
    }
}
