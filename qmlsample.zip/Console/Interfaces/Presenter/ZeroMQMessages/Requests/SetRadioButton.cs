﻿

namespace Philips.PmsMR.UI.Interfaces.Presenter.ZeroMQMessages.Requests
{
    /// <summary>
    /// TODO: this command to protobuf datamodel
    /// </summary>
    public class SetRadioButton
    {
        /// <summary>
        /// Container of exclusive radio buttons.
        /// </summary>
        public string RadioButtonParentId;

        /// <summary>
        /// Radio button to be set into checked-state.
        /// </summary>
        public string RadioButtonId;
    }
}
