﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Philips.PmsMR.UI.Interfaces.Presenter.ZeroMQMessages.Notifications
{
    /// <summary>
    /// TODO: this to a protobuf message with type-safe data
    /// </summary>
    public class PatientSexChanged
    {
        public string PatientSex;
    }
}
