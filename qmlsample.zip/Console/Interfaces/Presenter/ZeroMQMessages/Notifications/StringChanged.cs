﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Philips.PmsMR.UI.Interfaces.Presenter.ZeroMQMessages.Notifications
{
    public class StringChanged
    {
        public string WidgetId;

        public string NewValue;
    }
}
