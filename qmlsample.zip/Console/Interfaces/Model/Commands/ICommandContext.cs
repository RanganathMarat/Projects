﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Philips.PmsMR.UI.Interfaces.Model.PatientAdmin;

namespace Philips.PmsMR.UI.Interfaces.Model.Commands
{
    /// <summary>
    /// Models available for commands
    /// </summary>
    public interface ICommandContext
    {
        IPatientScheduler PatientScheduler { get; }
    }
}
