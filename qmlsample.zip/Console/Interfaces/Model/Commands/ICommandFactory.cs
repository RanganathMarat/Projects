﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Philips.PmsMR.UI.Interfaces.Model.Commands
{
    /// <summary>
    /// A factory for creating commands.
    /// </summary>
    public interface ICommandFactory
    {

        /// <summary>
        /// Create a simple command without return values (always succeeds)
        /// </summary>
        /// <param name="commandAction"></param>
        /// <returns>Command instance that can be executed</returns>
        ICommand CreateSimple(Action<ICommandContext> commandAction);

    }
}
