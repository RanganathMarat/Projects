﻿#region Copyright 2015 Koninklijke Philips N.V.
//
// All rights reserved. Reproduction in whole or in part is prohibited without 
// the written consent of the copyright owner.
//
#endregion

using System;
using System.Collections.Generic;
using System.Linq;

namespace Philips.PmsMR.UI.Interfaces.Model.Commands
{
    /// <summary>
    /// Command execution end-result.
    /// </summary>
    public enum ExecutionResult
    {
        /// <summary>
        /// Command was cancelled by the system.
        /// </summary>
        /// <remarks>
        /// For example, when the system is shutting down or a lengthy operation was user-cancelled.
        /// </remarks>
        Cancelled,
        /// <summary>
        /// Command succeeded.
        /// </summary>
        Succeeded,
        /// <summary>
        /// Command failed.
        /// </summary>
        Failed
    }

    /// <summary>
    /// A generic result interface for a command execution.
    /// </summary>
    /// <remarks>
    /// <para>
    ///     For complex commands, the command result instance may declare
    ///     more complex result interfaces that inherit from ICommandResult.
    /// </para>
    /// <para>
    ///     The command results are not meant to be used to update
    ///     view layer widgets, such updates should be sent as events
    ///     from the model. The results are more for diagnostics and logging purposes.
    /// </para>
    /// </remarks>
    public interface ICommandResult
    {
        /// <summary>
        /// Success state of the command after the command has been completed.
        /// </summary>
        ExecutionResult Result { get; }
    }

}
