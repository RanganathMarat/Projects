﻿#region Copyright 2015 Koninklijke Philips N.V.
//
// All rights reserved. Reproduction in whole or in part is prohibited without 
// the written consent of the copyright owner.
//
#endregion
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Philips.PmsMR.UI.Interfaces.Model.Commands
{
    /// <summary>
    /// A command interface.
    /// </summary>
    /// <remarks>
    /// All commands targetting models implement this interace.
    /// </remarks>
    public interface ICommand
    {
        /// <summary>
        /// Executes the command possibly in background threads, not necessarily in the caller thread.
        /// </summary>
        /// <remarks>
        /// Prefer the synchronous Execute version over this call, as the asynchronous version will
        /// make the logic more complex!
        /// </remarks>
        /// <example>
        /// For async-supporting execution (.NET 4.5 async feature https://msdn.microsoft.com/en-us/library/vstudio/hh191443.aspx)
        /// <code>
        /// public async Task<ICommandResult> ExecuteAsync() ..
        /// </code>
        /// An seemingly asynchronous interface can be implemented for simple, synchronous-only operations
        /// with the help of Task.FromResult:
        /// <code>
        /// Task<ICommandResult> ExecuteAsync() {.. return Task.FromResult(result));}
        /// </code>
        /// </example>
        /// <typeparam name="ICommandResult"></typeparam>
        /// <returns></returns>
        Task<ICommandResult> ExecuteAsync();

        /// <summary>
        /// Convenience method for "return await cmd.ExecuteAsync();" 
        /// for scripting or normal, short-lived ui commands.
        /// Runs in the caller thread.
        /// </summary>
        /// <returns></returns>
        ICommandResult Execute();
    }
}
