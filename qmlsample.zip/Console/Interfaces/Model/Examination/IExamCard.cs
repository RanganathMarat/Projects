﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Rhino.Mocks.Constraints;

namespace Philips.PmsMR.UI.Interfaces.Model.Examination
{

    public interface IContrastAgent
    {
        
    }

    public interface IExecutionItem
    {
        Guid Id { get; }
    }

    public interface IHtmlHelp { }

    public interface IPostProcessingStep : IExecutionItem
    {

    }

    public delegate void ScanChangedEventHandler(IScan changedCard);

    public interface IScan : IExecutionItem
    {
        event ScanChangedEventHandler ScanChanged;

        IContrastAgent ContrastAgent { get; set; }

        string GeoName { get; set; }

        IHtmlHelp htmlHelp { get; }

        IEnumerable<IPostProcessingStep> PostProcessingSteps { get; set; }

        string ProtocolName { get; set; }

        IScanProperties ScanProperties { get; set; }
    }

    public interface IScanProperties
    {
        bool Pausing { get; set; }
        bool SmartScout { get; set; }
    }

    public delegate void ExamCardChangedEventHandler(IExamCard changedCard);

    public enum MovePositionType
    {
        Before, After
    }
    public interface IExamCard
    {
        event ExamCardChangedEventHandler ExamCardChanged;

        IExecutionItem FindExecutionItem(Guid id);

        IList<IExecutionItem> Items { get; set; }

        void Move(Guid sourceId, Guid targetId, MovePositionType positionType);
    }
}
