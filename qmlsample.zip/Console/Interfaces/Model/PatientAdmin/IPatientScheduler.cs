﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Philips.PmsMR.UI.Interfaces.Model.PatientAdmin
{
    /// <summary>
    /// Patient scheduler.
    /// </summary>
    public interface IPatientScheduler
    {
        /// <summary>
        /// The patient being edited in UI.
        /// </summary>
        IPatient PatientInEditor { get; }

        /// <summary>
        /// The current patient being scanned.
        /// </summary>
        IPatient PatientInScanner { get; }
    }
}
