﻿#region Copyright 2015 Koninklijke Philips N.V.
//
// All rights reserved. Reproduction in whole or in part is prohibited without 
// the written consent of the copyright owner.
//
#endregion
using System;
using System.Collections.Generic;
using System.Linq;

namespace Philips.PmsMR.UI.Interfaces.Model.PatientAdmin
{
    /// <summary>
    /// Event notification fired after the patient id has been changed.
    /// </summary>
    /// <param name="newId"></param>
    public delegate void PatientIdChangedEventHandler(string newId);

    public enum PatientSexType
    {
        Male,
        Female,
        Other
    }
    public delegate void PatientSexChangedEventHandler(PatientSexType sexType);

    /// <summary>
    /// Patient model interface.
    /// </summary>
    public interface IPatient
    {
        Examination.IExamCard CurrentExamCard { get; }

        event PatientIdChangedEventHandler PatientIdChanged;

        event PatientSexChangedEventHandler PatientSexChanged;

        string PatientId { get; set; }

        PatientSexType PatientSex { get; set; }
    }
}
