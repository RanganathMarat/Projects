﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Philips.PmsMR.UI.Interfaces.Model.PatientAdmin;

namespace Philips.PmsMR.UI.Interfaces.Model.Notifications
{
    /// <summary>
    /// Available notification sources from the model.
    /// </summary>
    public interface INotificationContext
    {
        IPatientScheduler PatientScheduler { get; }
    }
}
