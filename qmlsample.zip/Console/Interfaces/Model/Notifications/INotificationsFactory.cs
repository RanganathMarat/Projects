﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Philips.PmsMR.UI.Interfaces.Model.Notifications
{
    public interface INotificationsFactory
    {
        void ChangeSubscriptions(Action<INotificationContext> changeCall);

        void QueryModel(Action<INotificationContext> queryCall);
    }
}
