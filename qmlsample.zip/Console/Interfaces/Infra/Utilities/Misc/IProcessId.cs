﻿#region Copyright Koninklijke Philips Electronics N.V. 2010
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
#endregion

using System;

namespace Philips.PmsMR.UI.Interfaces.Infra.Utilities.Misc
{

    /// <summary>
    /// Unique process identification.
    /// </summary>
    /// <remarks>
    /// Windows recycles pid integers aggressively -
    /// therefore an unique process id needs to be
    /// augmented with the process start time.
    /// </remarks>    
    public interface IProcessId : IEquatable<IProcessId>, IComparable<IProcessId> {

        /// <summary>
        /// Pid of the source process.
        /// </summary>
        int Pid { get; }

        /// <summary>
        /// Start time of the source process.
        /// </summary>
        Int64 StartTimeTicks { get; }

    }

}
