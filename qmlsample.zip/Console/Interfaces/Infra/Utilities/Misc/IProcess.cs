﻿#region Copyright Koninklijke Philips Electronics N.V. 2010
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
#endregion

using System;
using Philips.PmsMR.UI.Interfaces.Infra.Utilities.Misc;

namespace Philips.PmsMR.UI.Interfaces.Infra.Utilities.Misc
{

    /// <summary>
    /// Wrapper for a process class.
    /// </summary>
    public interface IProcess {

        /// <summary>
        /// Set if the process has exited.
        /// </summary>
        bool HasExited { get; }

        /// <summary>
        /// Event fired at the process exit.
        /// </summary>
        event EventHandler Exited;

        /// <summary>
        /// Set to enable events.
        /// </summary>
        bool EnableRaisingEvents { get; set; }

        /// <summary>
        /// Time-invariant, unique identifier.
        /// </summary>
        IProcessId Id { get; }
    }

}
