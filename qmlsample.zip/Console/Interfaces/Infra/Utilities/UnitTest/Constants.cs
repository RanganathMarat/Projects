﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

#if NUnitTest

namespace Philips.PmsMR.UI.Interfaces.Infra.Utilities.UnitTest
{
    /// <summary>
    /// Unit test constants.
    /// </summary>
    public class Constants
    {
        /// <summary>
        /// A constant usable for a default timeout to wait for a condition, in milliseconds.
        /// </summary>
        public static int DefaultConditionWaitTimeout = 360000; // 6 minutes

        /// <summary>
        /// Maximum time a single test can take - refactor your test if this becomes a problem.
        /// </summary>
        public static int MaximumUnitTestWaitTimeout = 30 * 60 * 1000;

    }
}

#endif // NUnitTest


