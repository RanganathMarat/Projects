#region Copyright Koninklijke Philips Electronics N.V. 2007
//
// All rights are reserved. Reproduction or transmission in whole or in part, in 
// any form or by any means, electronic, mechanical or otherwise, is prohibited 
// without the prior written consent of the copyright owner.
// 
#endregion

using System;

namespace Philips.PmsMR.UI.Interfaces.Infra.Utilities.UnitTest
{
    namespace SourceChecks {

        /// <summary>
        /// Attribute for those special cases where 
        /// a raw MarshalByRefObject dependancy is allowed.
        /// </summary>
        public class IgnoreMarshalByRefObjectAttribute : Attribute {
        }

        /// <summary>
        /// Attribute for those special cases where using a raw
        /// MarshalByRefObject dependency is allowed.
        /// </summary>
        public class IgnoreRemotingViolationAttribute : Attribute {
        }

        /// <summary>
        /// Attribute for those special cases where
        /// a raw System.Threading.Thread can be used
        /// (instead of ExceptionSafeThread).
        /// </summary>
        public class IgnoreThreadAttribute : Attribute {
        }

        /// <summary>
        /// Attribute for those special cases where
        /// a raw System.Xml.Serialization.XmlSerializer can be used
        /// (instead of a customized, fast Utilities.Xml.Serialization.XmlSerializerFactory/IXmlSerializer).
        /// </summary>
        public class IgnoreXmlSerializerAttribute : Attribute {
        }

        /// <summary>
        /// Attribute for those special cases where
        /// a raw Double.Epsilon can be used.
        /// </summary>
        public class IgnoreDoubleEpsilonUsageAttribute : Attribute {            
        }
    }
}
