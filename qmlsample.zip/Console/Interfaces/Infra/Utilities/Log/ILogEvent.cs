﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Philips.PmsMR.UI.Interfaces.Infra.Utilities.Log
{

    /// <summary>
    /// Log severity levels
    /// </summary>
    public enum LogLevel
    {
        /// <summary>
        /// Error: fata error from which recovery is not possible.
        /// </summary>
        Error,

        /// <summary>
        /// Warning: warnings and minor errors where recovery is possible.
        /// </summary>
        Warning,

        /// <summary>
        /// Info: informational entries.
        /// </summary>
        Info,

        /// <summary>
        /// Debug: rest.
        /// </summary>
        Debug
    }

    /// <summary>
    /// Interface for log events.
    /// </summary>
    public interface ILogEvent
    {
        /// <summary>
        /// Log error message.
        /// </summary>
        /// <param name="description"></param>
        void LogError(string description);

        /// <summary>
        /// Log error message with associated exception.
        /// </summary>
        /// <param name="description"></param>
        /// <param name="e"></param>
        void LogError(string description, Exception e);

        /// <summary>
        /// Log warning message.
        /// </summary>
        /// <param name="description">A warning message</param>
        void LogWarning(string description);

        /// <summary>
        /// Log warning message with an associated exception.
        /// </summary>
        /// <param name="description">A warning message</param>
        /// <param name="e">The associated exception</param>
        void LogWarning(string description, Exception e);

        /// <summary>
        /// Log info message.
        /// </summary>
        /// <param name="description"></param>
        void LogInfo(string description);

        /// <summary>
        /// Log info message with associated exception.
        /// </summary>
        /// <param name="description"></param>
        /// <param name="e"></param>
        void LogInfo(string description, Exception e);

        /// <summary>
        /// Log debug message.
        /// </summary>
        /// <param name="description"></param>
        void LogDebug(string description);

        /// <summary>
        /// Log debug message with associated exception.
        /// </summary>
        /// <param name="description"></param>
        /// <param name="e"></param>
        void LogDebug(string description, Exception e);

    }
}
