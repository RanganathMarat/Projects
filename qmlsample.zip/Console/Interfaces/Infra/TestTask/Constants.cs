﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Philips.PmsMR.UI.Interfaces.Infra.TestTask
{
    /// <summary>
    /// Static constants.
    /// </summary>
    public class Constants
    {
        /// <summary>
        /// Named event, set when build tests are running.
        /// </summary>
        public const string BuildTestEventName = "PhilipsMRBuildTest";

        #region Environment Variables
        /// <summary>
        /// An integer value, where set bits indicate allowed CPU affinity for processes.
        /// </summary>
        /// <remarks>
        /// The affinity can be used to artificially load some of the CPUs during the test run.
        /// </remarks>
        public const string ProcessorAffinity = "PhilipsMRProcessorAffinityMask";
        #endregion

    }
}
