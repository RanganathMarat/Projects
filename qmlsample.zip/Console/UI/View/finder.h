#ifndef FINDER
#define FINDER

// In Qt5, findChildren no longer works for repeater types (sets parent explicitly at runtime)
class Finder {
public:
    enum SearchType {Shallow, Recursive};
    Finder(QQuickItem & parent, SearchType search) : _parent(parent), _searchType(search), _abortSearch(false) {}
    QQuickItem * findRuntimeChild(const std::function<bool(QQuickItem &)> & predicate) {
        QQuickItem * retVal = nullptr;
        findRuntimeChildren(_parent, [&predicate, &retVal] (QQuickItem& tentativeChild) {
            if (predicate(tentativeChild)) {
                retVal = &tentativeChild;
                return true;
            }
            return false;
        }, true);
        return retVal;
    }
    void findRuntimeChildren(const std::function<void(QQuickItem &)> & predicate) {
        findRuntimeChildren(_parent, [&predicate] (QQuickItem& tentativeChild) {predicate(tentativeChild); return true;}, false);
    }
    QQuickItem * findParent() {
        QQuickItem * tmp = &_parent;
        do {
            if (isPresentedObject(*tmp)) {
                return tmp;
            }
            tmp = tmp->parentItem();
        } while (tmp != nullptr);
        return nullptr;
    }
private:
    bool isPresentedObject(QQuickItem & item) {
        auto name = item.objectName();
        return name.startsWith("zmq");
    }
    void findRuntimeChildren(QQuickItem & parent, const std::function<bool(QQuickItem &)> & predicate, bool stopAfterMatch) {
        QList<QQuickItem *> children = parent.childItems();
        foreach (QQuickItem *item, children) {
            bool presentedObject = isPresentedObject(*item);
            if (presentedObject) {
                if (predicate(*item)) {
                    if (stopAfterMatch) {
                        _abortSearch = true;
                        return;
                    }
                }
            }
            if (_searchType == Recursive || !presentedObject) {
                findRuntimeChildren(*item, predicate, stopAfterMatch);
            }
            if (_abortSearch) {
                return;
            }
        }
    }

    QQuickItem & _parent;
    SearchType _searchType;
    bool _abortSearch;
};

#endif // FINDER

