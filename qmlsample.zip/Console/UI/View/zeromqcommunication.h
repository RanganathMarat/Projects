#ifndef ZEROMQCOMMUNICATION
#define ZEROMQCOMMUNICATION

#include <QDebug>
#include <QObject>
#include <QQmlProperty>
#include <QQuickItem>

class ZeroMQCommunication : public QObject {
    Q_OBJECT
public:
    ZeroMQCommunication() : _localGenerationCount(0) {}
    virtual ~ZeroMQCommunication() {}

    Q_INVOKABLE void sendRadioMessage(QQuickItem* parentWidget, const QString & objectName) const;

    Q_INVOKABLE void sendCreationMessage(QQuickItem* parentWidget, const QString & createdName, const QString & typeName) const;
    // TODO: destruction message handling (remove items from _currentWidgets and send a message)

    Q_INVOKABLE void sendDragAndDrop(QQuickItem* widget, const QString & command) const;

    Q_INVOKABLE void sendScrollClick(QQuickItem* parentWidget, const QString & objectName, const QString & direction) const;

    // One-time-initialization per process.
    // Address format "tcp://127.0.0.1:1234"
    void initApplication(const QString & pub_address, const QString & req_address);

protected slots:
    void messageReceived(const QList<QByteArray>&);

private:
    // Ensure that a parent exists
    QQuickItem & enforceParent(QQuickItem* parentWidget, const QString & widget) const;

    void fireNotifications(const QList<QString> & pendingNotifications) const;

    QList<QString> sendBlockingMessage(QList<QByteArray> & message) const;

    void synchronizeFromNotifications();

    mutable __int64 _localGenerationCount;
    mutable QMap<QString, QQuickItem* > _currentWidgets;
};

#endif // ZEROMQCOMMUNICATION

