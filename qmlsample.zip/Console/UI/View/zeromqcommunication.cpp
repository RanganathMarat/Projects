#include <functional>

#include "zeromqcommunication.h"
#include "nzmqt/nzmqt.hpp"

#include "Finder.h"

namespace {
    nzmqt::ZMQSocket* s_sub_socket = nullptr;
    nzmqt::ZMQSocket* s_req_socket = nullptr;
}

QQuickItem & ZeroMQCommunication::enforceParent(QQuickItem* parent, const QString & widget) const {
    QQuickItem* parentWidget = parent;
    if (parentWidget == nullptr) {
        qCritical() << "Cannot enforce parent widget, parent widget is null for " << widget;
        throw std::runtime_error("No parent widget");
    }

    parentWidget = Finder(*parentWidget, Finder::Shallow).findParent();
    if (parentWidget == nullptr) {
        if (parent->objectName() == "root") {
            qDebug() << "Detected a root widget";
            parentWidget = parent;
        } else {
            qCritical() << "Cannot enforce parent for " << widget << ", zmq-named parent could not be found";
            throw std::runtime_error("No parent widget");
        }
    }
    return *parentWidget;
}

void ZeroMQCommunication::fireNotifications(const QList<QString> & pendingNotifications) const
{
    // TODO: we can measure the performance and data-bandwidth to identified widgets here to find bottle-necks

    // index 0: sync reply
    // index 1: generation count
    if (pendingNotifications.length() < 2) {
        qWarning() << "Invalid notification received, parts count " << pendingNotifications.length();
        return;
    }

    int index = 1;
    auto generationCount = pendingNotifications[index++].toLongLong();
    if (_localGenerationCount >= generationCount) {
        return;
    }

    qDebug() << "ZeroMQ generation count updated from " << _localGenerationCount << " to " << generationCount;
    _localGenerationCount = generationCount;

    while (index < pendingNotifications.length()) {
        auto subMessageParts = pendingNotifications[index++].toInt();
        if (subMessageParts == 0) {
            break;
        }
        int subIndex = 0;
        auto widgetId = pendingNotifications[index + (subIndex++)];
        auto notificationType = pendingNotifications[index + (subIndex++)];

        auto foundIt = _currentWidgets.find(widgetId);
        if (foundIt == _currentWidgets.end()) {
            qWarning() << "Invalid notification received, id not found: " << widgetId;
        } else {
            QString functionName = QString("onZmq") + notificationType;
            if (notificationType == "PatientSexChanged") {
                qDebug() << "Patient sex change notification detected";
                auto patientSexValue = pendingNotifications[index + (subIndex++)];
                QMetaObject::invokeMethod(
                    *foundIt,
                    functionName.toUtf8(),
                    Q_ARG(QVariant, patientSexValue));
            } if (notificationType == "StringChanged") {
                auto stringContainerId = pendingNotifications[index + (subIndex++)];
                auto newValue = pendingNotifications[index + (subIndex++)];
                qDebug() << "String change notification detected for " << widgetId << "'s " << stringContainerId << newValue;
                QMetaObject::invokeMethod(
                    *foundIt,
                    functionName.toUtf8(),
                    Q_ARG(QVariant, stringContainerId),
                    Q_ARG(QVariant, newValue));
            } else {
                qWarning() << "Unimplemented notification type received: " << notificationType;
            }
        }
        index += subMessageParts;
    }
}

void ZeroMQCommunication::initApplication(const QString & pub_address, const QString & req_address) {
    static nzmqt::ZMQContext* context = nullptr;
    if (context != nullptr) {
        throw std::runtime_error("Cannot initialize application multiple times");
    }
    context = nzmqt::createDefaultContext();

    {
        qDebug() << "ZeroMQ hooks a subscriber to " << pub_address;
        s_sub_socket = context->createSocket(nzmqt::ZMQSocket::TYP_SUB, this);
        s_sub_socket->setObjectName("UI.ViewNotifications subscriber");
        connect(s_sub_socket,
               SIGNAL(messageReceived(const QList<QByteArray>&)),
               SLOT(messageReceived(const QList<QByteArray>&)));
        s_sub_socket->subscribeTo("UI.ViewNotifications");
        s_sub_socket->connectTo(pub_address);
    }

    {
        qDebug() << "ZeroMQ connects requests to " << req_address;
        s_req_socket = context->createSocket(nzmqt::ZMQSocket::TYP_REQ);
        s_req_socket->connectTo(req_address);
    }

    // Start watching incoming messages
    context->start();

}

void ZeroMQCommunication::messageReceived(const QList<QByteArray>& message)
{
    qDebug() << "ZeroMQ received published notification";
    if (message.length() == 2) {
        // Index 0: topic
        // Index 1: 64bit generation count
        auto generationCount = QString::fromUtf8(message[1]).toLongLong();
        if (_localGenerationCount < generationCount) {
            qDebug() << "ZeroMQ synchronization needed: " << generationCount << ", vs. ours " << _localGenerationCount;
            synchronizeFromNotifications();
        } else {
            return;
        }
    } else {
        qWarning() << "Invalid notification received, message parts count " << message.length();
    }
}

QList<QString> ZeroMQCommunication::sendBlockingMessage(QList<QByteArray> & message) const {
    try {
        s_req_socket->sendMessage(message);

        // Wait for a reply in a blocking mode
        QList<QString> parts;
        nzmqt::ZMQMessage msg;
        while (s_req_socket->receiveMessage(&msg, 0)) {
            parts += QString::fromUtf8(msg.toByteArray());
            msg.rebuild();

            if (!s_req_socket->hasMoreMessageParts()) {
                break;
            }
        }

        auto replyMessageType = parts[0];
        if (replyMessageType == "Warning" || replyMessageType == "Error") {
            qCritical() << "Socket sending failed with " << parts[1];
        } else if (replyMessageType == "SyncReply") {
            qDebug() << "ZeroMQ got a sync reply";
            fireNotifications(parts);
        } else {
            qDebug() << "ZeroMQ got a reply: " << parts.length();
        }        

        return parts;
    } catch (std::exception & e) {
        qCritical() << "Socket sending failed with " << e.what();
        throw;
    } catch (...) {
        qFatal("Socket sending failed with an unknown exception");
        throw;
    }
}

void ZeroMQCommunication::sendCreationMessage(QQuickItem* parent, const QString & createdName, const QString & typeName) const {
    QQuickItem& parentWidget = enforceParent(parent, createdName);

    auto parentName = parentWidget.objectName();
    auto createdWidget = Finder(parentWidget, Finder::Shallow).findRuntimeChild(
        [&createdName] (QQuickItem & child) {return child.objectName() == createdName;});
    QString children;
    if (createdWidget != nullptr) {
        Finder(*createdWidget, Finder::Shallow).findRuntimeChildren(
            [&children] (QQuickItem & child) {
                auto childName = child.objectName();
                if (!childName.isEmpty()) {
                    children += childName + ";";
                }
        });
    }

    _currentWidgets.insert(createdName, createdWidget);
    qDebug() << "ZeroMQ sends a creation message " << parentName << " - " << createdName << ", type " << typeName << ", children: " << children;
    QList<QByteArray> list;
    list.append("Creation");
    list.append(QString::number(_localGenerationCount).toUtf8());
    list.append(parentName.toUtf8());
    list.append(createdName.toUtf8());
    list.append(typeName.toUtf8());
    list.append(children.toUtf8());
    sendBlockingMessage(list);
}

void ZeroMQCommunication::sendDragAndDrop(QQuickItem* widget, const QString & command) const {
    auto widgetName = widget->objectName();
    qDebug() << "ZeroMQ sends a Drag-n-Drop message from " << widgetName << ": " << command;
    QList<QByteArray> list;
    list.append("DragAndDrop");
    list.append(QString::number(_localGenerationCount).toUtf8());
    list.append(widgetName.toUtf8());
    list.append(command.toUtf8());
    sendBlockingMessage(list);
}

void ZeroMQCommunication::sendRadioMessage(QQuickItem* parent, const QString & objectName) const
{
    QQuickItem& parentWidget = enforceParent(parent, objectName);
    auto parentName = parentWidget.objectName();
    qDebug() << "ZeroMQ sends a radio message from " << parentName << " - " << objectName;
    QList<QByteArray> list;
    list.append("SetRadioButton");
    list.append(QString::number(_localGenerationCount).toUtf8());
    list.append(parentName.toUtf8());
    list.append(objectName.toUtf8());
    sendBlockingMessage(list);
}

void ZeroMQCommunication::sendScrollClick(QQuickItem* parent, const QString & objectName, const QString & direction) const {
    QQuickItem& parentWidget = enforceParent(parent, objectName);
    auto parentName = parentWidget.objectName();
    qDebug() << "ZeroMQ sends a scroll click message from " << parentName << " - " << objectName;
    QList<QByteArray> list;
    list.append("ScrollClick");
    list.append(QString::number(_localGenerationCount).toUtf8());
    list.append(parentName.toUtf8());
    list.append(objectName.toUtf8());
    list.append(direction.toUtf8());
    sendBlockingMessage(list);
}

void ZeroMQCommunication::synchronizeFromNotifications() {
    QList<QByteArray> list;
    list.append("Sync");
    list.append(QString::number(_localGenerationCount).toUtf8());
    sendBlockingMessage(list);
}
