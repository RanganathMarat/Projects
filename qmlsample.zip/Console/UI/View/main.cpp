#include <QApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>

#include "zeromqcommunication.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    ZeroMQCommunication zeroMQCommunication;
    QQmlApplicationEngine engine;

    QString pub_address = "tcp://127.0.0.1:1234";
    QString req_address = "tcp://127.0.0.1:1235";
    for (int index = 0;index < app.arguments().length();++index) {
        if (app.arguments().at(index) == "--pub_address") {
            pub_address = app.arguments().at(++index);
        }
        if (app.arguments().at(index) == "--req_address") {
            req_address = app.arguments().at(++index);
        }
    }

    // Start socket initialization
    zeroMQCommunication.initApplication(pub_address, req_address);

    engine.rootContext()->setContextProperty("zeroMQ", &zeroMQCommunication);

    engine.load(QUrl(QStringLiteral("qrc:/main.qml")));

    return app.exec();
}
