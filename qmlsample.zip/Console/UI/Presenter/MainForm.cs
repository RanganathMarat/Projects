﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Philips.PmsMR.UI.Presenter.PatientEntryPage;

namespace Philips.PmsMR.UI.Presenter
{
    class MainForm : PresenterBase
    {
        public MainForm(WidgetId associatedWidget, IPresenter parentPresenter) : base(associatedWidget) { }

        public override void OnRequestArrived(object command)
        {
            // TODO
        }
    }
}
