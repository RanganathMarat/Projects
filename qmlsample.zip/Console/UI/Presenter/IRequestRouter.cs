﻿namespace Philips.PmsMR.UI.Presenter
{
    interface IRequestRouter
    {
        object HandleRequest(object command);
    }
}
