﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Philips.PmsMR.UI.Presenter.Common;

namespace Philips.PmsMR.UI.Presenter.AcquisitionPage
{
    class ExecutionList : PresenterBase, Common.IScrollButtonParent, IExecutionItemParent
    {
        public ExecutionList(WidgetId id, IPresenter parent) : base(id)
        {
        }

        public override void OnRequestArrived(object command)
        {
        }

        public void OnButtonClicked(Common.ScrollButtonDirection direction)
        {
            int oldScrollValue = scrollOffset;
            notificationsFactory.QueryModel(context =>
            {
                var patientInScanner = context.PatientScheduler.PatientInScanner;
                if (patientInScanner == null)
                {
                    return;
                }
                var examCard = patientInScanner.CurrentExamCard;
                if (examCard == null)
                {
                    return;
                }

                switch (direction)
                {
                    case ScrollButtonDirection.Right:       
                        if (scrollOffset + items.Count >= examCard.Items.Count)
                        {
                            return;
                        }
                        ++scrollOffset;
                        break;
                    case ScrollButtonDirection.Left:
                        if (scrollOffset == 0)
                        {
                            return;
                        }
                        --scrollOffset;
                        break;
                }
            });
            if (scrollOffset != oldScrollValue)
            {
                foreach (var child in items.Values)
                {
                    child.RefreshAll();
                }
            }
        }

        #region IExecutionItemParent Methods

        public Guid GetCurrentItemId(ExecutionItem child)
        {
            var itemListIndex = items.First(x => x.Value == child).Key;
            var itemIndex = itemListIndex + scrollOffset;

            // Iterate over the flattened hierarchy
            Guid retVal = Guid.Empty;
            ExecuteSimple(x =>
            {
                var patientInScanner = x.PatientScheduler.PatientInScanner;
                if (patientInScanner == null)
                {
                    return;
                }
                var examCard = patientInScanner.CurrentExamCard;
                if (examCard == null)
                {
                    return;
                }
                if (examCard.Items.Count <= itemIndex)
                {
                    return;
                }
                retVal = examCard.Items[itemIndex].Id;
            });
            return retVal;
        }

        public Guid GetDragAndDropStart()
        {
            return items.Select(x => x.Value.DragAndDropStartId).FirstOrDefault(x => x != Guid.Empty);
        }

        public void OnCreated(ExecutionItem child, int index)
        {
            items.Add(index, child);

            child.RefreshAll();
        }

        #endregion

        private int scrollOffset = 0;
        private readonly SortedList<int, ExecutionItem> items = new SortedList<int, ExecutionItem>();
    }
}
