﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Philips.PmsMR.UI.Presenter.AcquisitionPage
{
    interface IExecutionItemParent
    {
        /// <summary>
        /// Finds an exam card item to display for this child item
        /// </summary>
        /// <param name="child"></param>
        /// <returns>Guid.Empty if the item should not be displayed (no data)</returns>
        Guid GetCurrentItemId(ExecutionItem child);

        /// <summary>
        /// Find the current drag-n-drop source from source items
        /// </summary>
        /// <returns></returns>
        Guid GetDragAndDropStart();

        void OnCreated(ExecutionItem child, int inde);
    }
}
