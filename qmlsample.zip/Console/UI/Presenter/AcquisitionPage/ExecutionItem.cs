﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using Philips.PmsMR.UI.Interfaces.Model.Examination;
using Philips.PmsMR.UI.Interfaces.Presenter.ZeroMQMessages.Notifications;
using Philips.PmsMR.UI.Interfaces.Presenter.ZeroMQMessages.Requests;

namespace Philips.PmsMR.UI.Presenter.AcquisitionPage
{
    class ExecutionItem : PresenterBase
    {
        public ExecutionItem(WidgetId id, IPresenter parent)
            : base(id)
        {
            itemParent = (IExecutionItemParent) parent;

            // TODO: fix with protobuf, now a string hack
            var indexStr = indexExtractor.Match(id.IdAsString()).Groups["index"].ToString();
            var index = Int32.Parse(indexStr);
            itemParent.OnCreated(this, index);

            notificationsFactory.ChangeSubscriptions(x =>
            {
                x.PatientScheduler.PatientInScanner.CurrentExamCard.ExamCardChanged += OnExamCardChanged;
            });
        }

        public Guid DragAndDropStartId { get; set; }

        public override void OnRequestArrived(object command)
        {
            var dragAndDrop = command as DragAndDrop;
            if (dragAndDrop != null)
            {
                switch (dragAndDrop.Command)
                {
                    case "Start":
                        DragAndDropStartId = itemParent.GetCurrentItemId(this);
                        break;
                    case "Move":
                        // TODO: drag-n-drop implementation
                        var sourceId = itemParent.GetDragAndDropStart();
                        var targetId = itemParent.GetCurrentItemId(this);
                        if (targetId == Guid.Empty || sourceId == Guid.Empty)
                        {
                            return;
                        }
                        ExecuteSimple(context =>
                        {
                            var patient = context.PatientScheduler.PatientInScanner;
                            if (patient == null)
                            {
                                return;
                            }
                            var examCard = patient.CurrentExamCard;
                            if (examCard == null)
                            {
                                return;
                            }

                            MovePositionType moveDirection = MovePositionType.Before;
                            foreach (var item in examCard.Items)
                            {
                                if (sourceId == item.Id)
                                {
                                    moveDirection = MovePositionType.After;
                                    break;
                                }
                                if (targetId == item.Id)
                                {
                                    moveDirection = MovePositionType.Before;
                                    break;
                                }
                            }

                            examCard.Move(sourceId, targetId, moveDirection);
                        });
                        break;
                    case "CleanUp":
                        DragAndDropStartId = Guid.Empty;
                        break;
                    default:
                        throw new NotImplementedException("Unimplemented drag-n-drop command: " + dragAndDrop.Command);
                }
            }
        }

        /// <summary>
        /// Update all visible aspects in one go.
        /// </summary>
        public void RefreshAll()
        {
            ExecuteSimple(context =>
            {
                OnExamCardChanged(context.PatientScheduler.PatientInScanner.CurrentExamCard);
            });
        }

        private void OnExamCardChanged(IExamCard changedCard)
        {
            modelItemId = itemParent.GetCurrentItemId(this);
            IScan modelItem = modelItemId == Guid.Empty ? null : changedCard.FindExecutionItem(modelItemId) as IScan;

            PostNotification(new StringChanged
            {
                WidgetId = "zmqItemName",
                NewValue = modelItem == null ? "" : modelItem.ProtocolName
            });
        }

        private readonly IExecutionItemParent itemParent;
        private Guid modelItemId;
        private static readonly Regex indexExtractor = new Regex(@".*(?<index>\d+)", RegexOptions.Compiled);
    }
}
