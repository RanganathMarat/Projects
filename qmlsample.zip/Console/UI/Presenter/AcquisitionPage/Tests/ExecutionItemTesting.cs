﻿using System;
using System.Collections.Generic;
using System.Linq;

#if NUnitTest
using NUnit.Framework;
using Rhino.Mocks;
using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo(RhinoMocks.StrongName)]

namespace Philips.PmsMR.UI.Presenter.AcquisitionPage.Tests
{
    public class ExecutionItemTesting: Infra.Utilities.UnitTest.TestBed
    {
        [Test]
        public void Ctor_WidgetIdContainsIndex_ParentNotifiedOfCreation()
        {
            var parent = MockRepository.GenerateMock(typeof (IPresenter), new Type[] {typeof (IExecutionItemParent)}) as IPresenter;
            var id = new WidgetId("zmqExecutionItem3");
            var exeItem = new ExecutionItem(id, parent);
            ((IExecutionItemParent)parent).AssertWasCalled(x => x.OnCreated(exeItem, 3));
        }
    }
}
#endif
