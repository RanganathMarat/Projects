﻿using System;
using System.Collections.Generic;
using System.Linq;
using Philips.PmsMR.UI.Interfaces.Presenter;
#if NUnitTest
using NUnit.Framework;
using Philips.PmsMR.UI.Interfaces.Presenter.ZeroMQMessages.Requests;

namespace Philips.PmsMR.UI.Presenter.Tests
{
    public class RequestRouting : Infra.Utilities.UnitTest.TestBed
    {
        [Test]
        public void Ctor_RouteMapReflected_RoutingAvailableAfterConstruction()
        {
            var router = new RequestRouter();
            var sampleRequest = new SetRadioButton
            {
                RadioButtonParentId = "sample invalid id",
                RadioButtonId = "sample invalid id2"
            };
            var ex = Assert.Throws<System.Reflection.TargetInvocationException>(() => router.HandleRequest(sampleRequest), 
                "Invalid widget id should have been detected in the available router handler");
            Assert.That(ex.InnerException, Is.AssignableFrom<InvalidWidgetException>());
        }

        [Test]
        public void HandleRequest_UnknownRequest_NotImplementedExceptionThrown()
        {
            var router = new RequestRouter();
            var sampleRequest = new SampleUnknownRequest();
            var ex = Assert.Throws<NotImplementedException>(() => router.HandleRequest(sampleRequest));
        }

        private class SampleUnknownRequest { }
    }
}

#endif
