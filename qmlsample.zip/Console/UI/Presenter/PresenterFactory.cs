﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Philips.PmsMR.UI.Interfaces.Presenter.ZeroMQMessages.Requests;

namespace Philips.PmsMR.UI.Presenter
{
    class PresenterFactory
    {

        public static PresenterFactory Instance { get { return instance;} }

        public IPresenter Create(Creation creation, IPresenter parentPresenter)
        {
            // TODO: this will be removed by the introduction of protobuf (can be automated)
            IPresenter widgetPresenter;
            var widgetId = new WidgetId(creation.WidgetId);
            switch (creation.WidgetType)
            {
                case "ZMQExecutionItem":
                    widgetPresenter = new AcquisitionPage.ExecutionItem(widgetId, parentPresenter);
                    break;
                case "ZMQExecutionList":
                    widgetPresenter = new AcquisitionPage.ExecutionList(widgetId, parentPresenter);
                    break;
                case "ZMQMainForm":
                    widgetPresenter = new MainForm(widgetId, parentPresenter);
                    break;
                case "ZMQRadioButton":
                    widgetPresenter = new Common.RadioButton(widgetId, parentPresenter);
                    break;
                case "ZMQPatientSexEditor":
                    widgetPresenter = new PatientEntryPage.PatientSexEditor(widgetId, parentPresenter);
                    break;
                case "ZMQScrollButton":
                    widgetPresenter = new Common.ScrollButton(widgetId, parentPresenter);
                    break;
                default:
                    throw new NotImplementedException("Implementation for " + creation.WidgetType + " does not exist");
            }
            return widgetPresenter;            
        }

        private static readonly PresenterFactory instance = new PresenterFactory();
    }
}
