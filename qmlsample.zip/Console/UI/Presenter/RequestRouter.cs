﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Philips.PmsMR.UI.Interfaces.Presenter;
using Philips.PmsMR.UI.Interfaces.Presenter.ZeroMQMessages.Requests;

namespace Philips.PmsMR.UI.Presenter
{
    /// <summary>
    /// Routes the commands to the presenters.
    /// </summary>
    /// <remarks>
    /// Uses reflection to populate a map of known requests:
    /// each internal Handle-method declares a supported request type.
    /// </remarks>
    public class RequestRouter : IRequestRouter
    {
        public delegate object HandleCallback(RequestRouter thisRouter, object request);

        static RequestRouter()
        {
            var methods = typeof(RequestRouter).GetMethods(BindingFlags.Instance | BindingFlags.NonPublic);
            var handlers = methods.Where(x => x.Name == "Handle");
            foreach (var handler in handlers)
            {
                var handlerMethod = handler;
                var requestType = handlerMethod.GetParameters().Single().ParameterType;
                typeCommandMap[requestType] = (router, o) =>
                {
                    try
                    {
                        return handlerMethod.Invoke(router, new[] {o});
                    }
                    catch (TargetInvocationException e)
                    {
                        if (e.InnerException != null)
                        {
                            var innerType = e.InnerException.GetType();
                            if (innerType.IsInstanceOfType(typeof(NotImplementedException)) ||
                                innerType.IsInstanceOfType(typeof(InvalidWidgetException)))
                            {
                                throw e.InnerException;        
                            }
                        }
                        throw;
                    }
                };
            }
        }

        internal RequestRouter()
        {
            creationCache = new CreationCache(IsRootCreation);
        }

        public static RequestRouter Instance { get { return instance;} }

        #region IRequestRouter Methods

        public object HandleRequest(object request)
        {
            if (request == null)
            {
                throw new ArgumentNullException("request", "RequestRouter cannot handle null request");
            }
            try
            {
                return typeCommandMap[request.GetType()](this, request);
            }
            catch (KeyNotFoundException)
            {
                throw new NotImplementedException("RequestRouter does not have an implementation for " + request.GetType());
            }
        }

        #endregion

        #region Actual handlers - function name must be "Handle" with a single request parameter
        private object Handle(SetRadioButton setRadioButton)
        {
            IPresenter presenter;
            if (!idPresenterMap.TryGetValue(setRadioButton.RadioButtonId, out presenter))
            {
                throw new InvalidWidgetException("Cannot find a presenter for " + setRadioButton.RadioButtonId);
            }
            presenter.OnRequestArrived(setRadioButton);
            return null;
        }

        private object Handle(Creation creation)
        {
            if (idPresenterMap.ContainsKey(creation.WidgetId) || 
                (!rootCreated && creationCache.IsAlreadyCached(creation)))
            {
                // Already created, ignore the second notification
                return null;
            }

            if (!rootCreated)
            {
                IEnumerable<Creation> flushedCache = creationCache.TryAdding(creation);
                if (flushedCache == null)
                {
                    // A child item, we need still to wait for the final root creation
                    return null;
                }

                rootCreated = true;
                foreach (var item in flushedCache.Reverse())
                {
                    Handle(item);
                }
            }

            IPresenter parentPresenter = null;
            if (!IsRootCreation(creation))
            {
                if (!idPresenterMap.TryGetValue(creation.ParentId, out parentPresenter))
                {
                    throw new InvalidWidgetException("Cannot find a parent presenter " + creation.ParentId);
                }
            }
            else
            {
                System.Diagnostics.Trace.WriteLine("Handling the creation of the root widget");
            }

            var widgetPresenter = PresenterFactory.Instance.Create(creation, parentPresenter);
            idPresenterMap[creation.WidgetId] = widgetPresenter;
            return null;
        }

        private object Handle(DragAndDrop dragAndDrop)
        {
            IPresenter sourcePresenter;
            if (!idPresenterMap.TryGetValue(dragAndDrop.WidgetId, out sourcePresenter))
            {
                throw new InvalidWidgetException("Cannot find a source presenter for " + dragAndDrop.WidgetId);
            }

            sourcePresenter.OnRequestArrived(dragAndDrop);
            return null;
        }

        private object Handle(ScrollClick scrollClick)
        {
            IPresenter presenter;
            if (!idPresenterMap.TryGetValue(scrollClick.ButtonId, out presenter))
            {
                throw new InvalidWidgetException("Cannot find a presenter for " + scrollClick.ButtonId);
            }
            presenter.OnRequestArrived(scrollClick);
            return null;
        }


        private object Handle(Sync sync)
        {
            return Communication.PublicationQueue.Instance.GetNotifications(sync);
        }
        #endregion

        private bool IsRootCreation(Creation creation)
        {
            return String.Compare(creation.ParentId, "root", StringComparison.InvariantCulture) == 0;
        }

        private readonly Dictionary<string, IPresenter> idPresenterMap = new Dictionary<string, IPresenter>();
        private readonly CreationCache creationCache;
        private bool rootCreated;

        private static readonly Dictionary<Type, HandleCallback> typeCommandMap = new Dictionary<Type, HandleCallback>();

        private static readonly RequestRouter instance = new RequestRouter();
    }
}
