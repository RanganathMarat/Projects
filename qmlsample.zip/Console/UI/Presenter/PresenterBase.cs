using System;
using Philips.PmsMR.UI.Interfaces.Model.Commands;
using Philips.PmsMR.UI.Interfaces.Model.Notifications;
using Philips.PmsMR.UI.Presenter.PatientEntryPage;

namespace Philips.PmsMR.UI.Presenter
{
    /// <summary>
    /// Abstract base class for presenter instances.
    /// </summary>
    abstract class PresenterBase : IPresenter
    {
        protected PresenterBase(WidgetId associatedWidget) : this(
            associatedWidget, 
            Model.Commands.CommandsFactory.Instance, 
            Model.Notifications.NotificationsFactory.Instance,
            Communication.PublicationQueue.Instance) { }

        protected PresenterBase(WidgetId associatedWidget, 
            ICommandFactory commandFactory, INotificationsFactory notificationsFactory, Communication.IPublicationQueue publicationQueue)
        {
            this.associatedWidget = associatedWidget;
            this.commandFactory = commandFactory;
            this.notificationsFactory = notificationsFactory;
            this.publicationQueue = publicationQueue;
        }

        /// <summary>
        /// Convenience method for executing synchronously a method, 
        /// whose return value does not matter.
        /// </summary>
        /// <param name="commandLambda"></param>
        protected void ExecuteSimple(Action<ICommandContext> commandLambda)
        {
            commandFactory.CreateSimple(commandLambda).Execute();
        }

        protected void PostNotification(object notification)
        {
            publicationQueue.Enqueue(associatedWidget, notification);
        }

        /// <summary>
        /// Presenter-specific handler for requests.
        /// </summary>
        /// <remarks>
        /// Each presenter type can try to cast the command into a command message type the presenter is capable of handling.
        /// </remarks>
        /// <param name="command"></param>
        public abstract void OnRequestArrived(object command);

        protected WidgetId associatedWidget;
        protected ICommandFactory commandFactory;
        protected INotificationsFactory notificationsFactory;

        private Communication.IPublicationQueue publicationQueue;

        internal const string DefaultWidgetPrefix = "zmq";
    }
}