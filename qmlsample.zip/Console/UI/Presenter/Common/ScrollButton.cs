﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Philips.PmsMR.UI.Interfaces.Presenter.ZeroMQMessages.Requests;

namespace Philips.PmsMR.UI.Presenter.Common
{
    class ScrollButton : PresenterBase
    {
        public ScrollButton(WidgetId associatedWidget, IPresenter parentPresenter)
            : base(associatedWidget)
        {
            this.parentPresenter = (IScrollButtonParent)parentPresenter;
        }

        public override void OnRequestArrived(object command)
        {
            var click = command as ScrollClick;
            if (click != null)
            {
                ScrollButtonDirection direction;
                switch (click.ScrollDirection)
                {
                    case "zmqLeft":
                        direction = ScrollButtonDirection.Left;
                        break;
                    case "zmqRight":
                        direction = ScrollButtonDirection.Right;
                        break;
                    default:
                        throw new NotImplementedException("Unimplemented scroll direction: " + click.ScrollDirection);
                }
                parentPresenter.OnButtonClicked(direction);
            }
        }

        private readonly IScrollButtonParent parentPresenter;
    }
}
