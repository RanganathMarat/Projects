﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Philips.PmsMR.UI.Presenter.Common
{
    class RadioButton : PresenterBase
    {
        public RadioButton(WidgetId associatedWidget, IPresenter parentPresenter) : base(associatedWidget)
        {
            this.parentPresenter = (IRadioButtonParent)parentPresenter;
        }

        public override void OnRequestArrived(object command)
        {
            var setCmd =  command as Interfaces.Presenter.ZeroMQMessages.Requests.SetRadioButton;
            if (setCmd != null)
            {
                parentPresenter.OnButtonClicked(setCmd.RadioButtonId.Substring(DefaultWidgetPrefix.Length));
            }
        }

        private readonly IRadioButtonParent parentPresenter;
    }
}
