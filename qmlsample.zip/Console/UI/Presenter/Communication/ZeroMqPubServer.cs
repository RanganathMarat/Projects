﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using NetMQ;

namespace Philips.PmsMR.UI.Presenter.Communication
{
    class ZeroMqPubServer : IDisposable
    {
        public ZeroMqPubServer(NetMQContext netMqContext, string address, IPublicationQueue publicationQueue = null)
        {
            pubSocket = netMqContext.CreatePublisherSocket();
            pubSocket.Bind(address);
            this.publicationQueue = publicationQueue ?? PublicationQueue.Instance;
        }

        public void Run(CancellationToken cancellationToken)
        {
            CheckDisposed();
            publicationQueue.Register(cancellationToken);

            while (!cancellationToken.IsCancellationRequested)
            {
                var generationCount = publicationQueue.WaitForNotifications(cancellationToken);
                if (cancellationToken.IsCancellationRequested)
                {
                    System.Diagnostics.Trace.WriteLine("Publication server got a cancellation request, exiting");
                    return;
                }

                System.Diagnostics.Trace.WriteLine("Publication server sends a notification for count " + generationCount);
                pubSocket.SendMore(PublicationTopic).Send(generationCount.ToString(CultureInfo.InvariantCulture));
            }
            
        }
        
        #region IDisposable
        /// <summary>
        /// Disposal flag.
        /// </summary>        
        protected bool disposed;

        /// <summary>
        /// Dispose implementation.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Finalizer.
        /// </summary>
        ~ZeroMqPubServer()
        {
            Dispose(false);
        }

        /// <summary>
        /// Finalizer/disposal.
        /// </summary>
        /// <param name="disposing">Set when called from the explicit dispose</param>        
        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    if (pubSocket != null)
                    {
                        pubSocket.Dispose();
                        pubSocket = null;
                    }
                }
                else
                {
                    System.Diagnostics.Debug.Assert(false, "Forgot to dispose object of type ZeroMqPubServer");
                }
                disposed = true;
            }
        }

        /// <summary>
        /// A check for disposal.
        /// </summary>        
        /// <exception cref="ObjectDisposedException">Throws if already disposed of</exception>
        protected void CheckDisposed()
        {
            if (disposed)
            {
                System.Diagnostics.Debug.Assert(false, "Trying to use disposed object of type ZeroMqPubServer");
                throw new ObjectDisposedException("ZeroMqPubServer");
            }
        }
        #endregion

        internal const string PublicationTopic = "UI.ViewNotifications";

        private readonly IPublicationQueue publicationQueue;
        private NetMQ.Sockets.PublisherSocket pubSocket;
    }
}
