﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;
using Philips.PmsMR.UI.Interfaces.Presenter.ZeroMQMessages.Requests;

namespace Philips.PmsMR.UI.Presenter.Communication
{
    /// <summary>
    /// UI notifications to be published are posted to this queue.
    /// </summary>
    class PublicationQueue : IPublicationQueue
    {
        public static PublicationQueue Instance = new PublicationQueue();

        public void Enqueue(WidgetId targetWidgetId, object notification)
        {
            lock (queue)
            {
                var timeStamp = DateTime.UtcNow;
                queue.Add(new NotificationData
                {
                    GenerationTimeStamp = timeStamp,
                    Notification = notification,
                    PublisherGenerationCount = ++generationCount,
                    TargetWidgetId = targetWidgetId
                });
                Monitor.PulseAll(queue);

                // Scrub cache from stale entries
                while (cache.Count > 0)
                {
                    if (cache[0].GenerationTimeStamp + MaximumCacheAge < timeStamp)
                    {
                        cache.RemoveAt(0);
                    }
                    else
                    {
                        break;
                    }
                }
            }
        }

        public object GetNotifications(Sync request)
        {
            // TODO: use proper types instead of strings
            var viewCount = Int64.Parse(request.GenerationCount, CultureInfo.InvariantCulture);
            var missedNotifications = new LinkedList<object>();
            Int64 updatedCount;

            bool historyStillAvailable = false;
            lock (queue)
            {
                updatedCount = generationCount;
                foreach (var cachedItem in ((IEnumerable<NotificationData>)(cache)).Reverse())
                {
                    if (cachedItem.PublisherGenerationCount <= viewCount)
                    {
                        if (cachedItem.PublisherGenerationCount == viewCount)
                        {
                            historyStillAvailable = true;
                        }
                        break;
                    }
                    missedNotifications.AddFirst(cachedItem);
                }

                foreach (var queueItem in queue)
                {
                    if (queueItem.PublisherGenerationCount <= viewCount)
                    {
                        if (queueItem.PublisherGenerationCount == viewCount)
                        {
                            historyStillAvailable = true;
                        }
                        continue;
                    }
                    missedNotifications.AddLast(queueItem);
                }                
            }

            if (viewCount > 0 && !historyStillAvailable && cache.Count > 0)
            {
                return new ErrorReply 
                    {
                        DescriptiveErrorText =
                            "Synchronization request came in too late, current generation count: " + updatedCount +
                            " vs. requested " + viewCount
                    };
            }

            var retVal = new SyncReply
            {
                GenerationCount = updatedCount.ToString(CultureInfo.InvariantCulture),
                EmbeddedNotifications = missedNotifications
            };
            return retVal;
        }

        public void Register(CancellationToken token)
        {
            token.Register(() =>
            {
                if (!token.IsCancellationRequested)
                {
                    throw new ApplicationException("Cancellation registration cannot work without cancel being set");
                }
                lock (queue)
                {
                    Monitor.PulseAll(queue);
                }
            });
        }

        public Int64 WaitForNotifications(CancellationToken token)
        {
            Int64 count = 0;
            lock (queue)
            {
                while (queue.Count == 0 && !token.IsCancellationRequested)
                {
                    Monitor.Wait(queue);
                }
                if (queue.Count > 0)
                {
                    count = generationCount;
                    cache.AddRange(queue);
                    queue.Clear();
                }
            }

            return count;
        }

        private readonly List<NotificationData> queue = new List<NotificationData>();
        private readonly List<NotificationData> cache = new List<NotificationData>();
        private Int64 generationCount;

        // TODO: fix this with client counting - instead of timestamps
        private static readonly TimeSpan MaximumCacheAge = TimeSpan.FromMinutes(5);
    }
}
