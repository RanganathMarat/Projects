﻿using System;
using System.Collections.Generic;
using System.Data.Odbc;
using System.Globalization;
using System.Linq;
using System.Threading;
using NetMQ;
using Philips.PmsMR.UI.Interfaces.Presenter;
using Philips.PmsMR.UI.Interfaces.Presenter.ZeroMQMessages.Notifications;
using Philips.PmsMR.UI.Interfaces.Presenter.ZeroMQMessages.Requests;

namespace Philips.PmsMR.UI.Presenter.Communication
{
    /// <summary>
    /// Implements the REP contract for the View Layer.
    /// </summary>
    /// <remarks>
    /// <para>
    /// TODO: to add a new request-type for View-Presenter communication, one needs to:
    /// 1. Add a request message class to Interfaces.Presenter.ZeroMQMessages-namespace
    /// [1.1. This class: Add an interpreter for the message for converting from zeromq strings to the message - step will go away once protobuf is in]
    /// 2. Add a Handle-method into RequestRouter to dispatch the message handling to the corred presenter instance
    /// 3. Implement the command on the associated presenter class
    /// </para>
    /// <para>
    /// TODO: to add a new presenter type, one needs to:
    /// 1. Add a string case to PresenterFactory to route the creation message to the allocation of a new type
    /// 2. Implement the new presenter type that inherits from PresenterBase
    /// 3. Declare a parent interface if the request on the presenter needs actions on the parent presenter
    /// [3.1 Add a Interfaces.Presenter.ZeroMQMessages.Requests classes for the new request types from the widget - see request-type above]
    /// 4. Implement OnRequestArrived on the presenter to detect incoming requests
    /// </para>
    /// </remarks>

    class ZeroMqRepServer : IDisposable
    {
        public ZeroMqRepServer(NetMQContext netMqContext, string address, IRequestRouter commandRouter = null)
        {
            repSocket = netMqContext.CreateResponseSocket();
            repSocket.Bind(address);
            this.commandRouter = commandRouter ?? RequestRouter.Instance;
        }

        public void Run(CancellationToken cancellationToken)
        {
            using (var poller = new Poller())
            {
                poller.AddSocket(repSocket);
                using (cancellationToken.Register(() =>
                {
                    System.Diagnostics.Trace.WriteLine("Rep server got a cancellation request");
                    // It is ok to use the disposable in this closure, token registration will go out of scope before the poller
                    poller.Cancel();
                }))
                {
                    System.Diagnostics.Trace.WriteLine("Trying to receive");
                    repSocket.ReceiveReady += (sender, args) =>
                    {
                        System.Diagnostics.Trace.WriteLine("Received a message");
                        var socket = args.Socket;
                        var list = new List<string>();
                        bool more;
                        do
                        {
                            var data = socket.ReceiveFrameString(out more);
                            list.Add(data);

                        } while (more);

                        string remoteCount;
                        var request = InterpretMessage(list, out remoteCount);
                        HandleUIRequest(socket, request, remoteCount);
                    };

                    poller.PollTillCancelled();
                }
            }
        }

        private void HandleUIRequest(NetMQSocket socket, object request, string remoteCount)
        {
            try
            {
                var reply = commandRouter.HandleRequest(request);
                if (reply == null)
                {
                    // A message was not a sync message, flush the notifications
                    HandleUIRequest(socket, new Sync { GenerationCount = remoteCount }, remoteCount);
                }
                else
                {
                    // A sync message reply
                    var replyMessage = InterpretReply(reply);
                    socket.SendMessage(replyMessage);
                }
            }
            catch (InvalidWidgetException e)
            {
                var message = new NetMQMessage();
                message.Append("Warning");
                message.Append(e.ToString());
                socket.SendMessage(message);
            }
            catch (NotImplementedException e)
            {
                var message = new NetMQMessage();
                message.Append("Warning");
                message.Append(e.ToString());
                socket.SendMessage(message);
            }
            catch (Exception e)
            {
                var message = new NetMQMessage();
                message.Append("Error");
                message.Append(e.ToString());
                socket.SendMessage(message);
                throw;
            }
        }

        #region IDisposable
        /// <summary>
        /// Disposal flag.
        /// </summary>        
        protected bool disposed;

        /// <summary>
        /// Dispose implementation.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Finalizer.
        /// </summary>
        ~ZeroMqRepServer()
        {
            Dispose(false);
        }

        /// <summary>
        /// Finalizer/disposal.
        /// </summary>
        /// <param name="disposing">Set when called from the explicit dispose</param>        
        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    if (repSocket != null)
                    {
                        repSocket.Dispose();
                        repSocket = null;
                    }
                }
                else
                {
                    System.Diagnostics.Debug.Assert(false, "Forgot to dispose object of type ZeroMqRepServer");
                }
                disposed = true;
            }
        }

        /// <summary>
        /// A check for disposal.
        /// </summary>        
        /// <exception cref="ObjectDisposedException">Throws if already disposed of</exception>
        protected void CheckDisposed()
        {
            if (disposed)
            {
                System.Diagnostics.Debug.Assert(false, "Trying to use disposed object of type ZeroMqRepServer");
                throw new ObjectDisposedException("ZeroMqRepServer");
            }
        }
        #endregion

        /// <summary>
        /// TODO: this to protobuf deserialization, now a quick string hack
        /// </summary>
        /// <param name="messageParts"></param>
        /// <param name="remoteGenerationCount"></param>
        /// <returns></returns>
        private object InterpretMessage(List<string> messageParts, out string remoteGenerationCount)
        {
            // Ugly string handling, do not stare!
            remoteGenerationCount = messageParts[1];
            switch (messageParts.First())
            {
                case "Creation":
                    return new Creation
                    {
                        ParentId = messageParts[2],
                        WidgetId = messageParts[3],
                        WidgetType = messageParts[4]
                    };
                case "DragAndDrop":
                    return new DragAndDrop
                    {
                        WidgetId = messageParts[2],
                        Command = messageParts[3]
                    };
                case "ScrollClick":
                    return new ScrollClick
                    {
                        ParentId = messageParts[2],
                        ButtonId = messageParts[3],
                        ScrollDirection = messageParts[4]
                    };
                case "SetRadioButton":
                    return new SetRadioButton
                    {
                        RadioButtonParentId = messageParts[2],
                        RadioButtonId = messageParts[3]
                    };
                case "Sync":
                    return new Sync
                    {
                        GenerationCount = messageParts[1]
                    };
                default:
                    throw new NotImplementedException("Unknown command received: " + messageParts.First());
            }
        }

        /// <summary>
        /// TODO: automate this with probuf, now a simplistic brute-force string encoding
        /// </summary>
        /// <param name="reply"></param>
        /// <returns></returns>
        private NetMQMessage InterpretReply(object reply)
        {
            var syncReply = reply as SyncReply;
            if (syncReply != null)
            {
                var message = new NetMQMessage();
                message.Append("SyncReply");
                message.Append(syncReply.GenerationCount);
                foreach (NotificationData data in syncReply.EmbeddedNotifications)
                {
                    var subMessage = new List<string> { data.TargetWidgetId.IdAsString() };

                    Action<List<string>, object> act;
                    if (ReplyCreatorMap.TryGetValue(data.Notification.GetType(), out act))
                    {
                        act(subMessage, data.Notification);
                    }
                    else { 
                        throw new NotImplementedException("Reply type not implemented: " + data.Notification.GetType());
                    }

                    message.Append(subMessage.Count.ToString(CultureInfo.InvariantCulture));
                    foreach (var part in subMessage)
                    {
                        message.Append(part);
                    }
                }
                return message;
            }

            var errorReply = reply as ErrorReply;
            if (errorReply != null)
            {
                var message = new NetMQMessage();
                message.Append("Error");
                message.Append(errorReply.DescriptiveErrorText);
                return message;
            }

            throw new NotImplementedException("Unimplemented reply type: " + reply.GetType());
        }

        private static readonly Dictionary<Type, Action<List<string>, object>> ReplyCreatorMap =
            new Dictionary<Type, Action<List<string>, object>> {
            {
                typeof (PatientSexChanged), (msg, reply) =>
                {
                    var patientSexChanged = (PatientSexChanged) reply;
                    msg.Add("PatientSexChanged");
                    msg.Add(patientSexChanged.PatientSex);
                }
            }, {
                   typeof(StringChanged), (msg, reply) =>
                   {
                       var stringChanged = (StringChanged) reply;
                       msg.Add("StringChanged");
                       msg.Add(stringChanged.WidgetId);
                       msg.Add(stringChanged.NewValue);
                   }                    
                }
        };

        private NetMQ.Sockets.ResponseSocket repSocket;
        private readonly IRequestRouter commandRouter;
    }
}
