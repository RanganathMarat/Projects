﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Philips.PmsMR.UI.Interfaces.Presenter.ZeroMQMessages.Requests;

namespace Philips.PmsMR.UI.Presenter.Communication
{

    class NotificationData
    {
        public WidgetId TargetWidgetId;

        public object Notification;

        public Int64 PublisherGenerationCount;

        public DateTime GenerationTimeStamp;
    }

    interface IPublicationQueue
    {
        void Enqueue(WidgetId targetWidgetId, object notification);

        object GetNotifications(Sync request);

        void Register(CancellationToken token);

        Int64 WaitForNotifications(CancellationToken token);
    }
}
