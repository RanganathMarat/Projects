﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using NetMQ;
using Philips.PmsMR.UI.Interfaces.Presenter;

namespace Philips.PmsMR.UI.Presenter.Communication
{
    /// <summary>
    /// ZeroMQ communication to the View Layer.
    /// </summary>
    public class ZeroMqCommunication : IDisposable
    {
        public void Launch(NetMQContext netMqContext, string pubAddress, string repAddress)
        {
            CheckDisposed();
            var cancellationToken = cancellation.Token;

            pubServerTask = Task.Factory.StartNew(() =>
            {
                using (var pubServer = new ZeroMqPubServer(netMqContext, pubAddress))
                {
                    pubServer.Run(cancellationToken);
                }
            }, cancellationToken, TaskCreationOptions.LongRunning, TaskScheduler.Default);

            repServerTask = Task.Factory.StartNew(() =>
            {
                using (var repServer = new ZeroMqRepServer(netMqContext, repAddress))
                {
                    repServer.Run(cancellationToken);
                }
            }, cancellationToken, TaskCreationOptions.LongRunning, TaskScheduler.Default);
        }

        #region IDisposable
        /// <summary>
        /// Disposal flag.
        /// </summary>        
        protected bool disposed;

        /// <summary>
        /// Dispose implementation.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Finalizer.
        /// </summary>
        ~ZeroMqCommunication()
        {
            Dispose(false);
        }

        /// <summary>
        /// Finalizer/disposal.
        /// </summary>
        /// <param name="disposing">Set when called from the explicit dispose</param>        
        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    cancellation.Cancel();
                    repServerTask.Wait();
                    pubServerTask.Wait();                    
                }
                else
                {
                    System.Diagnostics.Debug.Assert(false, "Forgot to dispose object of type ZeroMqCommunication");
                }
                disposed = true;
            }
        }

        /// <summary>
        /// A check for disposal.
        /// </summary>        
        /// <exception cref="ObjectDisposedException">Throws if already disposed of</exception>
        protected void CheckDisposed()
        {
            if (disposed)
            {
                System.Diagnostics.Debug.Assert(false, "Trying to use disposed object of type ZeroMqCommunication");
                throw new ObjectDisposedException("ZeroMqCommunication");
            }
        }
        #endregion

        private Task repServerTask;
        private Task pubServerTask;
        private readonly CancellationTokenSource cancellation = new CancellationTokenSource();

    }
}
