﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Philips.PmsMR.UI.Interfaces.Model.PatientAdmin;

namespace Philips.PmsMR.UI.Presenter.PatientEntryPage
{

    class PatientSexEditor : PresenterBase, Common.IRadioButtonParent
    {
        public PatientSexEditor(WidgetId associatedWidget, IPresenter parentPresenter)
            : base(associatedWidget)
        {
            notificationsFactory.ChangeSubscriptions(context =>
            {
                context.PatientScheduler.PatientInEditor.PatientSexChanged += OnPatientSexChanged;
            });
        }

        public override void OnRequestArrived(object command) { }

        #region IRadioButtonParent Methods
        public void OnButtonClicked(string name)
        {
            PatientSexType type;
            Enum.TryParse(name, false, out type);
            ExecuteSimple(commandContext =>
            {
                commandContext.PatientScheduler.PatientInEditor.PatientSex = type;
            });
        }
        #endregion

        private void OnPatientSexChanged(PatientSexType sexType)
        {
            // TODO: this needs to use type-safe data in protobuf-format, now a hack with strings
            PostNotification(
                new Interfaces.Presenter.ZeroMQMessages.Notifications.PatientSexChanged
                {
                    PatientSex = DefaultWidgetPrefix + sexType
                });
        }
    }
}
