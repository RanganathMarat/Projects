﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Philips.PmsMR.UI.Presenter.PatientEntryPage
{
    /// <summary>
    /// Commands and notifications from the view layer.
    /// </summary>
    interface IPatientInfoSink
    {

    }

    /// <summary>
    /// Notifications from services and models.
    /// </summary>
    interface IPatientInfoEvents
    {

    }

    public enum PatientModificationType
    {
        Unknown = 0,
        PatientId = 73445
    }

    public enum ModificationTimingType
    {
        Unknown = 0,
        /// <summary>
        /// After the value has been modified.
        /// </summary>
        After = 452,
        /// <summary>
        /// Before the value is being modified.
        /// </summary>
        Before = 3734,      
    }

    /// <summary>
    /// TODO: protobuf data-model, string-editing change
    /// </summary>
    public class PatientStringModification
    {
        public PatientModificationType Modification;
        public ModificationTimingType Timing;
        public string Value;
    }

    /// <summary>
    /// Presentation for a patient info editor.
    /// </summary>
    class PatientInfoEditor : PresenterBase, IPatientInfoEvents, IPatientInfoSink
    {        
        internal PatientInfoEditor(WidgetId associatedWidget)
            : base(associatedWidget) { }

        /// <summary>
        /// Edit patient id value.
        /// </summary>
        /// <param name="newId"></param>
        public void SetPatientId(string newId)
        {
            ExecuteSimple(context =>
            {
                context.PatientScheduler.PatientInEditor.PatientId = newId;
            });
        }

        /// <summary>
        /// An opportunity to commit the data into database, editing has finished.
        /// </summary>
        public void LoseFocus()
        {
            // TODO: patient.CommitToDb
        }

        #region IPatientInfoEvents Methods
        /// <summary>
        /// A notification from the model.
        /// </summary>
        /// <param name="newId"></param>
        public void OnPatientIdChanged(string newId)
        {
            // TODO: publish a notification, synchronize (eventually) if we are within a command execution.
            // TODO: QueueNotification(new PatientStringModification {Timing = ModificationTimingType.After, Value = newId})
        }
        #endregion

        public override void OnRequestArrived(object command)
        {
            var stringModification = command as PatientStringModification;
            if (stringModification != null && stringModification.Timing == ModificationTimingType.After)
            {
                switch (stringModification.Modification)
                {
                    case PatientModificationType.PatientId:
                        SetPatientId(stringModification.Value);
                        break;
                    default:
                        throw new NotImplementedException("Modification id: " + stringModification.Modification);
                }
            }
        }

    }
}
