﻿using System;
using System.Collections.Generic;
using System.Linq;
using Philips.PmsMR.UI.Interfaces.Presenter.ZeroMQMessages.Requests;

namespace Philips.PmsMR.UI.Presenter
{
    /// <summary>
    /// Cache all creation messages.
    /// </summary>
    /// <remarks>
    /// Caching is needed to invert the creation message order in the case the view layer sends the messages
    /// in reverse order (children first)
    /// </remarks>
    class CreationCache
    {
        public delegate bool IsRootCreationCallback(Creation creation);

        public CreationCache(IsRootCreationCallback isRootCreation)
        {
            this.isRootCreation = isRootCreation;
        }

        public bool IsAlreadyCached(Creation creation)
        {
            return widgetIds.Contains(creation.WidgetId);
        }

        /// <summary>
        /// Try adding a creation message to the cache.
        /// </summary>
        /// <param name="creation"></param>
        /// <returns>A non-null cache result when the root creation is received - excludes the root item</returns>
        public List<Creation> TryAdding(Creation creation)
        {
            creationMessages.Add(creation);
            if (isRootCreation(creation))
            {
                System.Diagnostics.Trace.WriteLine("Creation cache detects the root creation, flushing the cache");
                return creationMessages;
            }
            widgetIds.Add(creation.WidgetId);
            return null;
        }

        private readonly List<Creation> creationMessages = new List<Creation>();
        private readonly HashSet<String> widgetIds = new HashSet<string>(); 
        private readonly IsRootCreationCallback isRootCreation;
    }
}
