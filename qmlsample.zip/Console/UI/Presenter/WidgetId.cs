using System;
using System.Globalization;

namespace Philips.PmsMR.UI.Presenter
{
    /// <summary>
    /// Unique identifier for a widget.
    /// </summary>
    class WidgetId : IEquatable<WidgetId>
    {
        public WidgetId(string id)
        {
            this.id = id;
        }

        public bool Equals(WidgetId other)
        {
            if (other == null)
            {
                return false;
            }
            return String.Compare(id, other.id, false, CultureInfo.InvariantCulture) == 0;
        }

        public override bool Equals(object obj)
        {
            return base.Equals(obj as WidgetId);
        }

        public override int GetHashCode()
        {
            if (id == null)
            {
                return 0;
            }
            return id.GetHashCode();
        }

        public string IdAsString()
        {
            return id;
        }

        private readonly string id;
    }
}