﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Philips.PmsMR.UI.Interfaces.Model.Commands;

namespace Philips.PmsMR.UI.Model.Commands
{
    abstract class Command : ICommand
    {
        public abstract ICommandResult Execute();

        public abstract Task<ICommandResult> ExecuteAsync();
    }
}
