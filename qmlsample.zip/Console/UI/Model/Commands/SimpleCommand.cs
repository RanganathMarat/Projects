﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Philips.PmsMR.UI.Interfaces.Model.Commands;

namespace Philips.PmsMR.UI.Model.Commands
{
    class SimpleCommand : Command
    {
        public SimpleCommand(Action<ICommandContext> commandAction, ICommandContext context)
        {
            this.commandAction = commandAction;
            this.context = context;
        }
        public override ICommandResult Execute()
        {
            commandAction(context);
            return new SimpleCommandResult();
        }

        public override Task<ICommandResult> ExecuteAsync()
        {
            return Task.FromResult(Execute());
        }

        private readonly Action<ICommandContext> commandAction;
        private readonly ICommandContext context;
    }
}
