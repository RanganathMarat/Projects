﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Philips.PmsMR.UI.Interfaces.Model.Commands;

namespace Philips.PmsMR.UI.Model.Commands
{
    class CommandContext : ICommandContext
    {

        public Interfaces.Model.PatientAdmin.IPatientScheduler PatientScheduler {get; internal set; }
    }
}
