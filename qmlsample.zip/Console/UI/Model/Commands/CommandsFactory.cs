﻿using System;
using System.Collections.Generic;
using System.Linq;
using Philips.PmsMR.UI.Interfaces.Model.Commands;

namespace Philips.PmsMR.UI.Model.Commands
{
    /// <summary>
    /// Factory implementation for creating commands.
    /// </summary>
    public class CommandsFactory : ICommandFactory
    {

        public CommandsFactory()
        {
            context = new CommandContext {PatientScheduler = PatientAdmin.PatientScheduler.Instance};
        }

        /// <summary>
        /// Singleton access.
        /// </summary>
        public static CommandsFactory Instance
        {
            get
            {
                return instance;
            }
        }

        #region ICommandFactory Methods
        /// <summary>
        /// Interface impl.
        /// </summary>
        /// <param name="commandAction"></param>
        /// <returns></returns>
        public ICommand CreateSimple(Action<ICommandContext> commandAction)
        {
            return new SimpleCommand(commandAction, context);
        }
        #endregion

        private readonly CommandContext context;
        private static readonly CommandsFactory instance = new CommandsFactory();
    }
}
