﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Philips.PmsMR.UI.Interfaces.Model.Examination;

namespace Philips.PmsMR.UI.Model.Examination
{


    class Scan : IScan
    {
        public event ScanChangedEventHandler ScanChanged;

        public IContrastAgent ContrastAgent
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public string GeoName
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public IEnumerable<IPostProcessingStep> PostProcessingSteps
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public IScanProperties ScanProperties
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public IHtmlHelp htmlHelp
        {
            get { throw new NotImplementedException(); }
        }


        public string ProtocolName
        {
            get
            {
                return protocolName;
            }
            set
            {
                if (String.Compare(protocolName, value, StringComparison.InvariantCulture) != 0)
                {
                    protocolName = value;
                    var notifiers = ScanChanged;
                    if (notifiers != null)
                    {
                        notifiers(this);
                    }
                }
            }
        }

        public Guid Id { get; internal set; }

        private string protocolName;
    }

    class ExamCard : IExamCard
    {
        public ExamCard()
        {
            // TODO: this is fake data, read from ExamCard service
            var items = new List<IExecutionItem>
            {
                new Scan
                {
                    Id = Guid.NewGuid(),
                    ProtocolName = "3D Survey"
                },
                new Scan
                {
                    Id = Guid.NewGuid(),
                    ProtocolName = "mDixon"
                },
                new Scan
                {
                    Id = Guid.NewGuid(),
                    ProtocolName = "Seed Scan"
                },
                new Scan
                {
                    Id = Guid.NewGuid(),
                    ProtocolName = "T2"
                },
            };

            for (int index = 0; index < 256; ++index)
            {
                items.Add(
                    new Scan
                    {
                        Id = Guid.NewGuid(),
                        ProtocolName = "T2 Copy " + (index + 1)
                    });
            }

            Items = items;
        }

        public event ExamCardChangedEventHandler ExamCardChanged;

        public IExecutionItem FindExecutionItem(Guid id)
        {
            return Items.FirstOrDefault(x => x.Id == id);
        }

        public IList<IExecutionItem> Items { get; set; }

        public void Move(Guid sourceId, Guid targetId, MovePositionType positionType)
        {
            // TODO: replace these with dictionary lookups - now using brute force
            var sourceItem = Items.FirstOrDefault(x => x.Id == sourceId);
            if (sourceItem == null)
            {
                return;
            }
            Items.Remove(sourceItem);

            bool moved = false;
            for (int index = 0; index < Items.Count && !moved; ++index)
            {
                if (Items[index].Id == targetId)
                {
                    switch (positionType)
                    {
                        case MovePositionType.Before:
                            Items.Insert(index, sourceItem);
                            break;
                        case MovePositionType.After:
                            Items.Insert(index+1, sourceItem);
                            break;
                    }
                    moved = true;
                }
            }
            var notifiers = ExamCardChanged;
            if (notifiers != null)
            {
                notifiers(this);
            }
        }

    }
}
