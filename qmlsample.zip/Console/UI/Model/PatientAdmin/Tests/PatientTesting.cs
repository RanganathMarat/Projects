﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

#if NUnitTest
using NUnit.Framework;

namespace Philips.PmsMR.UI.Model.PatientAdmin.Tests
{
    public class PatientTesting : Infra.Utilities.UnitTest.TestBed
    {

        [Test]
        public void PatientId_ValueChanged_NotificationsFired()
        {
            var patient = new Patient();
            patient.PatientId = "abc";
            string notifiedValue = null;
            patient.PatientIdChanged += id =>
            {
                notifiedValue = id;
            };
            patient.PatientId = "abc";
            Assert.IsNull(notifiedValue, "Notification not given yet, value not changed");
            patient.PatientId = "abcd";
            Assert.AreEqual("abcd", notifiedValue, "Subscription made and value changes, notification should have been created");
        }

        [Test]
        public void PatientId_MaximumLengthExceeded_ClippedNotificationFired()
        {
            var patient = new Patient();
            string notified = null;
            patient.PatientIdChanged += id =>
            {
                notified = id;
            };
            patient.PatientId = String.Concat(Enumerable.Repeat("\u2a6d", Patient.MaximumPatientIdLengthChars + 1));
            Assert.AreEqual(String.Concat(Enumerable.Repeat("\u2a6d", Patient.MaximumPatientIdLengthChars)), notified);
            notified = null;
            patient.PatientId = String.Concat(Enumerable.Repeat("\u2a6d", Patient.MaximumPatientIdLengthChars + 1));
            Assert.AreEqual(String.Concat(Enumerable.Repeat("\u2a6d", Patient.MaximumPatientIdLengthChars)), notified, "Another attempt to go over limit must spawn another notification to keep ui up-to-date");
        }
    }
}
#endif
