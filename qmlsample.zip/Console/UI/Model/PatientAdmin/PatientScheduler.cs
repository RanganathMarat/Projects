﻿#region Copyright 2015 Koninklijke Philips N.V.
//
// All rights reserved. Reproduction in whole or in part is prohibited without 
// the written consent of the copyright owner.
//
#endregion
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Philips.PmsMR.UI.Interfaces.Model.PatientAdmin;

namespace Philips.PmsMR.UI.Model.PatientAdmin
{
    /// <summary>
    /// Scheduler for patients.
    /// </summary>
    /// <remarks>
    /// There can be several patients defined in the system: 
    /// patients being prepared for upcoming scans,
    /// the patient currently being scanned,
    /// and patients that have already been scanned.
    /// </remarks>
    public class PatientScheduler : IPatientScheduler
    {

        public PatientScheduler()
        {
            PatientInEditor = new Patient();

            // TODO: this is fake data
            var patient = new Patient {CurrentExamCard = new Examination.ExamCard()};
            PatientInScanner = patient;
        }

        /// <summary>
        /// The patient being edited in UI.
        /// </summary>
        public IPatient PatientInEditor { get; private set; }

        /// <summary>
        /// The current patient being scanned.
        /// </summary>
        public IPatient PatientInScanner { get; private set; }

        public static readonly PatientScheduler Instance = new PatientScheduler();

    }
}
