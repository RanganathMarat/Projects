﻿#region Copyright 2015 Koninklijke Philips N.V.
//
// All rights reserved. Reproduction in whole or in part is prohibited without 
// the written consent of the copyright owner.
//
#endregion
using System;
using System.Collections.Generic;
using System.Linq;
using Philips.PmsMR.UI.Interfaces.Model.PatientAdmin;

namespace Philips.PmsMR.UI.Model.PatientAdmin
{
    /// <summary>
    /// Model for a patient.
    /// </summary>
    class Patient : IPatient
    {
        #region IPatient Methods
        public event PatientIdChangedEventHandler PatientIdChanged;

        public event PatientSexChangedEventHandler PatientSexChanged;

        public Interfaces.Model.Examination.IExamCard CurrentExamCard { get; internal set; }

        public string PatientId
        {
            get { return patientId;}
            set
            {
                if (String.Compare(patientId, value, StringComparison.InvariantCulture) != 0)
                {
                    patientId = value.Substring(0, Math.Min(value.Length, MaximumPatientIdLengthChars));
                    var notifiers = PatientIdChanged;
                    if (notifiers != null)
                    {
                        notifiers(patientId);
                    }
                }
            }
        }

        public PatientSexType PatientSex
        {
            get
            {
                return patientSex;
            }
            set
            {
                if (patientSex != value)
                {
                    patientSex = value;
                    var notifiers = PatientSexChanged;
                    if (notifiers != null)
                    {
                        notifiers(patientSex);
                    }
                }
            }
        }

        #endregion

        /// <summary>
        /// DICOM patient id LO definition.
        /// </summary>
        /// <remarks>
        /// Note that the limit is in characters, not in bytes.
        /// </remarks>
        public const int MaximumPatientIdLengthChars = 64;

        private string patientId;

        private PatientSexType patientSex;
    }
}
