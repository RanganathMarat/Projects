﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Philips.PmsMR.UI.Interfaces.Model.Notifications;
using Philips.PmsMR.UI.Interfaces.Model.PatientAdmin;

namespace Philips.PmsMR.UI.Model.Notifications
{
    public class NotificationsFactory : INotificationsFactory
    {
        public static NotificationsFactory Instance
        {
            get
            {
                return instance;                
            }
        }

        public NotificationsFactory()
        {
            context = new NotificationsContext {PatientScheduler = PatientAdmin.PatientScheduler.Instance};
        }

        public void ChangeSubscriptions(Action<INotificationContext> changeCall)
        {
            changeCall(context);
        }

        public void QueryModel(Action<INotificationContext> queryCall)
        {
            queryCall(context);
        }

        private class NotificationsContext : INotificationContext
        {
            public IPatientScheduler PatientScheduler { get; internal set; }
        }

        private NotificationsContext context;
        private static readonly NotificationsFactory instance = new NotificationsFactory();

    }
}
