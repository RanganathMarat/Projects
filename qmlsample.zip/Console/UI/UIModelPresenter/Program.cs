﻿using System;
using NetMQ;

namespace Philips.PmsMR.UI.UIModelPresenter
{
    class Program
    {
        static void Main(string[] args)
        {
            string repAddress = "tcp://127.0.0.1:1235";
            string pubAddress = "tcp://127.0.0.1:1234";
            for (int index = 0; index < args.Length; ++index)
            {
                if (args[index] == "--rep_address")
                {
                    repAddress = args[++index];
                }
                if (args[index] == "--pub_address")
                {
                    pubAddress = args[++index];
                }
            }

            using (var context = NetMQContext.Create())
            {

                using (var communication = new Presenter.Communication.ZeroMqCommunication())
                {
                    Console.WriteLine("Press any key to exit!");
                    communication.Launch(context, pubAddress, repAddress);
                    Console.ReadKey();
                }                
            }
        }
    }
}
