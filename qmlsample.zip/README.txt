UI Release Part: A git repository for user interface development

*** Adding of new visual studio 2013 C# projects ***
Use visual studio to create a new project.
Edit the created project file:
  * Fix root namespace and assembly name elements
  * Remove <TargetFrameworkVersion>vX.Y.Z</TargetFrameworkVersion> - the target version setting is centralized
  * Add <RootLevel>$([MSBuild]::GetDirectoryNameOfFileAbove($(MSBuildThisFileDirectory), '.gitmodules'))\</RootLevel> to locate the root directory automatically
  * Add <Import Project="$(RootLevel)build\consolebuild\Common.CSharp.include.proj" /> before the first ItemGroup
  * Add <Import Project="$(RootLevel)build\consolebuild\Common.CSharp.post.include.proj" /> just after <Import Project="$(MSBuildToolsPath)\Microsoft.CSharp.targets" /> - line.
  * Add the new project file to the .proj file of the parent-directory (as a subproject) 
  * Remove the local AssemblyInfo.cs from project Properties-subdirectory