
This directory contains build tools that are not intended for inclusion into the product.

Most of the tools are to be implemented as shallow git submodules that point to individual Tools-project repositories.
Decision to create a submodule is based on the following logic:
 * if the tool is generally useful and needs to be shared with other release parts => submodule
 * if the tool is large, that is, it contains large amount of source code or history, or binary artifacts => submodule
 * a release-part specific script or compilable tool => local subdirectory, part of this release part repository

Shallow git submodules ensure that the cloning of the release part is a light-weight operation.
For example, if a submodule repository contains large, prebuild binaries, and the binaries have several
versions, the resulting repository can be hunderds of MB in size. A shallow submodule refers to a single
commit in the large repository, so that when the code is downloaded, only a single revision of binaries is 
retrieved.


*** To create a shallow submodule ***
Preconditions: 
- A known (external) git repository exists for a new tool to be taken into use, for example, in github.
  - If the git repository does not exist, the code can be imported to an internal repository and used in place of the external repository.
- Our product repository (the repository this file is in) is checked out to the disk.

Clone ssh://git@firvatayr1ms019.code1.emi.philips.com:7999/tool/scripts.git to your local hard-disk
- This repository contains useful automation scripts/tools for interacting with git with complex/laborious commands

Use Stash and scripts/Tools/import_external_repo.py to populate an internal tool-repository clone for the external repository
- This script needs an existing label on the external repo for creating Philips-specific branch from the label
  - Note that the label can also be a pre-existing branch
- You need to create an empty internal repository in Stash, in this case, under the Tools project
  - See the script help (-h option) for details

Go to the Tools-directory on the product repository and create a submodule:
	git submodule add -b <created_philips_branch_here> --  ssh://git@firvatayr1ms019.code1.emi.philips.com:7999/tool/<internal repo>.git <subfolder name>
- This will create a submodule as a directory under Tools-dir

Commit the product repository

*** To repopulate a shallow submodule after cloning ***
When the product repository is cloned, the submodules are not automatically checked out.
Use Tools/update_submodules.exe in the root directory of your product repository to download submodule files
- Running update_submodules will also update the submodule contents, for example, after merging or pulling

